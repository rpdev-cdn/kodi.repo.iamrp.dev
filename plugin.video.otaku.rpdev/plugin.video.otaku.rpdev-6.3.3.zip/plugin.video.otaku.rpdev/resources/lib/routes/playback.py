# -*- coding: utf-8 -*-
import ast
import json
import re
import time

from resources.lib import MetaBrowser
from resources.lib.routes.history import save_to_watch_history
from resources.lib.ui import control, database, utils
from resources.lib.ui.router import Route, multi_route

_BROWSER_ROUTE_SUFFIXES = ('tv_show', 'movie', 'tv_short', 'special', 'ova', 'ona', 'music')


def _browser_list_route_paths(prefix):
    return (prefix,) + tuple('%s_%s' % (prefix, s) for s in _BROWSER_ROUTE_SUFFIXES)


def _wildcard_browser_paths(prefix):
    """Paths like ``marked_as_watched/*``, ``marked_as_watched_tv_show/*``, …"""
    return tuple('%s/*' % p for p in _browser_list_route_paths(prefix))


def _show_source_select(mock_args, sources, rescrape):
    from resources.lib.windows.source_select import SourceSelect
    xml_file = 'source_select_alt.xml' if control.getInt('general.dialog') in (5, 6) else 'source_select.xml'
    dlg = None
    try:
        dlg = SourceSelect(xml_file, control.ADDON_PATH, actionArgs=mock_args, sources=sources, rescrape=rescrape)
        return dlg.doModal()
    finally:
        if dlg:
            try:
                dlg.close()
            except Exception:
                pass
            del dlg


def _show_resolver(mock_args, sources):
    from resources.lib.windows.resolver import Resolver
    xml_file = 'resolver_alt.xml' if control.getInt('general.dialog') in (5, 6) else 'resolver.xml'
    dlg = None
    try:
        dlg = Resolver(xml_file, control.ADDON_PATH, actionArgs=mock_args)
        return dlg.doModal(sources, {}, False)
    finally:
        if dlg:
            try:
                dlg.close()
            except Exception:
                pass
            del dlg


def _param_flag_true(params, key):
    if not isinstance(params, dict):
        return False
    val = params.get(key)
    if isinstance(val, bool):
        return val
    if val is None:
        return False
    return str(val).strip().lower() in ('true', '1', 'yes')


def _clear_preresolved_handoff():
    for prop in (
        'otaku.preResolved_url',
        'otaku.preResolved_malId',
        'otaku.preResolved_episode',
        'otaku.preResolved_data',
    ):
        control.playerWindow.clearProperty(prop)


@Route('play/*')
def PLAY(payload, params):
    parts = [p for p in payload.strip('/').split('/') if p]
    mal_id = parts[0] if parts else ''
    episode = parts[1] if len(parts) > 1 else '1'
    source_select = _param_flag_true(params, 'source_select')
    rescrape = _param_flag_true(params, 'rescrape')
    if source_select or rescrape:
        _clear_preresolved_handoff()
    last_played = control.getSetting('last_played_source')
    last_watched = control.getSetting('last_watched_series')
    resume = params.get('resume')
    if rating := params.get('rating'):
        try:
            params['rating'] = ast.literal_eval(rating)
        except (ValueError, SyntaxError):
            params['rating'] = rating
    params['path'] = f"{control.addon_url(f'play/{payload}')}"

    # Populate params with episode metadata from database if not already present
    # This ensures metadata is available even when playing from Information dialog
    if not params.get('tvshowtitle'):
        episode_data = database.get_episode(mal_id, episode)
        if not episode_data:
            MetaBrowser.get_anime_init(mal_id)
            episode_data = database.get_episode(mal_id, episode)
        if episode_data:
            params = database.loads(episode_data['kodi_meta'])
        else:
            # Fallback: build minimal params from show database
            # This ensures metadata is available even for episodes not yet indexed
            show_meta = database.get_show(mal_id)
            if show_meta:
                kodi_meta = database.loads(show_meta['kodi_meta'])
                show_art = database.get_show_meta(mal_id)
                art = database.loads(show_art['art']) if show_art and show_art.get('art') else {}
                params = {
                    'info': {
                        'title': f"{kodi_meta.get('title_userPreferred', '')} - Episode {episode}",
                        'tvshowtitle': kodi_meta.get('title_userPreferred', ''),
                        'episode': int(episode),
                        'plot': kodi_meta.get('plot', ''),
                        'mediatype': 'episode',
                        'UniqueIDs': {'mal_id': str(mal_id), **database.get_unique_ids(mal_id, 'mal_id')},
                    },
                    'image': {
                        'poster': art.get('poster') or kodi_meta.get('poster', ''),
                        'fanart': art.get('fanart', ''),
                        'icon': art.get('poster') or kodi_meta.get('poster', ''),
                        'thumb': art.get('thumb', ''),
                    },
                    'path': params.get('path', ''),
                }

    if resume:
        resume = float(resume)
        context = control.context_menu([f'Resume from {utils.format_time(resume)}', 'Play from beginning'])
        if context == -1:
            return control.exit_code()
        elif context == 1:
            resume = None

    # Guard against premature scraping of unaired episodes
    episode_info = params.get('info', {})
    aired_str = episode_info.get('aired')
    if aired_str and not rescrape and not source_select:
        try:
            from datetime import date
            aired_date = date.fromisoformat(aired_str[:10])
            today = date.today()
            if aired_date > today:
                diff_days = (aired_date - today).days
                day_str = "tomorrow" if diff_days == 1 else f"in {diff_days} days ({aired_date.strftime('%a, %b %d')})"
                confirmed = control.yesno_dialog(
                    control.ADDON_NAME,
                    f"Episode {episode} is not scheduled to air until {day_str}.\n\nSearch for early releases or raw leaks anyway?"
                )
                if not confirmed:
                    return control.exit_code()
        except Exception as e:
            control.log(f"playback aired_date check error: {e}", 'debug')

    # Zero-Wait Pre-Resolved Stream Handoff
    preresolved_url = control.playerWindow.getProperty('otaku.preResolved_url')
    preresolved_mal_id = control.playerWindow.getProperty('otaku.preResolved_malId')
    preresolved_ep = control.playerWindow.getProperty('otaku.preResolved_episode')
    preresolved_data_str = control.playerWindow.getProperty('otaku.preResolved_data')

    if (
        preresolved_url
        and preresolved_mal_id == str(mal_id)
        and preresolved_ep == str(episode)
        and not source_select
        and not rescrape
        and control.getBool('smartplay.preresolve', default=True)
    ):
        control.log(f"Playback: Zero-Wait Pre-Resolved Stream Hit for {mal_id} Ep {episode}!", 'info')
        control.playerWindow.clearProperty('otaku.preResolved_url')
        control.playerWindow.clearProperty('otaku.preResolved_malId')
        control.playerWindow.clearProperty('otaku.preResolved_episode')
        control.playerWindow.clearProperty('otaku.preResolved_data')

        preresolved_data = control.loads_json(preresolved_data_str, default={}) if preresolved_data_str else {}
        if not isinstance(preresolved_data, dict):
            preresolved_data = {}

        import xbmcgui, xbmcplugin
        item = xbmcgui.ListItem(path=preresolved_url, offscreen=True)

        # Always purge stale temporary subtitle files and embed sub flags before preparing new playback
        from resources.lib.ui import embed_extractor, source_utils
        embed_extractor.del_subs()
        control.clearGlobalProp('otaku.embed_sub_signs_only')
        control.clearGlobalProp('otaku.embed_sub_has_full_dialog')

        if preresolved_data.get('sub'):
            from resources.lib.subtitles import languages
            pref_lang = languages.get_preferred_subtitle_language()
            sub_entries = []
            if pref_lang != 'none':
                for idx, sub in enumerate(preresolved_data['sub']):
                    sub_lang = sub.get('lang') or embed_extractor.detect_sub_lang(sub.get('url'), sub.get('name'))
                    if pref_lang and not languages.is_language_match(sub_lang, pref_lang):
                        control.log(f"Playback: Skipping embed subtitle '{sub.get('name', '')}' ({sub_lang}) - does not match preferred '{pref_lang}'", 'debug')
                        continue
                    entry = embed_extractor.get_sub(
                        sub.get('url'),
                        sub.get('lang'),
                        headers=sub.get('headers'),
                        sub_index=sub.get('index', idx),
                        display_name=sub.get('name'),
                        source_url=sub.get('file'),
                        sub_tag=f"{mal_id}_{episode}_{int(time.time() * 1000)}",
                    )
                    if entry:
                        sub_entries.append(entry)
            if sub_entries:
                item.setSubtitles([e['path'] for e in sub_entries])

        headers = preresolved_data.get('headers') or {}
        from resources.lib.windows.resolver import _get_header_ci, hook_mimetype
        content_type = _get_header_ci(headers, 'Content-Type')
        if content_type:
            item.setProperty('MimeType', content_type.split(';', 1)[0].strip())
            item = hook_mimetype.trigger(content_type, item)

        video_info = dict(params.get('info', {})) if params.get('info') else dict(params)
        control.set_videotags(item, video_info)

        # Signal standardized filename to Kodi Player and subtitle search addons
        clean_filename = source_utils.format_video_filename(video_info)
        if clean_filename:
            item.setProperty('original_filename', clean_filename)
            item.setProperty('VideoPlayer.OriginalFilename', clean_filename)
            item.setLabel(clean_filename)
        if params.get('image'):
            clean_art = control.clean_art_dict(params.get('image'))
            if clean_art:
                item.setArt(clean_art)

        from resources.lib.WatchlistIntegration import watchlist_update_episode
        from resources.lib.ui import player
        source_dict = preresolved_data.get('source') or {}
        if source_dict:
            database.save_last_played_source(mal_id, source_dict)
            if source_dict.get('type') in ['embed', 'direct']:
                lp_key = f"{source_dict.get('provider', '')} {' '.join(map(str, source_dict.get('info') or []))}".strip()
            else:
                lp_key = str(source_dict.get('release_title') or source_dict.get('name') or '')
            control.setSetting('last_played_source', lp_key)
            control.setSetting('last_watched_series', str(mal_id))

        stype = source_dict.get('type', '')
        sprovider = source_dict.get('provider', '')
        xbmcplugin.setResolvedUrl(control.HANDLE, True, item)
        player.WatchlistPlayer().handle_player(
            mal_id,
            watchlist_update_episode,
            int(episode),
            resume,
            params.get('path', ''),
            stype,
            sprovider,
            False,
            None,
        )
        control.exit_code()
        return

    sources = MetaBrowser.get_sources(mal_id, episode, 'show', rescrape, source_select)
    if sources:
        _mock_args = {"mal_id": mal_id, "episode": episode, 'play': True, 'resume': resume, 'context': rescrape or source_select, 'params': params}

        # SmartPlay Enabled
        if control.getBool('general.smartplay'):
            last_played_profile = database.get_last_played_source(mal_id)
            has_last_source = (last_played not in ("None", "0", "", None)) or bool(last_played_profile)
            is_same_series = (last_watched == str(mal_id)) or bool(last_played_profile)
            control.setSetting('last_watched_series', str(mal_id))

            if is_same_series and has_last_source and not source_select and not rescrape:
                _show_resolver(_mock_args, sources)
            else:
                _show_source_select(_mock_args, sources, rescrape)
        # SmartPlay Disabled
        else:
            if control.getInt('general.playstyle.episode') == 1 or source_select or rescrape:
                _show_source_select(_mock_args, sources, rescrape)
            else:
                _show_resolver(_mock_args, sources)
    else:
        control.playList.clear()
    control.exit_code()


@Route('play_movie/*')
def PLAY_MOVIE(payload, params):
    parts = [p for p in payload.strip('/').split('/') if p]
    mal_id = parts[0] if parts else ''
    eps_watched = parts[1] if len(parts) > 1 else '0'
    source_select = _param_flag_true(params, 'source_select')
    rescrape = _param_flag_true(params, 'rescrape')
    if source_select or rescrape:
        _clear_preresolved_handoff()
    resume = params.get('resume')
    params['path'] = f"{control.addon_url(f'play_movie/{payload}')}"

    # Populate params with movie metadata from database if not already present
    # This ensures metadata is available even when playing from Information dialog
    if not params.get('name'):
        from resources.lib.OtakuBrowser import OtakuBrowser
        OtakuBrowser().get_anime_data(mal_id)
        anime_meta = database.get_show_meta(mal_id)
        anime_data = database.get_show(mal_id)
        if not anime_data or not anime_meta:
            control.exit_code()
            return
        kodi_meta = database.loads(anime_data['kodi_meta']) if anime_data.get('kodi_meta') else {}
        art_data = database.loads(anime_meta['art']) if anime_meta.get('art') else {}

        params = {
            **kodi_meta,
            'info': kodi_meta,  # video info tags
            'image': {  # art fields for UI
                k: (v[0] if isinstance(v, list) else v)
                for k, v in art_data.items()
            }
        }

    if resume:
        resume = float(resume)
        context = control.context_menu([f'Resume from {utils.format_time(resume)}', 'Play from beginning'])
        if context == -1:
            return control.exit_code()
        elif context == 1:
            resume = None

    sources = MetaBrowser.get_sources(mal_id, 1, 'movie', rescrape, source_select)
    if sources:
        _mock_args = {'mal_id': mal_id, 'play': True, 'resume': resume, 'context': rescrape or source_select, 'params': params}
        if control.getInt('general.playstyle.movie') == 1 or source_select or rescrape:
            _show_source_select(_mock_args, sources, rescrape)
        else:
            _show_resolver(_mock_args, sources)
    else:
        control.playList.clear()
    control.exit_code()


@Route('tmdb_helper')
def TMDB_HELPER(payload, params):
    # --- Extract all relevant parameters from params and actionArgs ---
    from resources.lib.OtakuBrowser import OtakuBrowser
    from resources.lib.endpoints import tmdb

    action_args = params.pop('actionArgs', {})
    if isinstance(action_args, str):
        action_args = ast.literal_eval(action_args)
    # Now it's safe to use .get
    item_type = action_args.get('item_type')

    # Extract parameters from action_args
    item_type = action_args.get('item_type')
    tmdb_id = action_args.get('tmdb_id')
    tvdb_id = action_args.get('tvdb_id')
    imdb_id = action_args.get('imdb_id')
    trakt_id = action_args.get('trakt_id')
    season = action_args.get('season')
    episode = action_args.get('episode')

    # Extract source_select from params (default to False)
    source_select = params.pop('source_select', 'false') == 'true'
    params.update({'source_select': source_select})

    # Convert season and episode to int if present
    season_number = int(season) if season is not None else None
    episode_number = int(episode) if episode is not None else None

    # Grab Playstyle settings
    smartplay = control.getBool('general.smartplay')
    playstyle_movie = control.getInt('general.playstyle.movie')
    playstyle_episode = control.getInt('general.playstyle.episode')

    try:
        # Disable SmartPlay temporarily
        if smartplay:
            control.setBool('general.smartplay', False)

        # Parms cleanup
        parms = {}

        # Now all parameters are available: item_type, tmdb_id, title_url, season_number, episode_number, source_select
        control.log("Item Type: " + str(item_type))
        control.log("TMDB ID: " + str(tmdb_id))
        control.log("TVDB ID: " + str(tvdb_id))
        control.log("IMDB ID: " + str(imdb_id))
        control.log("Trakt ID: " + str(trakt_id))
        control.log("Season Number: " + str(season_number))
        control.log("Episode Number: " + str(episode_number))
        control.log("Source Select: " + str(source_select))

        if item_type == 'movie':
            mal_id = None
            id_sources = [
                ('themoviedb_id', tmdb_id),
                ('thetvdb_id', tvdb_id),
                ('imdb_id', imdb_id),
                ('trakt_id', trakt_id)
            ]

            for key, value in id_sources:
                if value:
                    anime_ids = database.get_mappings(value, key)
                    if anime_ids and anime_ids.get('mal_id'):
                        mal_id = anime_ids['mal_id']
                        break

            if mal_id:
                OtakuBrowser().get_anime_data(mal_id)

                if source_select:
                    control.setInt('general.playstyle.movie', 1)
                else:
                    control.setInt('general.playstyle.movie', 0)

                PLAY_MOVIE(f"{mal_id}/", parms)
                if control.monitor.waitForAbort(3):
                    return
                return
            else:
                if not control.monitor.waitForAbort(3):
                    control.notify(control.ADDON_NAME, 'No MAL ID found from this movie')
                return

        else:
            mal_ids = set()
            id_sources = [
                ('themoviedb_id', tmdb_id),
                ('thetvdb_id', tvdb_id),
                ('imdb_id', imdb_id),
                ('trakt_id', trakt_id)
            ]

            for key, value in id_sources:
                if value:
                    mappings = database.get_mal_ids(value, key)  # Now returns a list
                    for anime_ids in mappings:
                        if anime_ids and 'mal_id' in anime_ids and anime_ids['mal_id']:
                            if isinstance(anime_ids['mal_id'], list):
                                mal_ids.update(anime_ids['mal_id'])
                            else:
                                mal_ids.add(anime_ids['mal_id'])

            if mal_ids:
                episode_titles = tmdb.get_episode_titles(tmdb_id, season_number, episode_number)
                match = tmdb_mapping_match(tmdb_id, id_sources, season_number, episode_number) or find_episode_by_title(mal_ids, episode_titles)
                if match:
                    mal_id = match['mal_id']
                    episode_num = match['episode_number']
                    matched_title = match['matched_title']
                    control.log(f"Matched MAL ID: {mal_id} for Episode {episode_num} titled '{matched_title}'")
                    OtakuBrowser().get_anime_data(mal_id)
                    MetaBrowser.get_anime_init(mal_id)

                    if source_select:
                        control.setInt('general.playstyle.episode', 1)
                    else:
                        control.setInt('general.playstyle.episode', 0)

                    PLAY(f"{mal_id}/{episode_num}", parms)
                    if control.monitor.waitForAbort(3):
                        return
                    return
                else:
                    if not control.monitor.waitForAbort(3):
                        control.notify(control.ADDON_NAME, 'No MAL ID found from this episode')
                    return
    finally:
        control.setInt('general.playstyle.movie', playstyle_movie)
        control.setInt('general.playstyle.episode', playstyle_episode)
        control.setBool('general.smartplay', smartplay)


def tmdb_mapping_match(tmdb_id, id_sources, season_number, episode_number):
    """Find the MAL id and episode for a TMDb season/episode using mappings.db, returns None if unsure"""
    try:
        return _tmdb_mapping_match(tmdb_id, id_sources, season_number, episode_number)
    except Exception as e:
        control.log(f'TMDB mapping: error, falling back to title matching: {e}', 'warning')
        return None


def _tmdb_mapping_match(tmdb_id, id_sources, season_number, episode_number):
    from resources.lib.ui import client
    from resources.lib.endpoints import tmdb as tmdb_api

    if not tmdb_id or not season_number or not episode_number:
        return None

    # Get all mapping rows for this show and only keep the ones for this TMDb id
    rows, seen = [], set()
    for key, value in id_sources:
        if not value:
            continue
        for row in database.get_mal_ids(value, key) or []:
            if row and row.get('mal_id') and row['mal_id'] not in seen:
                seen.add(row['mal_id'])
                rows.append(row)
    rows = [r for r in rows if str(r.get('themoviedb_id')) == str(tmdb_id)]
    if not rows:
        return None

    # Turn a range like '13-25' into (13, 25)
    def ep_range(value):
        m = re.match(r'\s*(\d+)\s*-\s*(\d+)', str(value or ''))
        return (int(m.group(1)), int(m.group(2))) if m else None

    # Check if the episode is inside this MAL entry and get its episode number there
    def result(row, number):
        g, a = ep_range(row.get('global_media_episodes')), ep_range(row.get('anime_media_episodes'))
        if not g or not (g[0] <= number <= g[1]):
            return None
        start = a[0] if a else 1
        control.log(f"TMDB mapping match: S{season_number}E{episode_number} -> MAL {row['mal_id']} ep {start + number - g[0]}")
        return {'mal_id': row['mal_id'], 'episode_number': start + number - g[0], 'matched_title': 'mappings.db'}

    # Get the episode count of each season from TMDb
    layout = {}
    try:
        res = control.safe_json(client.get(f'{tmdb_api.baseUrl}tv/{tmdb_id}', params={'api_key': tmdb_api.apiKey}))
        layout = {int(s['season_number']): int(s.get('episode_count') or 0)
                  for s in res.get('seasons', []) if s.get('season_number') is not None}
    except Exception as e:
        control.log(f'TMDB mapping: could not load season layout: {e}', 'warning')
    tmdb_before = sum(n for s, n in layout.items() if 0 < s < season_number) if layout else None

    # Try the TVDb season with the same number as the TMDb season first
    season_rows = [r for r in rows if str(r.get('thetvdb_season')) == str(season_number)]
    if season_rows:
        if tmdb_before is not None:
            # Only use it if the earlier seasons add up to the same episode count on TMDb and TVDb
            tvdb_ends = {}
            for r in rows:
                s, g = str(r.get('thetvdb_season')), ep_range(r.get('global_media_episodes'))
                if s.isdigit() and 0 < int(s) < season_number and g:
                    tvdb_ends[int(s)] = max(tvdb_ends.get(int(s), 0), g[1])
            complete = all(s in tvdb_ends for s in range(1, season_number))
            if not complete or sum(tvdb_ends.values()) != tmdb_before:
                control.log('TMDB mapping: TMDb and TVDb season layouts differ, falling back to title matching')
                season_rows = []
        for r in season_rows:
            match = result(r, episode_number)
            if match:
                return match

    # Consult tvdb_rules table (from Otaku-Mapping-DB v2.0+) for multi-cour / split offsets
    for r in rows:
        for rule in (database.get_tvdb_rules(r.get('mal_id')) or []):
            if str(rule.get('season')) != str(season_number):
                continue
            r_start = rule.get('range_start')
            r_end = rule.get('range_end')
            ep_start = rule.get('ep_start') or 1
            if r_start is None:
                continue
            if episode_number >= int(r_start) and (r_end is None or episode_number <= int(r_end)):
                mapped_ep = int(ep_start) + episode_number - int(r_start)
                control.log(f"TMDB rule match: S{season_number}E{episode_number} -> MAL {r['mal_id']} ep {mapped_ep}")
                return {'mal_id': r['mal_id'], 'episode_number': mapped_ep, 'matched_title': 'mappings.db'}

    # Absolute numbered shows like Naruto and One Piece
    abs_rows = [r for r in rows if str(r.get('thetvdb_season')) == 'a']
    if abs_rows and tmdb_before is not None:
        absolute = tmdb_before + episode_number
        for r in abs_rows:
            match = result(r, absolute)
            if match:
                return match
    return None


def remove_punctuation(s):
    return re.sub(r'[^\w\s]', '', s)


def find_episode_by_title(mal_ids, episode_titles):
    from resources.lib.indexers.jikanmoe import JikanAPI
    from resources.lib.ui.source_utils import get_fuzzy_match, clean_text
    # Split titles on '|' and clean each part
    split_titles = []
    for t in episode_titles:
        if t:
            split_titles.extend([x.strip() for x in t.split('|') if x.strip()])
    # Use shared clean_text for normalization (removes punctuation, preserves spaces)
    cleaned_titles = [clean_text(t) for t in split_titles]
    jikan_api = JikanAPI()
    requests_made = 0
    last_request_time = time.time()
    for mal_id in mal_ids:
        # Rate limit: max 3 requests every 4 seconds, space each request by at least 1.33 seconds
        if requests_made == 3:
            elapsed = time.time() - last_request_time
            if elapsed < 4.0:
                if control.monitor.waitForAbort(max(0.01, 4.0 - elapsed)):
                    break
            requests_made = 0
            last_request_time = time.time()
        # Space each request by at least 1.33 seconds
        if requests_made > 0:
            if control.monitor.waitForAbort(1.33):
                break
        # Retry logic for HTTP 429
        retries = 0
        max_retries = 3
        backoff = 2
        while retries <= max_retries:
            try:
                episodes = jikan_api.get_episode_meta(mal_id)
                requests_made += 1
                break
            except Exception as e:
                if hasattr(e, 'response') and getattr(e.response, 'status_code', None) == 429:
                    control.log(f"Jikan API rate limited (429) for mal_id {mal_id}, retrying in {backoff} seconds...")
                    if control.monitor.waitForAbort(backoff):
                        break
                    retries += 1
                    backoff *= 2
                else:
                    control.log(f"Jikan API error for mal_id {mal_id}: {e}")
                    episodes = []
                    break
        else:
            control.log(f"Jikan API failed for mal_id {mal_id} after {max_retries} retries.")
            episodes = []
        # Prepare candidate episode titles from Jikan
        episode_candidates = []
        episode_meta_map = []
        for ep in episodes:
            candidates = [
                ep.get('title', ''),
                ep.get('title_romanji', '')
            ]
            for candidate in candidates:
                if candidate:
                    episode_candidates.append(candidate)
                    episode_meta_map.append((candidate, ep))
        # Use shared clean_text for normalization
        cleaned_candidates = [clean_text(c) for c in episode_candidates]
        # Run fuzzy matching for each cleaned title variant individually
        best_idx = None
        for cleaned_query in cleaned_titles:
            match_indices = get_fuzzy_match(cleaned_query, cleaned_candidates)
            if match_indices:
                # get_fuzzy_match returns sorted indices by best match first
                idx = match_indices[0]
                if best_idx is None or idx < best_idx:
                    best_idx = idx
        if best_idx is not None:
            best_candidate, best_ep = episode_meta_map[best_idx]
            control.log(f"FUZZY MATCH FOUND: Jikan '{best_candidate}' matched TMDB title (fuzzy).")
            info = {
                'mal_id': mal_id,
                'episode_number': best_ep.get('mal_id'),
                'matched_title': best_candidate,
            }
            return info
        else:
            # Fallback to direct match if fuzzy fails
            for idx, candidate in enumerate(cleaned_candidates):
                if candidate in cleaned_titles:
                    orig_candidate, ep = episode_meta_map[idx]
                    control.log(f"DIRECT MATCH FOUND: Jikan '{orig_candidate}' matched TMDB title.")
                    info = {
                        'mal_id': mal_id,
                        'episode_number': ep.get('mal_id'),
                        'matched_title': orig_candidate,
                    }
                    return info
            control.log("No fuzzy or direct match for Jikan episode titles against TMDB titles.")
    return None  # No match found


@multi_route(*_wildcard_browser_paths('marked_as_watched'))
def MARKED_AS_WATCHED(payload, params):
    from resources.lib.WatchlistIntegration import watchlist_update_episode
    import service

    parts = [p for p in payload.strip('/').split('/') if p]
    if len(parts) >= 2:
        mal_id, episode = parts[0], parts[1]
    elif parts:
        mal_id, episode = parts[0], 1
    else:
        mal_id, episode = "", 1

    any_completed = watchlist_update_episode(mal_id, episode)
    if any_completed:
        if not control.monitor.waitForAbort(3):
            service.sync_watchlist(True)

    # Synchronize Watch History
    if mal_id:
        try:
            ep_int = int(episode) if str(episode).isdigit() else 1
            save_to_watch_history(mal_id, ep_int)
        except Exception as e:
            control.log(f"Error saving to watch history: {e}", "warning")

    # Invalidate cached eps_watched in kodi_meta so UI repaints playcounts
    show = database.get_show(mal_id)
    if show:
        try:
            kodi_meta = database.loads(show['kodi_meta'])
            ep_int = int(episode) if str(episode).isdigit() else 1
            kodi_meta['eps_watched'] = max(int(kodi_meta.get('eps_watched') or 0), ep_int)
            database.update_kodi_meta(mal_id, kodi_meta)
        except Exception as e:
            control.log(f"Error updating kodi_meta: {e}", "warning")

    # Update SQLite episodes table for the marked episode
    try:
        ep_num = int(episode) if str(episode).isdigit() else 1
        ep_row = database.get_episode(mal_id, ep_num)
        if ep_row:
            ep_meta = database.loads(ep_row['kodi_meta'])
            if ep_meta.get('info', {}).get('playcount') != 1:
                ep_meta.setdefault('info', {})['playcount'] = 1
                database.update_episode_column(mal_id, ep_num, 'kodi_meta', database.dumps(ep_meta))
    except Exception as e:
        control.log(f"Error updating episode table playcount: {e}", "warning")

    # Build notification showing updated watchlists
    enabled = control.enabled_watchlists()
    flavor_labels = {'anilist': 'AniList', 'kitsu': 'Kitsu', 'mal': 'MAL', 'simkl': 'Simkl'}
    updated_names = ', '.join([flavor_labels.get(f, f.capitalize()) for f in enabled]) if enabled else 'No Watchlist'

    if len(parts) >= 2:
        control.notify(control.ADDON_NAME, f'Episode #{episode} was Marked as Watched in {updated_names}')
        folder_path = control.getInfoLabel('Container.FolderPath')
        if 'watchlist_to_ep' in folder_path:
            control.execute(f'Container.Update(plugin://{control.ADDON_ID}/watchlist_to_ep/{mal_id}/{episode})')
        else:
            control.execute('Container.Refresh')
    else:
        title = ''
        if show:
            kodi_meta = database.loads(show['kodi_meta'])
            title = kodi_meta.get('title_userPreferred', '')
        control.notify(control.ADDON_NAME, f'{title} was Marked as Watched in {updated_names}')
        control.execute('Container.Refresh')
    control.exit_code()


@multi_route(*_wildcard_browser_paths('marked_as_unwatched'))
def MARKED_AS_UNWATCHED(payload, params):
    from resources.lib.WatchlistIntegration import watchlist_update_episode
    import service

    parts = [p for p in payload.strip('/').split('/') if p]
    if len(parts) >= 2:
        mal_id, ep_str = parts[0], parts[1]
    elif parts:
        mal_id, ep_str = parts[0], '1'
    else:
        return

    try:
        current_ep = int(ep_str)
        target_ep = max(0, current_ep - 1)
    except (ValueError, TypeError):
        current_ep = 1
        target_ep = 0

    any_completed = watchlist_update_episode(mal_id, target_ep)
    if any_completed:
        if not control.monitor.waitForAbort(3):
            service.sync_watchlist(True)

    # Invalidate cached eps_watched in kodi_meta so UI repaints playcounts
    show = database.get_show(mal_id)
    if show:
        try:
            kodi_meta = database.loads(show['kodi_meta'])
            kodi_meta['eps_watched'] = target_ep
            database.update_kodi_meta(mal_id, kodi_meta)
        except Exception as e:
            control.log(f"Error updating kodi_meta: {e}", "warning")

    # Clear SQLite episodes table playcounts for unwatched episodes
    episodes = database.get_episode_list(mal_id)
    if episodes:
        for ep_row in episodes:
            if ep_row['number'] >= current_ep:
                try:
                    ep_meta = database.loads(ep_row['kodi_meta'])
                    if ep_meta.get('info', {}).get('playcount') == 1:
                        ep_meta['info']['playcount'] = 0
                        database.update_episode_column(mal_id, ep_row['number'], 'kodi_meta', database.dumps(ep_meta))
                except Exception:
                    pass

    # If target_ep is 0, remove anime from watch history; otherwise update to target_ep
    if target_ep == 0:
        try:
            if control.pathExists(control.watch_history_json):
                with open(control.watch_history_json, 'r', encoding='utf-8') as f:
                    history_data = json.load(f)
                history_data['history'] = [
                    h for h in history_data.get('history', [])
                    if str(h.get('UniqueIDs', {}).get('mal_id') or h.get('mal_id')) != str(mal_id)
                ]
                control.atomic_write_json(control.watch_history_json, history_data)
        except Exception as e:
            control.log(f"Error updating watch history on unwatch: {e}", "warning")
    else:
        try:
            save_to_watch_history(mal_id, target_ep)
        except Exception as e:
            control.log(f"Error saving to watch history: {e}", "warning")

    enabled = control.enabled_watchlists()
    flavor_labels = {'anilist': 'AniList', 'kitsu': 'Kitsu', 'mal': 'MAL', 'simkl': 'Simkl'}
    updated_names = ', '.join([flavor_labels.get(f, f.capitalize()) for f in enabled]) if enabled else 'Local History'

    if len(parts) >= 2:
        control.notify(control.ADDON_NAME, f'Episode #{current_ep} Marked as Unwatched in {updated_names}')
    else:
        title = ''
        if show:
            try:
                title = database.loads(show['kodi_meta']).get('title_userPreferred', '')
            except Exception:
                title = ''
        control.notify(control.ADDON_NAME, f'{title} Marked as Unwatched in {updated_names}')

    folder_path = control.getInfoLabel('Container.FolderPath')
    if 'watchlist_to_ep' in folder_path:
        control.execute(f'Container.Update(plugin://{control.ADDON_ID}/watchlist_to_ep/{mal_id}/{target_ep})')
    else:
        control.execute('Container.Refresh')
    control.exit_code()


@multi_route(*_wildcard_browser_paths('mark_previous_watched'))
def MARK_PREVIOUS_WATCHED(payload, params):
    from resources.lib.WatchlistIntegration import watchlist_update_episode
    import service

    parts = [p for p in payload.strip('/').split('/') if p]
    if len(parts) >= 2:
        mal_id, ep_str = parts[0], parts[1]
    else:
        return
    try:
        target_ep = int(ep_str)
    except (ValueError, TypeError):
        return

    # User confirmation dialog
    show = database.get_show(mal_id)
    title = ''
    if show:
        try:
            kodi_meta = database.loads(show['kodi_meta'])
            title = kodi_meta.get('title_userPreferred', '')
        except Exception:
            title = ''
    anime_label = f" for '{title}'" if title else ""
    confirmed = control.yesno_dialog(
        "Mark Episodes as Watched",
        f"Mark episodes 1 to {target_ep}{anime_label} as watched in your WatchLists and Watch History?"
    )
    if not confirmed:
        return

    # Update watchlist for target_ep (MAL/AniList/Simkl/Kitsu sets progress to target_ep)
    any_completed = watchlist_update_episode(mal_id, target_ep, up_to=True)
    if any_completed:
        if not control.monitor.waitForAbort(3):
            service.sync_watchlist(True)

    # Save to watch history for target_ep
    try:
        save_to_watch_history(mal_id, target_ep)
    except Exception as e:
        control.log(f"Error saving to watch history: {e}", "warning")

    # Invalidate cached eps_watched in kodi_meta so UI repaints playcounts
    if show:
        try:
            kodi_meta = database.loads(show['kodi_meta'])
            kodi_meta['eps_watched'] = target_ep
            database.update_kodi_meta(mal_id, kodi_meta)
        except Exception as e:
            control.log(f"Error updating kodi_meta: {e}", "warning")

    # Also update cached episodes table in SQLite directly
    episodes = database.get_episode_list(mal_id)
    if episodes:
        for ep_row in episodes:
            if ep_row['number'] <= target_ep:
                try:
                    ep_meta = database.loads(ep_row['kodi_meta'])
                    if ep_meta.get('info', {}).get('playcount') != 1:
                        ep_meta.setdefault('info', {})['playcount'] = 1
                        database.update_episode_column(mal_id, ep_row['number'], 'kodi_meta', database.dumps(ep_meta))
                except Exception:
                    pass

    # Build notification showing updated watchlists
    enabled = control.enabled_watchlists()
    flavor_labels = {'anilist': 'AniList', 'kitsu': 'Kitsu', 'mal': 'MAL', 'simkl': 'Simkl'}
    updated_names = ', '.join([flavor_labels.get(f, f.capitalize()) for f in enabled]) if enabled else 'Local History'
    control.notify(control.ADDON_NAME, f"Episodes 1 to {target_ep} Marked as Watched in {updated_names}")

    folder_path = control.getInfoLabel('Container.FolderPath')
    if 'watchlist_to_ep' in folder_path:
        control.execute(f'Container.Update(plugin://{control.ADDON_ID}/watchlist_to_ep/{mal_id}/{target_ep})')
    else:
        control.execute("Container.Refresh")
    control.exit_code()


@Route('playback_options/*')
def PLAYBACK_OPTIONS(payload, params):
    import xbmcgui
    from urllib.parse import urlencode

    # Parse the payload to get mal_id and episode
    if payload and '/' in payload:
        mal_id, episode = payload.split('/', 1)
    else:
        control.log('Invalid payload format', 'error')
        return control.exit_code()

    # Get show information from database to build params
    show = database.get_show(mal_id)
    if show:
        kodi_meta = database.loads(show['kodi_meta'])

        # Build params similar to what get_video_info would return
        episode_params = {
            'mal_id': mal_id,
            'episode': episode,
            'title': kodi_meta.get('title_userPreferred', ''),
            'mediatype': 'episode',
            'tvshowtitle': kodi_meta.get('title_userPreferred', ''),
            'plot': kodi_meta.get('plot', ''),
            'year': str(kodi_meta.get('year', '')),
            'premiered': kodi_meta.get('premiered', ''),
            'season': str(kodi_meta.get('season', 1)),
            'aired': kodi_meta.get('aired', ''),
            'rating': kodi_meta.get('rating', {}),
            'resume': params.get('resume', ''),
            # Artwork
            'poster': kodi_meta.get('poster', ''),
            'tvshow.poster': kodi_meta.get('poster', ''),
            'icon': kodi_meta.get('poster', ''),
            'thumb': kodi_meta.get('thumb', ''),
            'fanart': kodi_meta.get('fanart', ''),
            'landscape': kodi_meta.get('landscape', ''),
            'banner': kodi_meta.get('banner', ''),
            'clearart': kodi_meta.get('clearart', ''),
            'clearlogo': kodi_meta.get('clearlogo', '')
        }
    else:
        # Fallback params if show not found in database
        episode_params = {
            'mal_id': mal_id,
            'episode': episode,
            'title': '',
            'mediatype': 'episode',
            'tvshowtitle': '',
            'plot': '',
            'year': '',
            'premiered': '',
            'season': '1',
            'aired': '',
            'rating': {},
            'resume': params.get('resume', ''),
            # Artwork
            'poster': '',
            'tvshow.poster': '',
            'icon': '',
            'thumb': '',
            'fanart': '',
            'landscape': '',
            'banner': '',
            'clearart': '',
            'clearlogo': ''
        }

    # Ask the user which playback option they want to use
    # Here the button labels are:
    # Button 0: "Cancel"   | Button 1: "Rescrape" | Button 2: "Source Select"
    yesnocustom = control.yesnocustom_dialog(
        control.ADDON_NAME + " - Playback Options",
        "Please choose a playback option:",
        "Cancel", "Source Select", "Rescrape",
        defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
    )

    if yesnocustom == 0:
        # Redirect to play route with source_select parameter
        query_params = urlencode({'source_select': 'true', **episode_params})
        control.playList.clear()
        control.execute(f'RunPlugin(plugin://{control.ADDON_ID}/play/{mal_id}/{episode}?{query_params})')

    elif yesnocustom == 1:
        # Redirect to play route with rescrape parameter
        query_params = urlencode({'rescrape': 'true', **episode_params})
        control.playList.clear()
        control.execute(f'RunPlugin(plugin://{control.ADDON_ID}/play/{mal_id}/{episode}?{query_params})')

    elif yesnocustom == 2:
        # User cancelled, exit without doing anything
        pass

    control.exit_code()
