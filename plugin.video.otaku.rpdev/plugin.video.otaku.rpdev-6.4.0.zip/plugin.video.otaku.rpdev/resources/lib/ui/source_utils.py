import os
import functools
import unicodedata
"""source_utils.py - Source Quality & Filtering Engine
=====================================================
Detects video quality, codec, audio format, and subtitle info from
release titles.  Provides regex-based torrent filtering, fuzzy matching,
and file-selection helpers used by the resolver pipeline.

Sections
--------
Quality & Info Detection   - getQuality, getAudio_lang, getInfo, etc.
Episode Regex              - get_cache_check_reg, convert_to_bytes, get_size
Fuzzy Matching             - get_fuzzy_match, get_best_match
Torrent Filtering          - filter_sources (season / episode / part regex)
Text Cleaning              - remove_patterns, cleanup_text, clean_text, cleanTitle
File Utilities             - is_file_ext_valid, video_ext, user_select, get_embedhost
Chapter Keywords           - CHAPTER_*_KEYWORDS, chapter_title_matches_intro/outro
Filter UI vocabulary       - INFO_STRUCT (codec / HDR / audio / misc tags for filter dialog)
"""

import re
import string
import xbmc


from resources.lib.ui import control

res = ['EQ', '480p', '720p', '1080p', '4k']

# Filter dialog: selectable tags per category (see windows/filter_select.py)
INFO_STRUCT = {
    "videocodec": {
        "AVC", "HEVC", "XVID", "DIVX", "WMV", "MP4", "MPEG", "VP9", "AV1",
    },
    "hdrcodec": {
        "DV", "HDR", "HYBRID", "SDR",
    },
    "audiocodec": {
        "AAC", "DTS", "DTS-HDMA", "DTS-HDHR", "DTS-X", "ATMOS", "TRUEHD",
        "DD+", "DD", "MP3", "WMA", "OPUS",
    },
    "audiochannels": {
        "2.0", "5.1", "7.1",
    },
    "misc": {
        "CAM", "HDTV", "PDTV", "REMUX", "HDRIP", "BLURAY", "DVDRIP", "WEB",
        "HC", "SCR", "3D", "60-FPS", "BATCH"
    },
}


# ═══════════════════════════════════════════════════════════════════════════
#  MKV / container chapter title keywords (ffprobe, optional skip hints)
# ═══════════════════════════════════════════════════════════════════════════
# Substrings are matched case-insensitively. Entries in the *_SHORT_* frozensets
# use word boundaries (\b) to cut false positives (e.g. "op" in "operation").
# Naming varies wildly by muxer; treat matches as hints only — combine with
# time sanity checks and never override AniSkip / AnimeSkip when present.

_CHAPTER_SHORT_INTRO = frozenset({'op', 'op1', 'op2', 'ncop'})
_CHAPTER_SHORT_OUTRO = frozenset({'ed', 'ed1', 'ed2', 'ed3', 'nced', 'pv'})

_RE_CHAPTER_SHORT_INTRO = re.compile(
    r'\b(?:' + '|'.join(re.escape(k) for k in sorted(_CHAPTER_SHORT_INTRO, key=len, reverse=True)) + r')\b',
    re.IGNORECASE
)
_RE_CHAPTER_SHORT_OUTRO = re.compile(
    r'\b(?:' + '|'.join(re.escape(k) for k in sorted(_CHAPTER_SHORT_OUTRO, key=len, reverse=True)) + r')\b',
    re.IGNORECASE
)

# Longer phrases first (checked in order for documentation; matching uses any()).
CHAPTER_INTRO_KEYWORDS = (
    'opening theme',
    'opening sequence',
    'opening animation',
    'opening song',
    'opening credit',
    'opening credits',
    'openning',  # common typo
    'title sequence',
    'title animation',
    'title song',
    'main title',
    'tv opening',
    'tv size op',
    'tv-size op',
    'opening',
    'intro',
    'オープニング',
    'オープニングテーマ',
    '前クレジット',
    'nc op',
)

_CHAPTER_EXPLICIT_OP = (
    'opening theme',
    'opening sequence',
    'opening animation',
    'opening song',
    'opening credit',
    'opening credits',
    'openning',
    'tv opening',
    'tv size op',
    'tv-size op',
    'opening',
    'オープニング',
    'オープニングテーマ',
    '前クレジット',
    'nc op',
)

CHAPTER_OUTRO_KEYWORDS = (
    'ending theme',
    'ending sequence',
    'ending animation',
    'ending song',
    'ending credit',
    'ending credits',
    'end credits',
    'end credit',
    'credit roll',
    'credit sequence',
    'closing theme',
    'closing credits',
    'closing animation',
    'main ending',
    'tv ending',
    'tv size ed',
    'tv-size ed',
    'ending',
    'credits',
    'outro',
    'epilogue',
    'post-credits',
    'post credits',
    'after credits',
    'next episode',
    'next time',
    'next on',
    'web preview',
    'episode preview',
    'preview',
    '予告',
    '次回予告',
    'エンディング',
    'エンディングテーマ',
    'ノンクレジット',
    'nc ed',
)


def chapter_title_matches_intro(title):
    """
    Return True if title looks like an opening / OP chapter (substring / word match).
    """
    return _chapter_title_matches_bucket(title, CHAPTER_INTRO_KEYWORDS, _RE_CHAPTER_SHORT_INTRO)


def chapter_title_matches_outro(title):
    """
    Return True if title looks like an ending / ED / credits / preview chapter.
    """
    return _chapter_title_matches_bucket(title, CHAPTER_OUTRO_KEYWORDS, _RE_CHAPTER_SHORT_OUTRO)


def _chapter_title_matches_bucket(title, phrases, short_tokens):
    t = (title or '').strip().lower()
    if not t:
        return False
    for phrase in phrases:
        if phrase in t:
            return True
    if hasattr(short_tokens, 'search'):
        return bool(short_tokens.search(t))
    for tok in short_tokens:
        if re.search(r'\b' + re.escape(tok) + r'\b', t):
            return True
    return False


def score_intro_chapter(title, duration=0.0):
    """
    Score candidate intro chapter title and duration.
    Higher score indicates higher confidence for being an anime opening theme.
    Returns 0 if title does not match intro criteria.
    """
    if not chapter_title_matches_intro(title):
        return 0

    t = (title or '').strip().lower()
    score = 50

    # Explicit OP keywords receive high base confidence
    for op_kw in _CHAPTER_EXPLICIT_OP:
        if op_kw in t:
            score = 100
            break
    if score < 100:
        if _RE_CHAPTER_SHORT_INTRO.search(t):
            score = 100

    # Standard anime OP duration is ~90s (typically 80-100s)
    if duration > 0:
        diff = abs(duration - 90.0)
        if diff <= 5.0:
            score += 30
        elif diff <= 15.0:
            score += 20
        elif diff <= 30.0:
            score += 10

    return score


# ═══════════════════════════════════════════════════════════════════════════
#  Quality & Info Detection
# ═══════════════════════════════════════════════════════════════════════════

def getAudio_lang(release_title):
    release_title = cleanTitle(release_title)
    if any(i in release_title for i in ['multi audio', 'multi lang', 'multiple audio', 'multiple lang']):
        lang = 0
    elif any(i in release_title for i in ['dual audio']):
        lang = 1
    elif any(i in release_title for i in ['dub', 'dubbed']):
        lang = 3
    else:
        lang = 2
    return lang


def getAudio_channel(release_title):
    release_title = cleanTitle(release_title)
    if any(i in release_title for i in ['2 0 ', '2 0ch', '2ch']):
        channel = 0
    elif any(i in release_title for i in ['5 1 ', '5 1ch', '6ch']):
        channel = 1
    elif any(i in release_title for i in ['7 1 ', '7 1ch', '8ch']):
        channel = 2
    else:
        channel = 3
    return channel


def getSubtitle_lang(release_title):
    release_title = cleanTitle(release_title)
    if any(i in release_title for i in ['multi sub', 'multiple sub']):
        sub = 0
    else:
        sub = 1
    return sub


def getQuality(release_title):
    release_title = release_title.lower()
    if any(i in release_title for i in ['4k', '2160', "216o"]):
        quality = 4
    elif any(i in release_title for i in ["1080", "1o80", "108o", "1o8o"]):
        quality = 3
    elif any(i in release_title for i in ["720", "72o"]):
        quality = 2
    else:
        quality = 1
    return quality


# Tag-detection table: (label, [keywords...])
# Checked in order — first match per label wins.
_INFO_TAGS = (
    # ── Video Codec ──
    ('AVC',         ['x264', 'x 264', 'h264', 'h 264', 'avc']),
    ('HEVC',        ['x265', 'x 265', 'h265', 'h 265', 'hevc']),
    ('XVID',        ['xvid']),
    ('DIVX',        ['divx']),
    ('MP4',         ['mp4']),
    ('WMV',         ['wmv']),
    ('MPEG',        ['mpeg']),
    ('VP9',         ['vp9']),
    ('AV1',         ['av1']),
    ('REMUX',       ['remux', 'bdremux']),
    ('HDR',         [' hdr ', 'hdr10', 'hdr 10', 'uhd bluray 2160p', 'uhd blu ray 2160p',
                     '2160p uhd bluray', '2160p uhd blu ray', '2160p bluray hevc truehd',
                     '2160p bluray hevc dts', '2160p bluray hevc lpcm',
                     '2160p us bluray hevc truehd', '2160p us bluray hevc dts']),
    ('SDR',         [' sdr ']),
    ('DV',          [' dv ', 'dovi', 'dolby vision', 'dolbyvision']),
    # ── Audio Codec ──
    ('AAC',         ['aac']),
    ('DTS',         ['dts']),
    ('DTS-HDMA',    ['hd ma', 'hdma']),
    ('DTS-HDHR',    ['hd hr', 'hdhr', 'dts hr', 'dtshr']),
    ('DTS-X',       ['dtsx', ' dts x']),
    ('ATMOS',       ['atmos']),
    ('TRUEHD',      ['truehd', 'true hd']),
    ('DD+',         ['ddp', 'dd+', 'eac3', ' e ac3', ' e ac 3']),
    ('DD',          [' dd ', 'dd2', 'dd5', 'dd7', ' ac3', ' ac 3']),
    ('MP3',         ['mp3']),
    ('WMA',         [' wma']),
    ('OPUS',        ['opus']),
    ('DUB',         ['dub', 'dubbed']),
    ('DUAL-AUDIO',  ['dual audio']),
    ('MULTI-AUDIO', ['multi audio', 'multi lang', 'multiple audio', 'multiple lang']),
    # ── Channels ──
    ('2.0',         ['2 0 ', '2 0ch', '2ch']),
    ('5.1',         ['5 1 ', '5 1ch', '6ch']),
    ('7.1',         ['7 1 ', '7 1ch', '8ch']),
    # ── Subtitles ──
    ('MULTI-SUB',   ['multi sub', 'multiple sub']),
    # ── Source ──
    ('BLURAY',      ['bluray', 'blu ray', 'bdrip', 'bd rip', 'brrip', 'br rip']),
    ('WEB',         [' web ', 'webrip', 'webdl', 'web rip', 'web dl']),
    ('HDRIP',       [' hdrip', ' hd rip']),
    ('DVDRIP',      ['dvdrip', 'dvd rip']),
    ('HDTV',        ['hdtv']),
    ('PDTV',        ['pdtv']),
    ('CAM',         [' cam ', 'camrip', 'hdcam', 'hd cam', ' ts ', 'hd ts', 'hdts',
                     'telesync', ' tc ', 'hd tc', 'hdtc', 'telecine', 'xbet']),
    ('SCR',         ['dvdscr', ' scr ', 'screener']),
    ('HC',          ['korsub', ' kor ', ' hc']),
    ('BLUR',        ['blurred']),
    ('3D',          [' 3d', ' half ou', ' half sbs']),
    ('60-FPS',      [' 60 fps', ' 60fps']),
    # ── Batch ──
    ('BATCH',       ['batch', 'complete series', 'complete season', 'entire series', 'all episodes', 'season pack', 'series pack', 'full season', 'whole series']),
)


def getInfo(release_title):
    release_title = cleanTitle(release_title)
    return [label for label, keywords in _INFO_TAGS
            if any(kw in release_title for kw in keywords)]


# ═══════════════════════════════════════════════════════════════════════════
#  Episode Regex & Size Helpers
# ═══════════════════════════════════════════════════════════════════════════

@functools.lru_cache(maxsize=128)
def _compile_cache_check_reg(episode_str):
    season = ''
    reg_string = r'''(?ix)                              # Ignore case (i), and use verbose regex (x)
                 (?:                                    # non-grouping pattern
                   s|season                             # s or season
                   )?
                 ({})?                                  # season num format
                 (?:                                    # non-grouping pattern
                   e|x|episode|ep|ep\.|_|-|\(           # e or x or episode or start of a line
                   )                                    # end non-grouping pattern
                 \s*                                    # 0-or-more whitespaces
                 (?<![\d])
                 ({}|{}|{})                             # episode num format: xx or xxx or xxxx
                 (?![\d])
                 '''.format(season, episode_str.zfill(2), episode_str.zfill(3), episode_str.zfill(4))
    return re.compile(reg_string)


def get_cache_check_reg(episode):
    return _compile_cache_check_reg(str(episode))


def convert_to_bytes(size, units):
    unit = (units or '').upper().replace('IB', 'B')
    if unit == 'B':
        byte_size = size
    elif unit == 'KB':
        byte_size = size * 2**10
    elif unit == 'MB':
        byte_size = size * 2**20
    elif unit == 'GB':
        byte_size = size * 2**30
    elif unit == 'TB':
        byte_size = size * 2**40
    else:
        raise ValueError("Unit must be 'B', 'KB', 'MB', 'GB', 'TB'")
    return byte_size


def get_size(size=0):
    power = 1024.0
    n = 0
    power_labels = {0: 'B', 1: 'KB', 2: 'MB', 3: 'GB', 4: 'TB'}
    while size > power and n < 4:
        size /= power
        n += 1
    return '{0:.2f} {1}'.format(size, power_labels[n])


# ═══════════════════════════════════════════════════════════════════════════
#  Title Scoring & Isolation
# ═══════════════════════════════════════════════════════════════════════════

APPROVED_DESCRIPTORS = frozenset({
    'dub', 'dubbed', 'sub', 'subbed', 'tv', 'movie', 'film', 'ova', 'ona',
    'special', 'specials', 'dual', 'audio', 'multi', 'uncut', 'censored',
    'uncensored', 'remastered', 'edition', 'bd', 'dvd', 'complete', 'series'
})

_RE_DESCRIPTOR_TAGS = re.compile(
    r'\b(dub|dubbed|sub|subbed|tv|movie|film|ova|ona|dual\s*audio)\b',
    re.IGNORECASE
)


def _has_descriptor_tags(text):
    return bool(_RE_DESCRIPTOR_TAGS.search(str(text)))


_RE_SEASON_TAG = re.compile(
    r'(?:^|[\W_])(?:season[._\s]*0*(\d+)(?=[\W_]|$)|(\d+)(?:st|nd|rd|th)[._\s]+season(?=[\W_]|$)|s0*(\d+)(?=[\W_]|e\d|$))',
    re.IGNORECASE,
)
_RE_SEASON_RANGE = re.compile(
    r'(?:^|[\W_])(?:s0*(\d+)\s*[-~]\s*s?0*(\d+)|season[._\s]*0*(\d+)\s*[-~]\s*0*(\d+))(?=[\W_]|$)',
    re.IGNORECASE,
)
_RE_STRIP_SEASON_MARKER = re.compile(
    r'(?:^|[\W_])(?:season[._\s]*0*\d+(?=[\W_]|$)|\d+(?:st|nd|rd|th)[._\s]+season(?=[\W_]|$)|s0*\d+(?:e\d+(?:v\d+)?)?(?=[\W_]|$))',
    re.IGNORECASE,
)


def parse_query_titles(query):
    """Split top-level '(Title1)|(Title2)' query strings without breaking nested parentheses like '(TV)'."""
    if not query:
        return []
    text = str(query).strip()
    parts = []
    depth = 0
    start = 0
    for idx, ch in enumerate(text):
        if ch == '(':
            depth += 1
        elif ch == ')':
            if depth > 0:
                depth -= 1
        elif ch == '|' and depth == 0:
            seg = text[start:idx].strip()
            if seg:
                parts.append(seg)
            start = idx + 1
    tail = text[start:].strip()
    if tail:
        parts.append(tail)

    seen = set()
    unique = []
    for part in parts:
        # Unwrap matching outer parentheses only if they wrap the entire segment
        while len(part) >= 2 and part[0] == '(' and part[-1] == ')':
            inner_depth = 0
            wraps_whole = True
            for i, ch in enumerate(part):
                if ch == '(':
                    inner_depth += 1
                elif ch == ')':
                    inner_depth -= 1
                    if inner_depth == 0 and i < len(part) - 1:
                        wraps_whole = False
                        break
            if wraps_whole and inner_depth == 0:
                part = part[1:-1].strip()
            else:
                break
        if part and part.lower() not in seen:
            seen.add(part.lower())
            unique.append(part)
    return unique


def filter_sources_by_audio(sources, source_pref):
    """
    Filter a source list according to general.source (0=Both, 1=Sub, 2=Dub).
    Evaluates info tags across the entire release rather than token-by-token so
    Dual-Audio / Multi-Audio releases that also carry MULTI-SUB tags are preserved.
    """
    try:
        pref = int(source_pref or 0)
    except (ValueError, TypeError):
        pref = 0
    if pref == 0 or not sources:
        return list(sources) if sources else []

    filtered = []
    for item in sources:
        lang = item.get('lang')
        info_upper = [str(t).upper() for t in (item.get('info') or [])]
        has_dual_or_multi = any(
            'DUAL' in t or 'MULTI-AUDIO' in t or 'MULTI AUDIO' in t
            for t in info_upper
        )
        has_dub_tag = any('DUB' in t for t in info_upper)
        has_sub_tag = any('SUB' in t for t in info_upper)

        if pref == 1:
            # Subtitles only: allow Sub (2), Dual (1), Multi-Audio (0); exclude pure Dub
            if lang not in (0, 1, 2):
                continue
            if has_dub_tag and lang not in (0, 1) and not has_dual_or_multi and not has_sub_tag:
                continue
            filtered.append(item)
        elif pref == 2:
            # Dubbed only: allow Dub (3), Dual (1), Multi-Audio (0); exclude pure Sub
            if lang not in (0, 1, 3):
                continue
            if has_sub_tag and lang not in (1, 3) and not has_dub_tag and not has_dual_or_multi:
                continue
            filtered.append(item)
        else:
            filtered.append(item)
    return filtered


def _extract_season_numbers(text):
    """Extract all explicit integer season numbers referenced in text (ranges expanded)."""
    seasons = set()
    s_text = str(text)
    for m in _RE_SEASON_RANGE.finditer(s_text):
        g1, g2 = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), m.group(4))
        try:
            lo, hi = int(g1), int(g2)
            if 1 <= lo <= hi <= 50:
                seasons.update(range(lo, hi + 1))
        except (ValueError, TypeError):
            pass
    for m in _RE_SEASON_TAG.finditer(s_text):
        val = m.group(1) or m.group(2) or m.group(3)
        try:
            num = int(val)
            if num >= 1:
                seasons.add(num)
        except (ValueError, TypeError):
            pass
    return seasons


def isolate_show_title(raw_title):
    """
    Isolate the release show title from a raw filename or candidate title by
    stripping release groups ([...]), resolutions (1080p, 720p), video/audio
    codecs, episode numbering, and file extensions (.mkv, .mp4).
    """
    if not raw_title:
        return ''

    text = str(raw_title).strip()

    # 1. Strip file extension
    text = re.sub(
        r'\.(?:mkv|mp4|avi|mov|wmv|m4v|webm|flv|ts|m2ts|mts|ogv|vob)$',
        '',
        text,
        flags=re.IGNORECASE
    )

    # 1b. Strip trailing truncated/unclosed bracketed or parenthesized fragment
    #     (e.g. Torrentio 60-char "(B…" or "[BDRip-1080p-8bit")
    text = re.sub(r'\s*[\(\[][^\)\]]*$', '', text)

    # 2. Strip leading bracketed/parenthesized release group tags and leading dot separator
    text = re.sub(r'^(?:\s*\[[^\]]*\]|\s*\([^\)]*\))+', '', text).lstrip('. ').strip()

    # 3. Handle dot-separated/scene format: e.g. "Monster.S01E01.1080p" or "Show - S01E02v2"
    scene_match = re.search(
        r'^(.*?)[._ -]+(?:s\d{1,2}(?:[._ -]?e\d{1,4}(?:v\d+)?)?|e\d{1,4}(?:v\d+)?|season[._ -]?\d{1,2})(?:[._ -]|$)',
        text,
        flags=re.IGNORECASE
    )
    if scene_match and scene_match.group(1):
        candidate = scene_match.group(1).replace('.', ' ').replace('_', ' ').strip()
        if candidate:
            text = candidate
    else:
        # 4. Segment at episode marker separating show title from episode number / episode title
        ep_split = re.split(
            r'''(?ix)
            \s+-\s+(?:ep(?:isode)?\s*|e\s*)?\d{1,4}(?:\b|v\d)
            |
            \s+-\s+s\d{1,2}(?:\s*-\s*\d{1,4}|\s*e\d{1,4}(?:v\d+)?)\b
            |
            \s+(?:s\d{1,2})?e\d{1,4}(?:v\d+)?\b
            |
            \s+(?:ep(?:isode)?\s*)\d{1,4}(?:v\d+)?\b
            |
            \s+-\s+part\s+\d+\s+-\s+\d{1,4}\b
            ''',
            text
        )
        if len(ep_split) > 1 and ep_split[0].strip():
            text = ep_split[0].strip()
        else:
            # Fallback: check if ends with standalone episode number followed by brackets/parens/metadata
            m = re.match(
                r'^(.*?)[._\s]+\d{1,4}(?:v\d)?(?:[._\s]+|\s*\[|\s*\()(?:360p|480p|720p|1080p|2160p|4k|bdrip|bluray|web-dl|webrip|dvdrip|hdtv|x264|x265|hevc|av1)',
                text,
                flags=re.IGNORECASE
            )
            if m and m.group(1).strip():
                cand = m.group(1).strip()
                if '.' in cand and ' ' not in cand:
                    cand = cand.replace('.', ' ')
                text = cand

    # 4b. Strip batch episode ranges (e.g. "Show 1-10+OVA Complete", "Show 01-12 [1080p]")
    batch_range_match = re.match(
        r'^(.*?)(?:\s+-\s+|\s+)(?:ep(?:isodes?)?\s*)?\d{1,3}\s*[-~]\s*\d{1,4}'
        r'(?:\s*\+\s*.*|\s+(?:complete|batch|bd|bdrip|bluray|dvd|dual|sub|dub|eng|multi|raw|uncensored|remastered|v\d+|360p|480p|720p|1080p|2160p|4k|x264|x265|hevc|av1|hi10|10bit|8bit|flac|aac)\b.*|\s*[\[\(].*|$)',
        text,
        flags=re.IGNORECASE,
    )
    if batch_range_match and batch_range_match.group(1).strip():
        text = batch_range_match.group(1).strip()

    # 5. Strip release-version suffix adjacent to bracketed tags (e.g. "(Season 1) V2 [1080p]")
    text = re.sub(r'(?<=[\)\]])\s+v[2-9]\b(?=\s*(?:\[|\(|$))', '', text, flags=re.IGNORECASE)

    # 6. Remove media patterns (resolution, codecs, etc.) and bracketed text
    text = remove_patterns(text)
    text = _RE_BRACKETS_AND_PARENS.sub('', text)
    text = _RE_COLLAPSE_SPACES.sub(' ', text).strip()

    # 6b. Strip bundled "+ OVA" / "+ Special" extras after bracket stripping so
    #     bracketed tags like "[Season 1 + OVA]" are already removed intact,
    #     while standalone "- OVA" titles remain untouched.
    plus_extra_match = re.match(
        r'^(.*?)\s*\+\s*(?:(?:ova|oav|special|extra|movie|ncop|nced|ona)s?\b.*|.*?\b(?:ova|oav|special|extra)s?\b.*)$',
        text,
        flags=re.IGNORECASE,
    )
    if plus_extra_match and plus_extra_match.group(1).strip():
        text = plus_extra_match.group(1).strip()

    # 7. Strip trailing standalone batch/media markers (e.g. ": Complete", "Complete", "Batch", "BD")
    while True:
        stripped = re.sub(
            r'(?::\s*|\s+)(?:complete(?:\s+series)?|batch|bd|bdrip|bdremux|bluray|blu-ray|dvdrip|web-dl|webrip|hdtv)\s*$',
            '',
            text,
            flags=re.IGNORECASE,
        ).strip()
        if not stripped or stripped == text:
            break
        text = stripped

    return text


def clean_title_for_matching(title):
    """
    Clean title for matching:
    Strips bracketed metadata, release groups, resolutions, codecs, file extensions,
    and normalizes punctuation while preserving distinct words and prefix boundaries.
    """
    if not title:
        return ''
    isolated = isolate_show_title(title)
    if not isolated:
        isolated = str(title)
    return cleanTitle(isolated)


def _score_single_candidate(target_list, candidate_title, passed_year=None, release_year=None, release_seasons=None, release_has_desc=None):
    """Score a single (or pipe-segment) candidate string against normalized target/alias entries."""
    cand_isolated = isolate_show_title(candidate_title) or str(candidate_title)
    cand_clean = cleanTitle(cand_isolated)
    cand_tokens = cand_clean.split()
    if not cand_tokens:
        return 0

    best_score = 0
    raw_cand_lower = str(candidate_title).lower()
    raw_cand_isolated_lower = str(cand_isolated).lower()

    cand_year = release_year
    if cand_year is None:
        cand_year_match = re.search(r'\b(19\d{2}|20\d{2})\b', str(candidate_title))
        cand_year = cand_year_match.group(1) if cand_year_match else None

    cand_seasons = release_seasons if release_seasons is not None else _extract_season_numbers(raw_cand_lower)
    cand_sequel_seasons = {s for s in cand_seasons if s >= 2}
    cand_has_desc = release_has_desc if release_has_desc is not None else _has_descriptor_tags(candidate_title)

    cand_stripped_clean = cleanTitle(re.sub(r'[\(\[]?\b(19\d{2}|20\d{2})\b[\)\]]?', '', str(cand_isolated)))
    cand_no_season_clean = cleanTitle(_RE_STRIP_SEASON_MARKER.sub('', str(cand_isolated)))

    for target, is_canonical in target_list:
        target_year_match = re.search(r'\b(19\d{2}|20\d{2})\b', str(target))
        target_year = passed_year or (target_year_match.group(1) if target_year_match else None)

        target_clean = cleanTitle(target)
        target_tokens = target_clean.split()
        if not target_tokens:
            continue

        raw_target_lower = str(target).lower()
        target_has_desc = _has_descriptor_tags(target)

        # Disqualify derivative prefix mismatch (e.g. "Re:Monster" vs "Monster")
        target_has_re = raw_target_lower.startswith(('re:', 're-', 're ')) or (target_tokens and target_tokens[0] == 're')
        cand_has_re = (
            raw_cand_lower.startswith(('re:', 're-', 're '))
            or raw_cand_isolated_lower.startswith(('re:', 're-', 're '))
            or (cand_tokens and cand_tokens[0] == 're')
        )
        if cand_has_re != target_has_re:
            continue

        # Disqualify other derivative prefixes
        prefix_mismatch = False
        for pfx in ('shin ', 'new ', 'gekijouban '):
            if (raw_cand_isolated_lower.startswith(pfx) or raw_cand_lower.startswith(pfx)) != raw_target_lower.startswith(pfx):
                prefix_mismatch = True
                break
        if prefix_mismatch:
            continue

        # Explicit year mismatch
        if target_year and cand_year and target_year != cand_year:
            continue

        # Disqualify mismatched sequel seasons (S01 / Season 01 stays eligible for Season 1)
        target_seasons = _extract_season_numbers(raw_target_lower)
        target_sequel_seasons = {s for s in target_seasons if s >= 2}
        target_isolated = isolate_show_title(target) or str(target)
        target_no_season_clean = cleanTitle(_RE_STRIP_SEASON_MARKER.sub('', str(target_isolated)))
        has_exact_arc_subtitle = (
            ' - ' in str(target)
            and bool(cand_no_season_clean)
            and cand_no_season_clean == target_no_season_clean
        )
        if cand_sequel_seasons and not target_sequel_seasons and not has_exact_arc_subtitle:
            continue
        if target_sequel_seasons and cand_seasons and not (cand_seasons & target_sequel_seasons):
            continue

        # Disqualify live-action adaptation when query is anime
        if ('live action' in raw_cand_lower or 'live-action' in raw_cand_lower) and ('live action' not in raw_target_lower and 'live-action' not in raw_target_lower):
            continue

        target_stripped_clean = cleanTitle(re.sub(r'[\(\[]?\b(19\d{2}|20\d{2})\b[\)\]]?', '', str(target)))
        target_isolated_clean = cleanTitle(target_isolated)

        # Equivalent forms when both target and candidate explicitly match the same sequel season (>= 2)
        same_sequel_season = bool(
            target_sequel_seasons
            and cand_sequel_seasons
            and (cand_sequel_seasons & target_sequel_seasons)
            and cand_no_season_clean == target_no_season_clean
        )

        # Exact normalized match (including year-stripped, space-collapsed compound Romaji, and season-normalized)
        cand_flat = cand_clean.replace(' ', '')
        target_flat = target_clean.replace(' ', '')
        cand_stripped_flat = cand_stripped_clean.replace(' ', '')
        target_stripped_flat = target_stripped_clean.replace(' ', '')
        is_exact = (cand_clean == target_clean) or (
            not target_sequel_seasons and cand_clean == target_isolated_clean
        ) or (
            same_sequel_season and bool(cand_no_season_clean)
        ) or (
            target_year and cand_year and target_year == cand_year and target_stripped_clean == cand_stripped_clean
        ) or (
            target_year and not cand_year and target_stripped_clean == cand_clean
        ) or (
            cand_year and not target_year and target_clean == cand_stripped_clean
        ) or (
            len(cand_flat) >= 6 and (
                cand_flat == target_flat
                or cand_flat == target_isolated_clean.replace(' ', '')
                or (cand_stripped_flat and cand_stripped_flat == target_stripped_flat)
            )
        )

        # Single-article typo match (e.g. "a Otaku" vs "an Otaku") on multi-word titles (>= 4 tokens)
        if not is_exact and len(target_tokens) >= 4 and len(cand_tokens) == len(target_tokens):
            diffs = [(ct, tt) for ct, tt in zip(cand_tokens, target_tokens) if ct != tt]
            if diffs and all(pair in {('a', 'an'), ('an', 'a')} for pair in diffs):
                is_exact = True

        if is_exact:
            if (cand_has_desc and not target_has_desc) or (target_has_desc and not cand_has_desc):
                score = 125 if is_canonical else 115
            else:
                score = 150 if is_canonical else 140
            if target_year and cand_year and target_year == cand_year:
                score += 10
            best_score = max(best_score, score)
            continue

        # Unexpected & missing tokens check excluding approved descriptors
        raw_unexpected = [tok for tok in cand_tokens if tok not in target_tokens]
        raw_missing = [tok for tok in target_tokens if tok not in cand_tokens]
        unexpected = raw_unexpected
        missing = [tok for tok in raw_missing if tok not in ('tv', 'movie', 'film', 'dub', 'sub')]

        if not unexpected and not missing:
            if not raw_unexpected and not raw_missing:
                score = 150 if is_canonical else 140
            else:
                score = 125 if is_canonical else 115
            best_score = max(best_score, score)
            continue

        # For short queries (<= 2 tokens), check derivative expansion
        if len(target_tokens) <= 2:
            if set(target_tokens).issubset(set(cand_tokens)):
                best_score = max(best_score, 10 if is_canonical else 0)
                continue
            else:
                continue

        # Multi-token titles (> 2 tokens): reject derivative spin-offs / mismatched titles
        if unexpected or missing:
            has_common = bool(set(target_tokens) & set(cand_tokens))
            best_score = max(best_score, 10 if (is_canonical and has_common) else 0)
            continue

    return best_score


def score_title_candidate(query, candidate_title, aliases=None, year=None):
    """
    Clean, robust, reusable candidate scoring function for all scrapers.
    Returns an integer score from 0 to 200.
    - Score >= 140 for exact canonical or alias matches (case-insensitive, normalized).
    - Score >= 110 for matches with valid release descriptor tags ((Dub), (Sub), (TV), (Movie)).
    - Score <= 40 or 0 for derivative titles (e.g. Re:Monster when query is Monster, Monster Musume, etc.).
    - Supports alias matching against Japanese/Romaji and English variations.
    """
    if not query or not candidate_title:
        return 0

    target_list = [(query, True)]
    if aliases:
        for a in aliases:
            if a and str(a).strip() and str(a).strip() != query:
                target_list.append((str(a).strip(), False))

    raw_cand = str(candidate_title)
    passed_year = str(year).strip() if year else None

    cand_year_match = re.search(r'\b(19\d{2}|20\d{2})\b', raw_cand)
    release_year = cand_year_match.group(1) if cand_year_match else None
    release_seasons = _extract_season_numbers(raw_cand.lower())
    release_has_desc = _has_descriptor_tags(raw_cand)

    best_score = _score_single_candidate(
        target_list, raw_cand, passed_year=passed_year,
        release_year=release_year, release_seasons=release_seasons, release_has_desc=release_has_desc,
    )

    if '|' in raw_cand:
        for seg in raw_cand.split('|'):
            seg = seg.strip()
            if seg:
                seg_score = _score_single_candidate(
                    target_list, seg, passed_year=passed_year,
                    release_year=release_year, release_seasons=release_seasons, release_has_desc=release_has_desc,
                )
                if seg_score > best_score:
                    best_score = seg_score

    return min(200, max(0, best_score))


# ═══════════════════════════════════════════════════════════════════════════
#  Fuzzy Matching
# ═══════════════════════════════════════════════════════════════════════════

def get_fuzzy_match(query, filenames):
    """
    Multi-stage fuzzy matching for torrent/file selection.
    Uses local algorithms for accuracy and speed (no external API dependency).

    Returns: List of indices that match the query, sorted by best match first
    """
    from difflib import SequenceMatcher

    if not query or not filenames:
        return []

    if '|' in str(query):
        titles = [t.strip() for t in re.findall(r'\(([^)]+)\)', str(query)) if t.strip()]
        if not titles:
            titles = [t.strip('() ') for t in str(query).split('|') if t.strip('() ')]
        if len(titles) > 1:
            merged = []
            for t in titles:
                for idx in get_fuzzy_match(t, filenames):
                    if idx not in merged:
                        merged.append(idx)
            return merged

    # Normalize query for matching
    query_isolated = isolate_show_title(query) or str(query)
    query_clean = cleanTitle(query_isolated)
    query_tokens = query_clean.split()
    if not query_tokens:
        query_clean = cleanTitle(query)
        query_tokens = query_clean.split()
        if not query_tokens:
            return []

    query_lower = query.lower()
    query_iso_lower = query_isolated.lower()
    is_short_query = (len(query_tokens) <= 2)
    query_has_re = query_lower.startswith(('re:', 're-', 're ')) or (query_tokens and query_tokens[0] == 're')

    query_year_match = re.search(r'\b(19\d{2}|20\d{2})\b', str(query))
    query_year = query_year_match.group(1) if query_year_match else None

    # Pre-parse candidate show titles
    candidates = []
    for i, filename in enumerate(filenames):
        cand_isolated = isolate_show_title(filename) or str(filename)
        cand_clean = cleanTitle(cand_isolated)
        cand_tokens = cand_clean.split()
        cand_lower = str(filename).lower()
        cand_iso_lower = cand_isolated.lower()

        # Disqualify derivative prefix mismatch (e.g. Re:Monster vs Monster)
        cand_has_re = (
            cand_lower.startswith(('re:', 're-', 're '))
            or cand_iso_lower.startswith(('re:', 're-', 're '))
            or (cand_tokens and cand_tokens[0] == 're')
        )
        if cand_has_re != query_has_re:
            continue

        # Disqualify live-action adaptation when query is anime
        if ('live action' in cand_lower or 'live-action' in cand_lower) and ('live action' not in query_lower and 'live-action' not in query_lower):
            continue

        # Explicit year mismatch
        cand_year_match = re.search(r'\b(19\d{2}|20\d{2})\b', str(filename))
        cand_year = cand_year_match.group(1) if cand_year_match else None
        if query_year and cand_year and query_year != cand_year:
            continue

        # Disqualify other derivative prefixes
        prefix_mismatch = False
        for pfx in ('shin ', 'new ', 'gekijouban '):
            if (cand_iso_lower.startswith(pfx) or cand_lower.startswith(pfx)) != query_lower.startswith(pfx):
                prefix_mismatch = True
                break
        if prefix_mismatch:
            continue

        # For short queries (<= 2 tokens), disqualify unapproved derivative expansions
        if is_short_query:
            if not set(query_tokens).issubset(set(cand_tokens)):
                continue
            unexpected = [tok for tok in cand_tokens if tok not in query_tokens and tok not in APPROVED_DESCRIPTORS]
            if unexpected:
                # Disqualify unapproved derivative expansion (e.g. Monster Musume, Monster Hunter Stories)
                continue

        candidates.append((i, filename, cand_isolated, cand_clean, cand_tokens))

    if not candidates:
        control.log(f"Fuzzy Match: No candidates passed title pre-filtering for '{query}'")
        return []

    # Stage 1: Exact match (normalized title token equality or strict descriptor match)
    exact_matches = []
    for i, filename, cand_isolated, cand_clean, cand_tokens in candidates:
        if cand_clean == query_clean:
            exact_matches.append((i, 1.0))
        elif set(query_tokens) == (set(cand_tokens) - APPROVED_DESCRIPTORS):
            exact_matches.append((i, 0.98))

    if exact_matches:
        exact_matches.sort(key=lambda x: x[1], reverse=True)
        control.log(f"Fuzzy Match: Found {len(exact_matches)} exact matches for '{query}'")
        return [i for i, _ in exact_matches]

    # Stage 2: Token-based matching (operates on isolated clean show title)
    query_tokens_set = set(query_tokens)
    token_matches = []

    for i, filename, cand_isolated, cand_clean, cand_tokens in candidates:
        cand_tokens_set = set(cand_tokens)
        common_tokens = query_tokens_set & cand_tokens_set
        if common_tokens:
            jaccard = len(common_tokens) / len(query_tokens_set | cand_tokens_set)
            coverage = len(common_tokens) / len(query_tokens_set)
            unexpected = [t for t in (cand_tokens_set - query_tokens_set) if t not in APPROVED_DESCRIPTORS]
            penalty = 0.2 * len(unexpected)
            score = (jaccard * 0.4) + (coverage * 0.6) - penalty

            if score >= 0.5:
                token_matches.append((i, score))

    if token_matches:
        token_matches.sort(key=lambda x: x[1], reverse=True)
        control.log(f"Fuzzy Match: Found {len(token_matches)} token matches for '{query}' (best: {token_matches[0][1]:.2f})")
        return [i for i, _ in token_matches]

    # Stage 3: Sequence matching (operates on isolated clean show title)
    sequence_matches = []
    threshold = control.getInt('general.fuzzy') / 100.0 if control.getInt('general.fuzzy') > 0 else 0.6

    for i, filename, cand_isolated, cand_clean, cand_tokens in candidates:
        ratio = SequenceMatcher(None, query_clean, cand_clean).ratio()
        if ratio >= threshold:
            sequence_matches.append((i, ratio))

    if sequence_matches:
        sequence_matches.sort(key=lambda x: x[1], reverse=True)
        control.log(f"Fuzzy Match: Found {len(sequence_matches)} sequence matches for '{query}' (best: {sequence_matches[0][1]:.2f})")
        return [i for i, _ in sequence_matches]

    # Stage 4: Fallback - Close matches on isolated clean show title
    fallback_matches = []

    for i, filename, cand_isolated, cand_clean, cand_tokens in candidates:
        ratio1 = SequenceMatcher(None, query_clean, cand_clean).ratio()
        ratio2 = SequenceMatcher(None, query_lower, cand_isolated.lower()).ratio()
        max_ratio = max(ratio1, ratio2)

        if max_ratio >= 0.4:
            fallback_matches.append((i, max_ratio))

    if fallback_matches:
        fallback_matches.sort(key=lambda x: x[1], reverse=True)
        control.log(f"Fuzzy Match: Found {len(fallback_matches)} fallback matches for '{query}' (best: {fallback_matches[0][1]:.2f})")
        return [i for i, _ in fallback_matches[:10]]

    # No matches found
    control.log(f"Fuzzy Match: No matches found for '{query}'")
    return []


_RE_SQUARE_BRACKETS = re.compile(r'\[.*?\]')


def get_best_match(dict_key, dictionary_list, episode, pack_select=False, filename=None):
    control.setBool('best_match', True)
    regex = get_cache_check_reg(episode)
    files = []
    for i in dictionary_list:
        path = _RE_SQUARE_BRACKETS.sub('', i[dict_key].split('/')[-1])
        if not is_file_ext_valid(path):
            continue
        if filename and filename in i.get(dict_key, ''):
            return i
        i['regex_matches'] = regex.findall(path)
        files.append(i)
    if pack_select:
        files = user_select(files, dict_key)
    else:
        files = [i for i in files if len(i['regex_matches']) > 0]
        if len(files) == 0:
            control.setBool('best_match', False)
            return {dict_key: '', 'path': ''}
        files = sorted(files, key=lambda x: len(' '.join(list(x['regex_matches'][0]))), reverse=True)
        if len(files) != 1:
            files = user_select(files, dict_key)

    if not files or not files[0] or (not files[0].get(dict_key) and not files[0].get('path')):
        control.setBool('best_match', False)
        return {dict_key: '', 'path': ''}

    return files[0]


# ═══════════════════════════════════════════════════════════════════════════
#  Torrent Filtering
# ═══════════════════════════════════════════════════════════════════════════

UNVERIFIED_TAG = 'UNVERIFIED-SEASON'
_ID_BASED_PROVIDERS = {'torrentio'}

_RE_FILTER_SEASON = re.compile(r"(?i)\b(?:s(?:eason)?[ ._-]?(\d{1,2}))(?!\d)")
_RE_FILTER_ORDINAL_SEASON = re.compile(r"(?i)\b(\d{1,2})(?:st|nd|rd|th)[ ._-]+season\b")
_RE_FILTER_SEASON_PACK = re.compile(r"(?i)\b(?:seasons?[ ._-]?\d{1,2}[~-]\d{1,2}|s\d{1,2}\s*[~-]\s*s\d{1,2})(?!\d)")
_RE_FILTER_EPISODE = re.compile(r"""(?ix)
    (?:^|[\s._-])                     # separator
    (?:e(?:p)?\s?(\d{1,4})(?:v\d+)?\b) # E12, EP12, E12v2
    |
    -\s?(\d{1,4})(?:v\d+)?\b          # - 12, - 02v2
    |
    \b(?:episode|ep|e)\s?(\d{1,4})(?:v\d+)?\b # ep 03, ep 03v2
    |
    s\d{1,2}e(\d{1,4})(?:v\d+)?\b     # s01e07, s01e07v2
    |
    (\d{1,4})\s+(\d{1,4})             # standalone episode range
""")
_RE_FILTER_EPISODE_RANGE = re.compile(r"(\d{1,4})\s*[~\-]\s*(\d{1,4})")
_RE_FILTER_PART = re.compile(r"(?i)\b(?:part|cour)[ ._-]?(\d+)(?:[&-](\d+))?\b")
_RE_FILTER_TRAILING_NUMBER = re.compile(r"""(?ix)
    \b(?:[a-z]{3,})\s+(\d{1,3})\b
""")
_RE_FILTER_ORDINAL_CHECK = re.compile(r"\b\d+(?:st|nd|rd|th)\b", re.IGNORECASE)
_RE_FILTER_S_E = re.compile(r"s\d{1,2}e(\d{1,4})", re.IGNORECASE)
_RE_BTIH_HASH = re.compile(r'btih:(.*?)(?:&|$)', re.IGNORECASE)


def filter_kwargs(hints):
    """filter_sources keyword arguments from a scrape's hints."""
    hints = hints or {}
    return {
        'season_source': hints.get('season_source'),
        'absolute_episode': hints.get('absolute_episode'),
    }


def get_release_info(res):
    """getInfo for a scraped release, flagging a season the filter could not confirm."""
    info = getInfo(res.get('name') or res.get('release_title') or '')
    if res.get('relaxed'):
        info.append(UNVERIFIED_TAG)
    return info


def expand_sequel_season_aliases(target_title, aliases, season):
    """For sequel seasons (season >= 2) with arc subtitles (e.g. 'Blue Exorcist: Beyond the Snow Saga'),
    append '<Title> Season N' and '<Franchise Base> Season N' aliases so season-numbered releases
    ('Blue Exorcist S04', '[TRC] Blue Exorcist - S04') match cleanly while Season 1 stays isolated.
    """
    out = list(aliases) if aliases else []
    try:
        season_int = int(season) if season is not None and str(season).isdigit() else None
    except (ValueError, TypeError):
        season_int = None
    if not season_int or season_int < 2:
        return out

    seen = {str(target_title).strip().lower()} if target_title else set()
    for a in out:
        if isinstance(a, str) and a.strip():
            seen.add(a.strip().lower())

    def _add(val):
        cleaned = (val or '').strip()
        if cleaned and cleaned.lower() not in seen:
            seen.add(cleaned.lower())
            out.append(cleaned)

    seed_titles = ([target_title] if target_title else []) + list(out)
    for t in seed_titles:
        if not isinstance(t, str):
            continue
        t_clean = t.strip()
        if not t_clean:
            continue
        if f"season {season_int}" not in t_clean.lower():
            _add(f"{t_clean} Season {season_int}")
        base = None
        if ':' in t_clean:
            base = t_clean.split(':', 1)[0].strip()
        elif ' - ' in t_clean:
            base = t_clean.split(' - ', 1)[0].strip()
        if base and len(base) >= 3:
            _add(f"{base} Season {season_int}")
    return out


def filter_sources(provider, torrent_list, mal_id, season=None, episode=None, part=None, anidb_id=True, show_title=None, aliases=None, season_source=None, absolute_episode=None):
    from resources.lib.ui import database
    """
    Filter torrents based on season, episode, and part information.
    Uses improved regex patterns to handle a wider variety of media title formats.
    When show_title or aliases are provided, validates release titles to reject
    derivative or unrelated torrents.
    """
    # Check for Large Animes or Tvdb Animes with season 0
    if season == 1:
        mal_mapping = database.get_mappings(mal_id, 'mal_id')
        if mal_mapping and 'thetvdb_season' in mal_mapping:
            thetvdb_season = mal_mapping['thetvdb_season']
            if thetvdb_season == 'a' or thetvdb_season == 0:
                season = None

    merged_aliases = list(aliases) if aliases else []
    if mal_id and (show_title or merged_aliases):
        seen_a = {str(a).strip().lower() for a in merged_aliases if a}
        try:
            for db_alias in (database.get_mapping_aliases(mal_id, limit=8) or []):
                s_alias = str(db_alias or '').strip()
                if s_alias and s_alias.lower() not in seen_a:
                    seen_a.add(s_alias.lower())
                    merged_aliases.append(s_alias)
        except Exception:
            pass
    effective_aliases = (
        expand_sequel_season_aliases(show_title, merged_aliases, season)
        if (show_title or merged_aliases)
        else merged_aliases
    )
    check_season = (provider not in _ID_BASED_PROVIDERS) and (season_source != 'default')

    def _run_pass(enforce_season):
        regex_season = _RE_FILTER_SEASON
        regex_ordinal_season = _RE_FILTER_ORDINAL_SEASON
        regex_season_pack = _RE_FILTER_SEASON_PACK
        regex_episode = _RE_FILTER_EPISODE
        regex_episode_range = _RE_FILTER_EPISODE_RANGE
        regex_part = _RE_FILTER_PART
        regex_trailing_number = _RE_FILTER_TRAILING_NUMBER
        regex_ordinal_check = _RE_FILTER_ORDINAL_CHECK

        filtered = []
        seen_hashes = set()

        for torrent in torrent_list:
            if provider in ('animetosho', 'nekobt', 'bitsearch', 'piratebay'):
                if 'hash' not in torrent:
                    continue
            elif provider == 'nyaa':
                if not torrent.get('hash'):
                    m = _RE_BTIH_HASH.search(torrent.get('magnet', ''))
                    torrent['hash'] = m.group(1) if m else ''
            elif provider == 'realdebrid':
                torrent['hash'] = torrent.get('hash', '')
            elif provider == 'alldebrid':
                torrent['hash'] = torrent.get('hash', '')
            elif provider == 'premiumize':
                torrent['hash'] = torrent.get('id', '')
            elif provider == 'torbox':
                torrent['hash'] = torrent.get('hash', '')
            elif provider == 'torrentio':
                if 'hash' not in torrent:
                    continue
            elif provider == 'local':
                torrent['hash'] = torrent.get('path', '')
            elif provider == 'easynews':
                if 'hash' not in torrent or 'name' not in torrent:
                    continue
            else:
                continue

            raw_title = torrent.get('release_title') or (
                torrent.get('filename', '') if provider in ['realdebrid', 'alldebrid'] else torrent.get('name', '')
            )
            title = raw_title.lower()

            if show_title or effective_aliases:
                target_query = show_title or (effective_aliases[0] if effective_aliases else '')
                title_score = score_title_candidate(target_query, raw_title, aliases=effective_aliases)
                if title_score <= 40:
                    continue
                torrent['relevance'] = title_score

            clean_title = clean_text(title)

            part_matches = regex_part.findall(title)
            extracted_parts = []
            for match in part_matches:
                for group in match:
                    if group:
                        extracted_parts.append(group)

            season_matches = regex_season.findall(title) + regex_ordinal_season.findall(title)
            extracted_seasons = ", ".join(season_matches) if season_matches else None

            clean_title_no_parts = regex_part.sub("", clean_title)
            extracted_episode = None

            se_match = _RE_FILTER_S_E.search(clean_title_no_parts)
            if se_match:
                epnum = se_match.group(1)
                if not (extracted_parts and epnum in extracted_parts):
                    extracted_episode = epnum

            clean_title_no_parts = regex_season_pack.sub(" ", clean_title_no_parts)
            clean_title_no_parts = regex_ordinal_season.sub(" ", regex_season.sub(" ", clean_title_no_parts))

            if not extracted_episode:
                range_match = regex_episode_range.search(clean_title_no_parts)
                if range_match:
                    start, end = range_match.group(1), range_match.group(2)
                    if int(start) <= int(end) and not (extracted_parts and (start in extracted_parts or end in extracted_parts)):
                        extracted_episode = f"{start}-{end}"

            if not extracted_episode:
                ep_match = regex_episode.findall(clean_title_no_parts)
                if ep_match:
                    episodes = []
                    for match in ep_match:
                        for group in match:
                            if group and group not in extracted_parts:
                                episodes.append(group)

                    if extracted_seasons and episodes:
                        try:
                            season_nums = [int(s.strip()) for s in extracted_seasons.split(",") if s.strip().isdigit()]
                            if episodes[0].isdigit() and int(episodes[0]) in season_nums:
                                episodes = episodes[1:]
                        except Exception:
                            pass

                    if len(episodes) >= 2 and episodes[0].isdigit() and episodes[-1].isdigit():
                        extracted_episode = f"{episodes[0]}-{episodes[-1]}"
                    elif episodes:
                        extracted_episode = ", ".join(episodes)

            if not extracted_episode:
                trail_matches = regex_trailing_number.findall(clean_title_no_parts)
                if trail_matches:
                    last_num = trail_matches[-1]
                    if not (extracted_parts and last_num in extracted_parts):
                        if extracted_seasons:
                            try:
                                season_nums = [int(s.strip()) for s in extracted_seasons.split(",") if s.strip().isdigit()]
                                if last_num.isdigit() and int(last_num) in season_nums:
                                    extracted_episode = None
                                elif not regex_ordinal_check.search(clean_title_no_parts):
                                    extracted_episode = last_num
                            except Exception:
                                pass
                        elif not regex_ordinal_check.search(clean_title_no_parts):
                            extracted_episode = last_num

            has_info = bool(extracted_episode or extracted_seasons or extracted_parts)
            if not has_info:
                filtered.append(torrent)
                continue

            valid = True
            absolute_match = False

            if episode and extracted_episode:
                if "-" in extracted_episode:
                    try:
                        start, end = extracted_episode.split("-", 1)
                        req_ep = int(episode)
                        if not (int(start) <= req_ep <= int(end)):
                            if absolute_episode is not None and (int(start) <= int(absolute_episode) <= int(end)):
                                absolute_match = True
                            else:
                                valid = False
                    except (ValueError, TypeError):
                        valid = False
                else:
                    try:
                        req_ep = int(episode)
                        episode_nums = [int(e.strip()) for e in extracted_episode.split(",") if e.strip().isdigit()]
                        if req_ep not in episode_nums:
                            if absolute_episode is not None and int(absolute_episode) in episode_nums:
                                absolute_match = True
                            else:
                                valid = False
                    except (ValueError, TypeError):
                        valid = False

            if enforce_season and season and extracted_seasons and not absolute_match:
                season_nums = []
                for s in extracted_seasons.split(","):
                    try:
                        season_nums.append(int(s.strip()))
                    except (ValueError, TypeError):
                        pass

                if season_nums:
                    try:
                        req_season = int(season)
                        if req_season not in season_nums:
                            valid = False
                    except (ValueError, TypeError):
                        valid = False

            if part and extracted_parts:
                part_nums = []
                for p in extracted_parts:
                    try:
                        part_nums.append(int(p))
                    except (ValueError, TypeError):
                        pass

                if part_nums:
                    try:
                        req_part = int(part)
                        if req_part not in part_nums:
                            valid = False
                    except (ValueError, TypeError):
                        valid = False

            if valid:
                thash = (torrent.get('hash') or '').strip().lower()
                if thash:
                    if thash in seen_hashes:
                        continue
                    seen_hashes.add(thash)
                filtered.append(torrent)

        return filtered

    filtered = _run_pass(check_season)
    if not filtered and torrent_list and check_season and season_source == 'title':
        filtered = _run_pass(False)
        for torrent in filtered:
            torrent['relaxed'] = True

    return filtered


# ═══════════════════════════════════════════════════════════════════════════
#  Text Cleaning
# ═══════════════════════════════════════════════════════════════════════════

_RE_COMBINED_PATTERNS = re.compile(
    r"\b(?:360p|480p|720p|1080p|2160p|4k)(?!\d)|"
    r"\b10\s?bits?\b|"
    r"\b(?:h\.?\s?264|x\.?\s?264|h\.?\s?265|x\.?\s?265|hevc|avc|hls)(?!\d)|"
    r"\b(?:web-dl|webrip|bluray|hdrip|dvdrip|hdtv|pdtv|cam|screener)\b|"
    r"\b(?:hdr10|hdr|sdr|dv|dolby vision|dovi)\b|"
    r"\b(?:mp4|vp9|av1|mpeg|xvid|divx|wmv|flac)\b|"
    r"\b(?:aac|mp3|opus|ddp|dd(?:\s?(?:2|5|7))|ac3|dts(?:-hdma|-hdhr|-x)?|atmos|truehd)(?:\d+(?:\.\d+)?)?\b|"
    r"\b(?:1\.0|2\.0|5\.1|7\.1|2ch|5ch|7ch|8ch)\b|"
    r"\b(?:3d|60[-\s]?fps)\b|"
    r"\b(?:multi audio|dual audio|dub(?:bed)?|multi sub|batch|complete series)\b",
    re.IGNORECASE
)

_RE_BRACKETS_AND_PARENS = re.compile(r"\[.*?\]|\(.*?\)")
_RE_SPECIAL_CHARS = re.compile(r"[:/,!?()'\"\\\[\]_.]")
_RE_COLLAPSE_SPACES = re.compile(r"\s+")
_RE_CLEANTITLE_PUNCT = re.compile(r'[:/,!?();\'"\\\[\]\-_.]')


def remove_patterns(text):
    return _RE_COMBINED_PATTERNS.sub("", text)


def cleanup_text(text):
    # Remove content within brackets or parentheses
    text = _RE_BRACKETS_AND_PARENS.sub("", text).strip()
    # Replace special characters with a space, but preserve dashes for episode range detection
    text = _RE_SPECIAL_CHARS.sub(" ", text)
    # Collapse multiple spaces into one
    return _RE_COLLAPSE_SPACES.sub(" ", text).strip()


def clean_text(text):
    text = remove_patterns(text)
    text = cleanup_text(text)
    return text


def cleanTitle(title):
    if not title:
        return ''
    # Normalize Unicode characters via NFKD decomposition so macrons and accented characters
    # (e.g. 'Pokémon' -> 'Pokemon', 'Ōsama' -> 'Osama', 'Yū Yū' -> 'Yu Yu') are preserved
    # as ASCII base characters rather than discarded.
    title = unicodedata.normalize('NFKD', str(title))
    title = title.encode('ascii', errors='ignore').decode('ascii', errors='ignore').lower()
    # Collapse common contractions ('s, 'm, 't, 're, 've, 'll, 'd) so "I'm" == "Im"
    title = title.replace("&#039;", "'").replace("\\'", "'")
    title = re.sub(r"(?<=[a-z0-9])'(?=(?:s|m|t|re|ve|ll|d)\b)", '', title)
    title = re.sub(r"(?<=[a-z0-9])\s+039\s+(?=(?:s|m|t|re|ve|ll|d)\b)", '', title)
    title = _RE_CLEANTITLE_PUNCT.sub(' ', title)
    title = _RE_COLLAPSE_SPACES.sub(' ', title)
    title = title.replace('&', 'and')
    return title.strip()


# ═══════════════════════════════════════════════════════════════════════════
#  File Utilities
# ═══════════════════════════════════════════════════════════════════════════

_VIDEO_EXTENSIONS_CACHE = None


def video_ext():
    global _VIDEO_EXTENSIONS_CACHE
    if _VIDEO_EXTENSIONS_CACHE is None:
        try:
            media_str = xbmc.getSupportedMedia('video')
            if isinstance(media_str, str) and media_str:
                raw = media_str.split('|')
                _VIDEO_EXTENSIONS_CACHE = frozenset(ext.lower() for ext in raw if ext and ext != '.zip')
        except (AttributeError, ValueError, TypeError) as e:
            control.log(f"getSupportedMedia parsing error: {e}", 'debug')
        if not _VIDEO_EXTENSIONS_CACHE:
            _VIDEO_EXTENSIONS_CACHE = frozenset({
                '.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm',
                '.flv', '.vob', '.ogv', '.ts', '.m2ts', '.mts'
            })
    return _VIDEO_EXTENSIONS_CACHE


def is_file_ext_valid(file_name):
    if not file_name:
        return False
    ext = os.path.splitext(file_name)[1].lower()
    return ext in video_ext()


def user_select(files, dict_key):
    if not files:
        return [{dict_key: '', 'path': ''}]
    idx = control.select_dialog('Select File', [i[dict_key].rsplit('/')[-1] for i in files])
    if idx == -1:
        file = [{dict_key: '', 'path': ''}]
    else:
        file = [files[idx]]
    return file


_RE_EMBED_HOST = re.compile(r'(?://|\.)([^.]+)\.')


def get_embedhost(url):
    s = _RE_EMBED_HOST.search(url)
    return s.group(1) if s else ''

# ═══════════════════════════════════════════════════════════════════════════
#  Season Pack & Release Group Detection
# ═══════════════════════════════════════════════════════════════════════════

_EPISODE_RANGE_RE = re.compile(
    r'(?:ep|eps|episode|e)?\s*(\d{1,4})\s*(?:-|~|–|—)\s*(?:ep|eps|episode|e)?\s*(\d{1,4})',
    re.IGNORECASE
)

_RELEASE_GROUP_RE = re.compile(
    r'^\s*[\[\(]([a-zA-Z0-9_\-\.\s]+?)[\]\)]'
)

_NON_GROUP_TAGS = frozenset({
    '1080p', '720p', '4k', '2160p', '480p', 'hevc', 'x264', 'x265', 'batch',
    'complete', 'dual-audio', 'multi-audio', 'dub', 'sub', 'remux', 'bluray',
    'bdrip', 'webrip', 'web-dl', 'webdl', 'flac', 'aac'
})


def extract_episode_range(release_title):
    """
    Extract (start_ep, end_ep) tuple from a release title if an episode range is present.
    Returns (int, int) or None.
    """
    if not release_title:
        return None
    for m in _EPISODE_RANGE_RE.finditer(release_title):
        try:
            s_val, e_val = int(m.group(1)), int(m.group(2))
            if 1900 <= s_val <= 2100 and 1900 <= e_val <= 2100:
                continue
            if s_val < e_val and (e_val - s_val) < 2000:
                return s_val, e_val
        except (ValueError, TypeError):
            continue
    return None


_RE_SEASON_PACK_CHECK = re.compile(r'\b(?:season\s*\d+|s\d{1,2})\b', re.IGNORECASE)
_RE_EPISODE_CHECK = re.compile(r'\b(?:e|ep|episode)\s*\d{1,4}\b|\bs\d{1,2}e\d{1,4}\b', re.IGNORECASE)
_RE_INVALID_FILENAME_CHARS = re.compile(r'[\\/*?:"<>|]')


def is_single_episode(title):
    """
    Check if a release title specifically targets a single episode (e.g. '- 01', 'S01E01', 'ep 02').
    Returns False for episode ranges ('01-24', '01~02') and whole-show/season titles.
    """
    if not title:
        return False
    if extract_episode_range(title) is not None:
        return False
    clean = clean_text(str(title).lower())
    if _RE_FILTER_EPISODE_RANGE.search(clean):
        return False
    m = _RE_FILTER_EPISODE.search(clean)
    if m and any(bool(g) for g in m.groups() if g is not None):
        return True
    return False


def is_season_pack(source, is_show_pack=False):
    """
    Determine whether a source represents a season pack / batch torrent.
    """
    if not isinstance(source, dict):
        return False
    if source.get('package') is True or source.get('is_pack') is True:
        if isinstance(source.get('info'), list) and 'BATCH' not in source['info']:
            source['info'].append('BATCH')
        return True
    if 'BATCH' in source.get('info', []):
        source['package'] = True
        source['is_pack'] = True
        return True
    title = source.get('release_title') or source.get('name') or source.get('filename') or ''
    if not title:
        return False
    if extract_episode_range(title) is not None:
        source['package'] = True
        source['is_pack'] = True
        if isinstance(source.get('info'), list) and 'BATCH' not in source['info']:
            source['info'].append('BATCH')
        return True
    lower = title.lower()
    if any(k in lower for k in (
        'batch', 'complete series', 'complete season', 'entire series',
        'all episodes', 'season pack', 'series pack', 'full season',
        'whole series'
    )):
        source['package'] = True
        source['is_pack'] = True
        if isinstance(source.get('info'), list) and 'BATCH' not in source['info']:
            source['info'].append('BATCH')
        return True
    if _RE_SEASON_PACK_CHECK.search(lower) and not _RE_EPISODE_CHECK.search(lower):
        source['package'] = True
        source['is_pack'] = True
        if isinstance(source.get('info'), list) and 'BATCH' not in source['info']:
            source['info'].append('BATCH')
        return True
    if is_show_pack and not is_single_episode(title):
        source['package'] = True
        source['is_pack'] = True
        if isinstance(source.get('info'), list) and 'BATCH' not in source['info']:
            source['info'].append('BATCH')
        return True
    return False


def season_pack_covers_episode(source, episode_num, total_episodes=None):
    """
    Check if a season pack source covers a specific episode number.
    """
    if not is_season_pack(source):
        return False
    try:
        ep_int = int(episode_num)
    except (ValueError, TypeError):
        return False

    title = source.get('release_title') or source.get('name') or source.get('filename') or ''
    r = extract_episode_range(title)
    if r is not None:
        start, end = r
        return start <= ep_int <= end

    if total_episodes:
        try:
            return 1 <= ep_int <= int(total_episodes)
        except (ValueError, TypeError):
            pass
    return ep_int >= 1


def extract_release_group(release_title):
    """
    Extract the release group from an anime release title (e.g., '[SubsPlease]' -> 'subsplease').
    Returns lowercase group name or empty string.
    """
    if not release_title:
        return ''
    m = _RELEASE_GROUP_RE.match(release_title)
    if m:
        group = m.group(1).strip()
        if group.lower() not in _NON_GROUP_TAGS:
            return group.lower()
    return ''


def format_video_filename(video_info):
    """
    Generate a standardized media filename for Kodi Player and external subtitle search addons.
    Examples:
      - TV Episode: 'Black Butler - S05E03.mkv'
      - Movie: 'Your Name (2016).mkv'
    """
    if not isinstance(video_info, dict):
        return ''
    show = video_info.get('tvshowtitle') or video_info.get('showtitle') or ''
    title = video_info.get('title') or ''
    season = video_info.get('season')
    episode = video_info.get('episode')
    year = video_info.get('year')

    clean_show = _RE_INVALID_FILENAME_CHARS.sub('', str(show)).strip() if show else ''
    clean_title = _RE_INVALID_FILENAME_CHARS.sub('', str(title)).strip() if title else ''

    if clean_show and season is not None and episode is not None:
        try:
            s_num = int(season)
            e_num = int(episode)
            return f"{clean_show} - S{s_num:02d}E{e_num:02d}.mkv"
        except (ValueError, TypeError):
            return f"{clean_show} - {episode}.mkv"
    elif clean_show and episode is not None:
        try:
            e_num = int(episode)
            return f"{clean_show} - {e_num:02d}.mkv"
        except (ValueError, TypeError):
            return f"{clean_show} - {episode}.mkv"
    elif clean_title and year:
        return f"{clean_title} ({year}).mkv"
    elif clean_title:
        return f"{clean_title}.mkv"
    return ''


