"""
control.py - Otaku Addon Control & Settings Layer
==================================================
Central hub for addon-wide constants, settings access, GUI helpers,
directory listing, and Kodi integration utilities.

Architecture
------------
Constants    - Addon ID, paths, database files, Kodi objects
Settings     - Cached getters/setters (window property → in-memory → Kodi API)
Logging      - Unified log() helper with level mapping
Debrid/WL    - Helper functions for enabled services
GUI/Dialogs  - Dialog wrappers, notifications, keyboard input
VideoTags    - ListItem metadata builder (set_videotags)
Directory    - draw_items / bulk_dir_list / xbmc_add_dir
View Types   - Container view mode helpers
Context Menu - process_context() for dynamic context menu caching
Utilities    - Misc helpers (clipboard, color, refresh, abort)
"""

import random
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs
import os
import sys
import json
import shutil
import threading
import re

from concurrent.futures import ThreadPoolExecutor
from functools import partial
from urllib import parse


# ═══════════════════════════════════════════════════════════════════════════
#  Constants - Addon Identity & Paths
# ═══════════════════════════════════════════════════════════════════════════

_artwork_cache = {}


def get_device_ram_mb() -> int | None:
    """Return total physical RAM in MB, or None if undetermined."""
    ram_mb = None
    try:
        with open('/proc/meminfo', 'r') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    ram_mb = int(line.split()[1]) // 1024
                    break
    except (OSError, ValueError, IndexError):
        pass

    if ram_mb is None:
        try:
            ram_mb = (os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES')) // (1024 * 1024)
        except (AttributeError, ValueError, OSError):
            pass
    return ram_mb


def is_low_memory() -> bool:
    """Return True if device has <= 2GB RAM or is running on a 32-bit architecture."""
    if sys.maxsize <= 2**31 - 1:
        return True
    ram_mb = get_device_ram_mb()
    return ram_mb is not None and ram_mb <= 2048


def _detect_max_threads() -> int:
    """Determine thread limit based on available physical memory and CPU count."""
    cpu = os.cpu_count() or 4
    ram_mb = get_device_ram_mb()

    if ram_mb is not None and ram_mb <= 2048:
        # Low-spec Android TV / Fire TV stick (<= 2 GB RAM)
        return max(2, min(cpu, 4))
    elif ram_mb is not None and ram_mb <= 4096:
        # Mid-tier box (<= 4 GB RAM)
        return max(2, min(cpu, 6))
    else:
        # High-spec device or PC
        return max(2, min(cpu, 8))


max_threads = _detect_max_threads()

try:
    HANDLE = int(sys.argv[1])
except (IndexError, ValueError):
    print('No handle found, using default 0')
    HANDLE = 0

class _SettingsProxy:
    """Session-cached proxy for xbmcaddon.Settings avoiding persistent SWIG wrapper leaks."""

    def __init__(self, addon_id=None):
        self._addon_id = addon_id
        self._addon = None
        self._cached = None

    def _get_addon(self):
        if self._addon is None:
            self._addon = xbmcaddon.Addon(self._addon_id) if self._addon_id else xbmcaddon.Addon()
        return self._addon

    def _get_settings(self):
        if self._cached is None:
            self._cached = self._get_addon().getSettings()
        return self._cached

    def cleanup(self):
        self._cached = None
        self._addon = None

    def getBool(self, key):
        return self._get_settings().getBool(key)

    def getInt(self, key):
        return self._get_settings().getInt(key)

    def getNumber(self, key):
        return self._get_settings().getNumber(key)

    def getString(self, key):
        return self._get_settings().getString(key)

    def getBoolList(self, key):
        return self._get_settings().getBoolList(key)

    def getIntList(self, key):
        return self._get_settings().getIntList(key)

    def getStringList(self, key):
        return self._get_settings().getStringList(key)

    def getNumberList(self, key):
        return self._get_settings().getNumberList(key)

    def setBool(self, key, value):
        return self._get_settings().setBool(key, bool(value))

    def setInt(self, key, value):
        return self._get_settings().setInt(key, int(value))

    def setNumber(self, key, value):
        return self._get_settings().setNumber(key, float(value))

    def setString(self, key, value):
        return self._get_settings().setString(key, str(value))

    def setStringList(self, key, value):
        return self._get_settings().setStringList(key, value)

    def setBoolList(self, key, value):
        return self._get_settings().setBoolList(key, value)

    def setIntList(self, key, value):
        return self._get_settings().setIntList(key, value)

    def setNumberList(self, key, value):
        return self._get_settings().setNumberList(key, value)


class _AddonProxy:
    """Lightweight session-cached proxy for xbmcaddon.Addon avoiding persistent SWIG wrapper leaks."""

    def __init__(self, addon_id=None):
        self._addon_id = addon_id
        self._cached = None

    def _get_addon(self):
        if self._cached is None:
            if self._addon_id:
                self._cached = xbmcaddon.Addon(self._addon_id)
            else:
                self._cached = xbmcaddon.Addon()
        return self._cached

    def cleanup(self):
        self._cached = None

    def getAddonInfo(self, info_id):
        return self._get_addon().getAddonInfo(info_id)

    def getLocalizedString(self, string_id):
        return self._get_addon().getLocalizedString(string_id)

    def getSetting(self, setting_id):
        return self._get_addon().getSetting(setting_id)

    def setSetting(self, setting_id, value):
        return self._get_addon().setSetting(setting_id, value)

    def getSettings(self):
        return _SettingsProxy(self._addon_id)

    def openSettings(self):
        return self._get_addon().openSettings()


class _WindowProxy:
    """Lightweight session-cached proxy for xbmcgui.Window avoiding persistent SWIG wrapper leaks."""

    def __init__(self, window_id=10000):
        self._window_id = window_id
        self._cached = None

    def _get_win(self):
        if self._cached is None:
            self._cached = xbmcgui.Window(self._window_id)
        return self._cached

    def cleanup(self):
        self._cached = None

    def getProperty(self, key):
        return self._get_win().getProperty(key)

    def setProperty(self, key, value):
        self._get_win().setProperty(key, str(value))

    def clearProperty(self, key):
        self._get_win().clearProperty(key)

    def clearProperties(self):
        self._get_win().clearProperties()


class _PlayListProxy:
    """Lightweight session-cached proxy for xbmc.PlayList avoiding persistent SWIG wrapper leaks."""

    def __init__(self, playlist_type=xbmc.PLAYLIST_VIDEO):
        self._type = playlist_type
        self._cached = None

    def _get_pl(self):
        if self._cached is None:
            self._cached = xbmc.PlayList(self._type)
        return self._cached

    def cleanup(self):
        self._cached = None

    def clear(self):
        self._get_pl().clear()

    def add(self, url, listitem=None, index=-1):
        pl = self._get_pl()
        if listitem is not None:
            pl.add(url=url, listitem=listitem, index=index)
        else:
            pl.add(url=url, index=index)

    def size(self):
        return self._get_pl().size()

    def getposition(self):
        return self._get_pl().getposition()

    def __getitem__(self, index):
        return self._get_pl()[index]

    def __len__(self):
        return self._get_pl().size()


class _ProgressDialogProxy:
    """Lightweight on-demand proxy for xbmcgui.DialogProgress avoiding persistent SWIG wrapper leaks."""

    def __init__(self):
        self._dialog = None

    def _ensure_dialog(self):
        if self._dialog is None:
            self._dialog = xbmcgui.DialogProgress()
        return self._dialog

    def create(self, heading, *args):
        self._ensure_dialog()
        try:
            return self._dialog.create(heading, *args)
        except TypeError:
            msg = "\n".join(str(a) for a in args if a)
            return self._dialog.create(heading, msg)

    def update(self, percent, *args):
        if self._dialog is not None:
            try:
                return self._dialog.update(percent, *args)
            except TypeError:
                msg = "\n".join(str(a) for a in args if a)
                return self._dialog.update(percent, msg)

    def iscanceled(self):
        if self._dialog is not None:
            return self._dialog.iscanceled()
        return False

    def close(self):
        if self._dialog is not None:
            try:
                self._dialog.close()
            except Exception:
                pass
            self._dialog = None

    def cleanup(self):
        self.close()


_init_addon = xbmcaddon.Addon()
ADDON_ID = _init_addon.getAddonInfo('id')
_target_addon = xbmcaddon.Addon(ADDON_ID)
ADDON_NAME = _target_addon.getAddonInfo('name')
ADDON_VERSION = _target_addon.getAddonInfo('version')
ADDON_ICON = _target_addon.getAddonInfo('icon')
OTAKU_FANART = _target_addon.getAddonInfo('fanart')
ADDON_PATH = _target_addon.getAddonInfo('path')
dataPath = xbmcvfs.translatePath(_target_addon.getAddonInfo('profile'))
del _target_addon
del _init_addon

_kodi_addon = xbmcaddon.Addon('xbmc.addon')
kodi_version = float(_kodi_addon.getAddonInfo('version')[:4])
del _kodi_addon

ADDONS_PATH = xbmcvfs.translatePath('special://home/addons/')
pathExists = xbmcvfs.exists

_settings_cache = {}

CONTEXT_ADDON_ID = 'context.otaku.rpdev'
_temp_context = xbmcaddon.Addon(CONTEXT_ADDON_ID)
CONTEXT_ADDON_PATH = _temp_context.getAddonInfo('path')
infoDB = os.path.join(CONTEXT_ADDON_PATH, 'info.db')
if not pathExists(infoDB):
    infoDB = os.path.join(ADDON_PATH, 'info.db')
del _temp_context

ADDON = _AddonProxy(ADDON_ID)
CONTEXT_ADDON = _AddonProxy(CONTEXT_ADDON_ID)
settings = _SettingsProxy(ADDON_ID)


def language(string_id):
    return xbmcaddon.Addon(ADDON_ID).getLocalizedString(string_id)


def addonInfo(info_id):
    return xbmcaddon.Addon(ADDON_ID).getAddonInfo(info_id)


# — External API endpoints —
# Jikan v4-schema-compatible MAL metadata provider. Centralized here so a
# future provider swap (e.g. Jikan -> Tenrai) is a one-line change instead
# of a multi-file find/replace.
MAL_API_BASE_URL = "https://api.tenrai.org/v1"

# — Database files —
cacheFile = os.path.join(dataPath, 'cache.db')
searchHistoryDB = os.path.join(dataPath, 'search.db')
malSyncDB = os.path.join(dataPath, 'malSync.db')
mappingDB = os.path.join(dataPath, 'mappings.db')

# — JSON data files —
maldubFile = os.path.join(dataPath, 'mal_dub.json')
downloads_json = os.path.join(dataPath, 'downloads.json')
completed_json = os.path.join(dataPath, 'completed.json')
genre_json = os.path.join(dataPath, 'genres.json')
sort_options_json = os.path.join(dataPath, 'sort_options.json')
watch_history_json = os.path.join(dataPath, 'watch_history.json')
embeds_json = os.path.join(dataPath, 'embeds.json')
animeschedule_calendar_json = os.path.join(dataPath, 'animeschedule_calendar.json')
mal_calendar_json = os.path.join(dataPath, 'mal_calendar.json')
simkl_calendar_json = os.path.join(dataPath, 'simkl_calendar.json')

# — Kodi system paths —
kodi_userdata_path = xbmcvfs.translatePath('special://userdata/')
kodi_advancedsettings_path = os.path.join(kodi_userdata_path, 'advancedsettings.xml')

# — Image / artwork paths —
IMAGES_PATH = os.path.join(ADDON_PATH, 'resources', 'images')
OTAKU_LOGO_PATH = os.path.join(ADDON_PATH, 'resources', 'images', 'trans-goku.png')
OTAKU_LOGO2_PATH = os.path.join(ADDON_PATH, 'resources', 'images', 'trans-goku-small.png')
OTAKU_LOGO3_PATH = os.path.join(ADDON_PATH, 'resources', 'images', 'trans-goku-large.png')
OTAKU_ICONS_PATH = os.path.join(CONTEXT_ADDON_PATH, 'resources', 'images', 'icons', ADDON.getSetting("interface.icons"))
OTAKU_GENRE_PATH = os.path.join(CONTEXT_ADDON_PATH, 'resources', 'images', 'genres')

# — Kodi GUI objects —
dialogWindow = xbmcgui.WindowDialog
homeWindow = _WindowProxy(10000)
playerWindow = _WindowProxy(10000)
menuItem = xbmcgui.ListItem
execute = xbmc.executebuiltin
get_region = xbmc.getRegion
trakt_gmt_format = '%Y-%m-%dT%H:%M:%S.000Z'
progressDialog = _ProgressDialogProxy()
playList = _PlayListProxy(xbmc.PLAYLIST_VIDEO)
sleep = xbmc.sleep


# ═══════════════════════════════════════════════════════════════════════════
#  Logging
# ═══════════════════════════════════════════════════════════════════════════

def closeBusyDialog():
    if xbmc.getCondVisibility('Window.IsActive(busydialog)'):
        execute('Dialog.Close(busydialog)')
    if xbmc.getCondVisibility('Window.IsActive(busydialognocancel)'):
        execute('Dialog.Close(busydialognocancel)')


# Pre-compiled regex patterns for sensitive data sanitization
_RE_AUTH_BEARER = re.compile(r'(?i)(bearer\s+)([a-zA-Z0-9_\-\.]{8,})')
_RE_URL_PARAMS = re.compile(r'(?i)([\?&][a-zA-Z0-9_\-\.]*?(?:key|token|auth|secret|password)[a-zA-Z0-9_\-\.]*?=)([^&\s]+)')
_RE_JSON_FIELDS = re.compile(r'(?i)(["\']?[a-zA-Z0-9_\-\.]*?(?:key|token|auth|secret|password)[a-zA-Z0-9_\-\.]*?["\']?\s*[:=]\s*["\'])([^"\']{6,})(["\'])')
_RE_BASIC_AUTH = re.compile(r'(?i)(https?://[^:\s@]+:)([^@\s]+)(@)')

_SENSITIVE_SETTING_KEYS = (
    'realdebrid.token', 'alldebrid.token', 'premiumize.token', 'torbox.token',
    'debridlink.token', 'easydebrid.token', 'simkl.token',
    'mal.token', 'kitsu.token'
)


def sanitize_log(msg) -> str:
    """Scrub authentication tokens, passwords, and sensitive keys from log messages."""
    if not isinstance(msg, str):
        msg = str(msg)

    # Fast-path check: avoid regex passes if no sensitive keywords exist
    lower_msg = msg.lower()
    if not any(k in lower_msg for k in ('bearer', 'token', 'key', 'auth', 'secret', 'pass', 'http://', 'https://')):
        return msg

    msg = _RE_AUTH_BEARER.sub(r'\1[REDACTED]', msg)
    msg = _RE_URL_PARAMS.sub(r'\1[REDACTED]', msg)
    msg = _RE_JSON_FIELDS.sub(r'\1[REDACTED]\3', msg)
    msg = _RE_BASIC_AUTH.sub(r'\1[REDACTED]\3', msg)

    # Scrub active user tokens if configured in settings
    for key in _SENSITIVE_SETTING_KEYS:
        try:
            token = getSetting(key)
            if token and len(token) >= 6 and token in msg:
                msg = msg.replace(token, '[REDACTED]')
        except (TypeError, KeyError, ValueError):
            pass

    return msg


def log(msg, level="debug"):
    if level == 'info':
        level = xbmc.LOGINFO
    elif level == 'warning':
        level = xbmc.LOGWARNING
    elif level == 'error':
        level = xbmc.LOGERROR
    elif level == 'debug':
        level = xbmc.LOGDEBUG
    else:
        level = xbmc.LOGNONE
    sanitized = sanitize_log(msg)
    xbmc.log(f'{ADDON_NAME.upper()} ({HANDLE}): {sanitized}', level)


def bin(s):
    return s.encode('latin-1')


# ═══════════════════════════════════════════════════════════════════════════
#  Debrid & Watchlist Helpers
# ═══════════════════════════════════════════════════════════════════════════

def enabled_debrid():
    debrids = ['realdebrid', 'debridlink', 'alldebrid', 'premiumize', 'torbox', 'easydebrid']
    return {x: getSetting(f'{x}.token') != '' and getBool(f'{x}.enabled') for x in debrids}


def easynews_enabled():
    """Easynews: account toggle + provider toggle + HTTP Basic credentials (no pin OAuth)."""
    if not getBool('easynews.enabled'):
        return False
    if not getBool('provider.easynews'):
        return False
    return bool(getSetting('easynews.user') and getSetting('easynews.password'))


def enabled_cloud():
    clouds = ['realdebrid', 'alldebrid', 'premiumize', 'torbox']
    return {x: getSetting(f'{x}.token') != '' and getBool(f'{x}.cloudInspection') for x in clouds}


def enabled_watchlists():
    watchlists = ['anilist', 'kitsu', 'mal', 'simkl']
    return [x for x in watchlists if getSetting(f'{x}.token') != '' and getBool(f'{x}.enabled')]


def copy2clip(txt):
    platform = sys.platform
    if platform == 'win32':
        try:
            os.system('echo %s|clip' % txt)
            return True
        except (AttributeError, OSError):
            pass
    return False


def colorstr(text, color='deepskyblue'):
    return f"[COLOR {color}]{text}[/COLOR]"


def refresh():
    execute('Container.Refresh')


# ═══════════════════════════════════════════════════════════════════════════
#  Settings - Cached Getters & Setters
# ═══════════════════════════════════════════════════════════════════════════

def getSetting(key):
    """Get setting as string - checks in-memory cache, then Kodi API, then window property fallback"""
    ck = f's_{key}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    try:
        val = settings.getString(key)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{ADDON_ID}_{key}')
    if cache:
        _settings_cache[ck] = cache
        return cache
    _settings_cache[ck] = ''
    return ''


def getBool(key, default=False):
    """Get setting as boolean - checks in-memory cache, then Kodi API, then window property fallback"""
    ck = f'b_{key}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    try:
        val = settings.getBool(key)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{ADDON_ID}_{key}')
    if cache:
        val = (cache == 'true')
        _settings_cache[ck] = val
        return val
    _settings_cache[ck] = default
    return default


def getInt(key, default=0):
    """Get setting as integer - checks in-memory cache, then Kodi API, then window property fallback"""
    ck = f'i_{key}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    try:
        val = settings.getInt(key)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{ADDON_ID}_{key}')
    if cache:
        try:
            val = int(cache)
            _settings_cache[ck] = val
            return val
        except ValueError:
            pass
    _settings_cache[ck] = default
    return default


def getStr(key):
    """Get setting as string - checks in-memory cache, then window property, then Kodi API"""
    return getSetting(key)


def getNumber(key, default=0.0):
    """Get setting as float/number - checks in-memory cache, then Kodi API, then window property fallback"""
    ck = f'n_{key}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    try:
        val = settings.getNumber(key)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{ADDON_ID}_{key}')
    if cache:
        try:
            val = float(cache)
            _settings_cache[ck] = val
            return val
        except ValueError:
            pass
    _settings_cache[ck] = default
    return default


def getStringList(settingid):
    """Get setting as list of strings - checks in-memory cache, then Kodi API, then window property fallback"""
    ck = f'sl_{settingid}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    try:
        val = settings.getStringList(settingid)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{ADDON_ID}_{settingid}')
    if cache:
        try:
            val = json.loads(cache)
            _settings_cache[ck] = val
            return val
        except (ValueError, TypeError):
            pass
    _settings_cache[ck] = []
    return []


def getBoolList(settingid):
    """Get setting as list of booleans - checks in-memory cache, then Kodi API, then window property fallback"""
    ck = f'bl_{settingid}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    try:
        val = settings.getBoolList(settingid)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{ADDON_ID}_{settingid}')
    if cache:
        try:
            val = json.loads(cache)
            _settings_cache[ck] = val
            return val
        except (ValueError, TypeError):
            pass
    _settings_cache[ck] = []
    return []


def getIntList(settingid):
    """Get setting as list of integers - checks in-memory cache, then Kodi API, then window property fallback"""
    ck = f'il_{settingid}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    try:
        val = settings.getIntList(settingid)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{ADDON_ID}_{settingid}')
    if cache:
        try:
            val = json.loads(cache)
            _settings_cache[ck] = val
            return val
        except (ValueError, TypeError):
            pass
    _settings_cache[ck] = []
    return []


def getNumberList(settingid):
    """Get setting as list of numbers - checks in-memory cache, then Kodi API, then window property fallback"""
    ck = f'nl_{settingid}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    try:
        val = settings.getNumberList(settingid)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{ADDON_ID}_{settingid}')
    if cache:
        try:
            val = json.loads(cache)
            _settings_cache[ck] = val
            return val
        except (ValueError, TypeError):
            pass
    _settings_cache[ck] = []
    return []


def _evict_setting(settingid):
    """Evict all cached variants of a setting key."""
    for prefix in ('s_', 'gs_', 'b_', 'i_', 'n_', 'sl_', 'bl_', 'il_', 'nl_'):
        _settings_cache.pop(f'{prefix}{settingid}', None)
    homeWindow.clearProperty(f'{ADDON_ID}_{settingid}')


def setSetting(settingid, value):
    """Set setting as string - kept for backward compatibility"""
    settings.setString(settingid, str(value))
    _evict_setting(settingid)
    _settings_cache[f's_{settingid}'] = str(value)
    homeWindow.setProperty(f'{ADDON_ID}_{settingid}', str(value))


def setBool(settingid, value):
    """Set setting as boolean"""
    settings.setBool(settingid, value)
    _evict_setting(settingid)
    _settings_cache[f'b_{settingid}'] = bool(value)
    homeWindow.setProperty(f'{ADDON_ID}_{settingid}', 'true' if value else 'false')


def setInt(settingid, value):
    """Set setting as integer"""
    settings.setInt(settingid, value)
    _evict_setting(settingid)
    _settings_cache[f'i_{settingid}'] = int(value)
    homeWindow.setProperty(f'{ADDON_ID}_{settingid}', str(value))


def setStr(settingid, value):
    """Set setting as string"""
    settings.setString(settingid, value)
    _evict_setting(settingid)
    _settings_cache[f's_{settingid}'] = str(value)
    homeWindow.setProperty(f'{ADDON_ID}_{settingid}', str(value))


def setNumber(settingid, value):
    """Set setting as float/number"""
    settings.setNumber(settingid, value)
    _evict_setting(settingid)
    _settings_cache[f'n_{settingid}'] = float(value)
    homeWindow.setProperty(f'{ADDON_ID}_{settingid}', str(value))


def setStringList(settingid, value):
    """Set setting as list of strings"""
    settings.setStringList(settingid, value)
    _evict_setting(settingid)


def setBoolList(settingid, value):
    """Set setting as list of booleans"""
    settings.setBoolList(settingid, value)
    _evict_setting(settingid)


def setIntList(settingid, value):
    """Set setting as list of integers"""
    settings.setIntList(settingid, value)
    _evict_setting(settingid)


def setNumberList(settingid, value):
    """Set setting as list of numbers"""
    settings.setNumberList(settingid, value)
    _evict_setting(settingid)


def clearSettingsCache():
    """Clear the in-memory settings cache (call after settings change)."""
    _settings_cache.clear()
    _artwork_cache.clear()
    settings.cleanup()


# ═══════════════════════════════════════════════════════════════════════════
#  Context Menu - Dynamic Property Caching
# ═══════════════════════════════════════════════════════════════════════════

def process_context():
    """Cache context menu settings into window properties for main, testing, and rpdev addons."""
    context_settings = [
        "context.otaku.findrecommendations",
        "context.otaku.findrelations",
        "context.otaku.getwatchorder",
        "context.otaku.viewreviews",
        "context.otaku.viewstatistics",
        "context.otaku.rescrape",
        "context.otaku.sourceselect",
        "context.otaku.logout",
        "context.otaku.deletefromdatabase",
        "context.otaku.watchlist",
        "context.otaku.markedaswatched",
        "context.otaku.markpreviouswatched",
        "context.otaku.fanartselect",
        "context.otaku.clearcache"
    ]
    for s_id in context_settings:
        try:
            val_str = str(settings.getBool(s_id)).lower()
            for prefix in ('context.otaku', 'context.otaku.testing', 'context.otaku.rpdev'):
                prop_id = s_id.replace('context.otaku', prefix)
                if homeWindow.getProperty(prop_id) != val_str:
                    homeWindow.setProperty(prop_id, val_str)
        except Exception:
            log(f'Failed to cache context setting: {s_id}', 'error')


# ═══════════════════════════════════════════════════════════════════════════
#  Window Properties & URL Helpers
# ═══════════════════════════════════════════════════════════════════════════

def setGlobalProp(property, value):
    homeWindow.setProperty(property, str(value))


def getGlobalProp(property):
    return homeWindow.getProperty(property)


def clearGlobalProp(property):
    homeWindow.clearProperty(property)


def getInfoLabel(label):
    return xbmc.getInfoLabel(label)


def lang(x):
    return language(x)


def addon_url(url):
    return f"plugin://{ADDON_ID}/{url}"


def get_plugin_url(url):
    addon_base = addon_url('')
    return url[len(addon_base):]


def get_plugin_params(param):
    return dict(parse.parse_qsl(param.replace('?', '')))


def get_payload_params(url):
    url_list = url.rsplit('?', 1)
    if len(url_list) == 1:
        url_list.append('')
    payload, params = url_list
    return get_plugin_url(payload), get_plugin_params(params)


def exit_code():
    if getSetting('reuselanguageinvoker.status') == 'Enabled':
        exit_(0)


def keyboard(title, text=''):
    keyboard_ = xbmc.Keyboard(text, title, False)
    keyboard_.doModal()
    if keyboard_.isConfirmed():
        return keyboard_.getText()
    return keyboard_.getText() if keyboard_.isConfirmed() else ""


# ═══════════════════════════════════════════════════════════════════════════
#  GUI - Dialogs & Notifications
# ═══════════════════════════════════════════════════════════════════════════

def wait_loop(step: int, timeout: int, path: str, path2: str = '', *, require_item_count=False):
    """
    :param step: Step wait time in ms
    :param timeout: max timeout time in ms
    :param path: path to match Container.FolderPath
    :param path2: path2 to match Container.FolderPath
    :param require_item_count: if True, also wait until Container.NumItems parses as int > 0
    """
    step = max(1, step)
    max_loop = max(1, int(timeout / step))
    for i in range(max_loop):
        xbmc.sleep(step)
        if xbmcgui.getCurrentWindowId() == 10025:
            kodi_path = xbmc.getInfoLabel('Container.FolderPath')
            paths_ok = path in kodi_path or (path2 and path2 in kodi_path)
            if paths_ok:
                if xbmc.getCondVisibility("Container.IsUpdating"):
                    continue
                if require_item_count:
                    try:
                        n = int(xbmc.getInfoLabel('Container.NumItems'))
                    except ValueError:
                        continue
                    if n <= 0:
                        continue
                break
    else:
        log(f"Waited ({step * max_loop}ms) for path {xbmc.getInfoLabel('Container.FolderPath')}")


def clean_memory():
    """Trigger Python garbage collection, close idle connections, and release heap via malloc_trim."""
    # 1. Clear excessive in-memory artwork cache
    global _artwork_cache
    if len(_artwork_cache) > 200:
        _artwork_cache.clear()

    try:
        from resources.lib.windows import base_window
        base_window.clear_artwork_cache()
    except (ImportError, AttributeError):
        pass

    # 2. Close thread-local SQLite connections for this thread
    try:
        from resources.lib.ui import database
        database.close_thread_connections()
    except (ImportError, AttributeError):
        pass

    # 3. Garbage collection
    try:
        import gc
        gc.collect()
    except Exception as e:
        log(f"gc.collect warning: {e}", 'debug')

    # 4. Release freed heap pages to OS (Android Bionic & Linux glibc)
    try:
        import ctypes
        for lib_name in ('libc.so', 'libc.so.6', None):
            try:
                libc = ctypes.CDLL(lib_name)
                trim_func = getattr(libc, 'malloc_trim', None)
                if trim_func:
                    trim_func(0)
                    break
            except (OSError, AttributeError):
                continue
    except Exception as e:
        log(f"malloc_trim warning: {e}", 'debug')


def cleanup():
    """Explicitly release Kodi GUI dialogs and C++ resources on script shutdown."""
    clearSettingsCache()
    for proxy in (progressDialog, homeWindow, playerWindow, playList, ADDON, CONTEXT_ADDON, settings):
        try:
            proxy.cleanup()
        except Exception:
            pass
    try:
        from resources.lib.windows.base_window import BaseWindow
        BaseWindow.cleanup_all()
    except Exception:
        pass
    clean_memory()


_RE_KODI_TAG = re.compile(r'\[/?(?:COLOR(?:\s+[^\]]+|=.*?)?|B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE|CR)\]', re.IGNORECASE)
_RE_CONTROL_CHARS = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]')


def sanitize_dialog_text(text, strip_formatting=False) -> str:
    """Sanitize strings passed to Kodi UI dialogs to prevent formatting spoofing and control char injection."""
    if text is None:
        return ''
    if not isinstance(text, str):
        text = str(text)
    # Strip dangerous non-printable control characters and null bytes
    text = _RE_CONTROL_CHARS.sub('', text)
    if strip_formatting:
        text = _RE_KODI_TAG.sub('', text)
    return text.strip()


def closeAllDialogs():
    execute('Dialog.Close(all,true)')


def ok_dialog(title, text):
    return xbmcgui.Dialog().ok(sanitize_dialog_text(title), sanitize_dialog_text(text))


def textviewer_dialog(title, text):
    xbmcgui.Dialog().textviewer(sanitize_dialog_text(title), sanitize_dialog_text(text))


def yesno_dialog(title, text, nolabel=None, yeslabel=None):
    return xbmcgui.Dialog().yesno(sanitize_dialog_text(title), sanitize_dialog_text(text), nolabel, yeslabel)


def yesnocustom_dialog(title, text, customlabel='', nolabel='', yeslabel='', autoclose=0, defaultbutton=0):
    return xbmcgui.Dialog().yesnocustom(
        sanitize_dialog_text(title),
        sanitize_dialog_text(text),
        sanitize_dialog_text(customlabel),
        sanitize_dialog_text(nolabel),
        sanitize_dialog_text(yeslabel),
        autoclose,
        defaultbutton
    )


def notify(title, text, icon=OTAKU_LOGO3_PATH, time=5000, sound=False):
    xbmcgui.Dialog().notification(sanitize_dialog_text(title), sanitize_dialog_text(text), icon, time, sound)


def input_dialog(title, input_='', option=0):
    return xbmcgui.Dialog().input(sanitize_dialog_text(title), input_, option)


def multiselect_dialog(title, dialog_list, preselect=None):
    clean_list = [sanitize_dialog_text(item) if isinstance(item, str) else item for item in dialog_list]
    return xbmcgui.Dialog().multiselect(sanitize_dialog_text(title), clean_list, preselect=preselect)


def select_dialog(title, dialog_list):
    clean_list = [sanitize_dialog_text(item) if isinstance(item, str) else item for item in dialog_list]
    return xbmcgui.Dialog().select(sanitize_dialog_text(title), clean_list)


def context_menu(context_list):
    return xbmcgui.Dialog().contextmenu(context_list)


def browse(type_, heading, shares, mask=''):
    return xbmcgui.Dialog().browse(type_, heading, shares, mask)


# ═══════════════════════════════════════════════════════════════════════════
#  VideoTags - ListItem Metadata Builder
# ═══════════════════════════════════════════════════════════════════════════

def set_videotags(li, info):
    vinfo: xbmc.InfoTagVideo = li.getVideoInfoTag()
    if title := info.get('title') or info.get('title_userPreferred'):
        vinfo.setTitle(str(title))
    if media_type := info.get('mediatype') or info.get('format'):
        vinfo.setMediaType(str(media_type))
    if tvshow_title := info.get('tvshowtitle'):
        vinfo.setTvShowTitle(str(tvshow_title))
    if plot := info.get('plot'):
        vinfo.setPlot(str(plot))
    if season_plot := info.get('season_plot'):
        if hasattr(vinfo, 'setSeasonPlot'):
            try:
                vinfo.setSeasonPlot(str(season_plot))
            except Exception:
                pass
        li.setProperty('SeasonPlot', str(season_plot))
    if year := info.get('year'):
        try:
            vinfo.setYear(int(year))
        except (ValueError, TypeError):
            pass
    elif premiered := info.get('premiered'):
        # Fallback year extraction from Premiered date (YYYY-MM-DD)
        if len(str(premiered)) >= 4 and str(premiered)[:4].isdigit():
            try:
                vinfo.setYear(int(str(premiered)[:4]))
            except (ValueError, TypeError):
                pass
    if premiered := info.get('premiered'):
        vinfo.setPremiered(str(premiered))
    elif year := info.get('year'):
        try:
            vinfo.setPremiered(f"{int(year):04d}-01-01")
        except (ValueError, TypeError):
            pass
    if status := info.get('status'):
        vinfo.setTvShowStatus(str(status))
    if genre := info.get('genre'):
        vinfo.setGenres([str(g) for g in genre] if isinstance(genre, list) else [str(genre)])
    if mpaa := info.get('mpaa'):
        vinfo.setMpaa(str(mpaa))
    if rating := info.get('rating'):
        if isinstance(rating, dict):
            try:
                vinfo.setRating(float(rating.get('score', 0) or 0), int(rating.get('votes', 0) or 0))
            except (ValueError, TypeError):
                vinfo.setRating(0.0, 0)
        else:
            vinfo.setRating(0.0, 0)
    if season := info.get('season'):
        try:
            vinfo.setSeason(int(season))
        except (ValueError, TypeError):
            pass
    if episode := info.get('episode'):
        try:
            vinfo.setEpisode(int(episode))
        except (ValueError, TypeError):
            pass
    if aired := info.get('aired'):
        vinfo.setFirstAired(str(aired))
    if playcount := info.get('playcount'):
        try:
            vinfo.setPlaycount(int(playcount))
        except (ValueError, TypeError):
            pass
    if duration := info.get('duration'):
        try:
            vinfo.setDuration(int(duration))
        except (ValueError, TypeError):
            pass
    if code := info.get('code'):
        vinfo.setProductionCode(str(code))
    if studio := info.get('studio'):
        if isinstance(studio, list):
            primary_studio = [s.strip() for s in studio if s and isinstance(s, str) and s.strip()][:1]
            if primary_studio:
                vinfo.setStudios(primary_studio)
                li.setProperty('Studios', ' / '.join(str(s) for s in studio if s))
                li.setProperty('Studio', primary_studio[0])
        elif isinstance(studio, str) and studio:
            clean_studios = [s.strip() for s in studio.split(' / ') if s.strip()]
            if clean_studios:
                vinfo.setStudios(clean_studios[:1])
                li.setProperty('Studios', studio)
                li.setProperty('Studio', clean_studios[0])
    if cast := info.get('cast'):
        vinfo.setCast([
            xbmc.Actor(
                str(c.get('name') or ''),
                str(c.get('role') or ''),
                int(c.get('index') or 0),
                str(c.get('thumbnail') or '')
            )
            for c in cast if isinstance(c, dict)
        ])
    if country := info.get('country'):
        vinfo.setCountries([str(c) for c in country] if isinstance(country, list) else [str(country)])
    if originaltitle := info.get('OriginalTitle') or info.get('originaltitle') or info.get('original_title'):
        vinfo.setOriginalTitle(str(originaltitle))
        li.setProperty('originaltitle', str(originaltitle))
        li.setProperty('OriginalTitle', str(originaltitle))
    if trailer := info.get('trailer'):
        vinfo.setTrailer(str(trailer))

    # Kodi 22+ InfoTagVideo enhancements: Tagline & BCP 47 OriginalLanguage
    if tagline := info.get('tagline'):
        if hasattr(vinfo, 'setTagLine'):
            try:
                vinfo.setTagLine(str(tagline))
            except Exception:
                pass
        li.setProperty('tagline', str(tagline))

    if original_language := info.get('originallanguage') or info.get('original_language'):
        if hasattr(vinfo, 'setOriginalLanguage'):
            try:
                vinfo.setOriginalLanguage(str(original_language))
            except Exception:
                pass
        li.setProperty('OriginalLanguage', str(original_language))
    elif country := info.get('country'):
        lang_map = {'JP': 'ja', 'CN': 'zh', 'KR': 'ko', 'US': 'en', 'GB': 'en'}
        c_code = country[0] if isinstance(country, list) and country else country
        if isinstance(c_code, str) and c_code.upper() in lang_map:
            inferred_lang = lang_map[c_code.upper()]
            if hasattr(vinfo, 'setOriginalLanguage'):
                try:
                    vinfo.setOriginalLanguage(inferred_lang)
                except Exception:
                    pass
            li.setProperty('OriginalLanguage', inferred_lang)

    # Kodi 22+ InfoTagVideo available fanart registration
    if fanarts := info.get('available_fanart') or info.get('fanarts'):
        if hasattr(vinfo, 'setAvailableFanart'):
            try:
                if isinstance(fanarts, list):
                    vinfo.setAvailableFanart([str(f) for f in fanarts if f])
            except Exception:
                pass

    if uniqueids := info.get('UniqueIDs'):
        uniqueids = {str(key): str(value) for key, value in uniqueids.items() if value is not None}
        vinfo.setUniqueIDs(uniqueids)
        if 'imdb' in uniqueids:
            vinfo.setIMDBNumber(str(uniqueids['imdb']))
        for key, value in uniqueids.items():
            li.setProperty(key, str(value))

    if resume := info.get('resume'):
        try:
            vinfo.setResumePoint(float(resume), 1)
        except (ValueError, TypeError):
            pass

    if hdr_type := info.get('hdr_type') or info.get('hdr'):
        if hasattr(vinfo, 'setHdrType'):
            try:
                hdr_map = {'none': 0, 'hdr10': 1, 'hlg': 2, 'dolbyvision': 3, 'dv': 3, 'hdr10plus': 4, 'hdr': 1}
                val = hdr_map.get(str(hdr_type).lower(), int(hdr_type) if str(hdr_type).isdigit() else 1)
                vinfo.setHdrType(val)
            except Exception:
                pass
        li.setProperty('VideoResolution.HDRType', str(hdr_type))


def jsonrpc(json_data):
    return json.loads(xbmc.executeJSONRPC(json.dumps(json_data)))


def kodi_get_setting(setting_id):
    """Retrieve a Kodi system/GUI setting value via JSON-RPC."""
    try:
        res = jsonrpc({'jsonrpc': '2.0', 'method': 'Settings.GetSettingValue', 'params': {'setting': setting_id}, 'id': 1})
        val = res.get('result', {}).get('value')
        return val if val is not None else ''
    except Exception:
        return ''


# ═══════════════════════════════════════════════════════════════════════════
#  Kodi 22 Native Power, CEC & Database Helpers
# ═══════════════════════════════════════════════════════════════════════════

def get_device_power_status():
    """Query HDMI/CEC display power state natively via Kodi 22 C++ API."""
    if hasattr(xbmc, 'getDevicePowerStatus'):
        try:
            status = xbmc.getDevicePowerStatus()
            if isinstance(status, str):
                return status
        except Exception:
            pass
    return 'on'


def is_device_in_standby():
    """Return True if connected display/AVR is in standby or suspend mode."""
    return str(get_device_power_status()).lower() in ('standby', 'suspend', 'off')


def get_cec_adapter_names():
    """Enumerate active HDMI-CEC adapters via Kodi 22 C++ API."""
    if hasattr(xbmc, 'getCecAdapterNames'):
        try:
            names = xbmc.getCecAdapterNames()
            if isinstance(names, list):
                return names
        except Exception:
            pass
    return []


def get_database_name(db_type='video'):
    """Resolve Kodi database filename dynamically via Kodi 22 C++ API or JSON-RPC."""
    if hasattr(xbmc, 'getDatabaseName'):
        try:
            name = xbmc.getDatabaseName(db_type)
            if isinstance(name, str):
                return name
        except Exception:
            pass
    try:
        res = jsonrpc({'jsonrpc': '2.0', 'method': 'Database.GetDatabaseName', 'params': {'type': db_type}, 'id': 1})
        if name := res.get('result', {}).get('name'):
            return name
    except Exception:
        pass
    return 'MyVideos149.db' if db_type == 'video' else 'MyMusic84.db'


# ═══════════════════════════════════════════════════════════════════════════
#  Directory Listing - draw_items / bulk_dir_list / xbmc_add_dir
# ═══════════════════════════════════════════════════════════════════════════

def xbmc_add_dir(name, url, art, info, draw_cm, bulk_add, isfolder, isplayable, bulk_prefs=None):
    u = addon_url(url)
    liz = xbmcgui.ListItem(name, offscreen=True)
    if info:
        set_videotags(liz, info)
        # Upcoming dub release: render in Label2 (right-aligned between title and watch indicator)
        _code = info.get('code')
        if isinstance(_code, str) and _code.startswith(('Dub ', 'Sub ')):
            liz.setLabel2(_code)
    if draw_cm:
        cm = [
            (
                x[0],
                x[1]
                if x[1].startswith(('RunPlugin(', 'PlayMedia(', 'Container.', 'ActivateWindow('))
                else f'RunPlugin(plugin://{ADDON_ID}/{x[1]}/{url})'
            )
            for x in draw_cm
        ]
        liz.addContextMenuItems(cm)
    # Check new artwork.fanart setting (inverted logic from old fanart_disable)
    if bulk_prefs is not None:
        artwork_fanart_enabled = bulk_prefs['artwork_fanart_enabled']
        fanart_select_enabled = bulk_prefs['fanart_select_enabled']
        artwork_clearlogo_enabled = bulk_prefs['artwork_clearlogo_enabled']
        artwork_studios_style = bulk_prefs.get('artwork_studios_style', 'coloured')
        fanart_mal_ids = bulk_prefs.get('fanart_mal_ids')
        fanart_selections = bulk_prefs.get('fanart_selections')
        fanart_map = bulk_prefs.get('fanart_map')
    else:
        artwork_fanart_enabled = getBool('artwork.fanart')
        fanart_select_enabled = getBool('context.otaku.fanartselect')
        artwork_clearlogo_enabled = getBool('artwork.clearlogo')
        artwork_studios_style = getSetting('artwork.studios') or 'coloured'
        fanart_mal_ids = None
        fanart_selections = None
        fanart_map = None

    if not art.get('fanart') or not artwork_fanart_enabled:
        art['fanart'] = OTAKU_FANART
    else:
        if isinstance(art['fanart'], list):
            if fanart_select_enabled:
                if info.get('UniqueIDs', {}).get('mal_id'):
                    mal_id = str(info["UniqueIDs"]["mal_id"])

                    # Check cache first
                    cache_key = f"fanart_{mal_id}"
                    if cache_key in _artwork_cache:
                        art['fanart'] = _artwork_cache[cache_key]
                    else:
                        fanart_select = ''
                        if fanart_map is not None:
                            fanart_select = fanart_map.get(mal_id, '')
                        else:
                            if fanart_mal_ids is not None:
                                mal_ids = fanart_mal_ids
                                fanart_selections_list = fanart_selections or []
                            else:
                                mal_ids = getStringList('fanart.mal_ids')
                                fanart_selections_list = getStringList('fanart.selections')
                            f_map = dict(zip(mal_ids, fanart_selections_list))
                            fanart_select = f_map.get(mal_id, '')

                        selected = fanart_select if fanart_select else random.choice(art['fanart'])
                        _artwork_cache[cache_key] = selected
                        art['fanart'] = selected
                else:
                    art['fanart'] = OTAKU_FANART
            else:
                # Use cached random selection if available
                cache_key = f"fanart_{url}"
                if cache_key in _artwork_cache:
                    art['fanart'] = _artwork_cache[cache_key]
                else:
                    selected = random.choice(art['fanart'])
                    _artwork_cache[cache_key] = selected
                    art['fanart'] = selected
        # If fanart is already a string (pre-selected), use it directly

    # Check new artwork.clearlogo setting (inverted logic from old clearlogo_disable)
    if not artwork_clearlogo_enabled or not art.get('clearlogo'):
        art['clearlogo'] = OTAKU_ICONS_PATH
    # If clearlogo is already a string (pre-selected), use it directly
    # No need for random.choice() since get_meta.py pre-selects it

    # Resolve anime studio logo from resource.images.animestudio packages
    if artwork_studios_style and artwork_studios_style != 'none' and info:
        studio_val = info.get('studio')
        primary_studio_name = None
        if isinstance(studio_val, list):
            primary_studio_name = next((s.strip() for s in studio_val if s and isinstance(s, str) and s.strip()), None)
        elif isinstance(studio_val, str) and studio_val:
            parts = [s.strip() for s in studio_val.split(' / ') if s.strip()]
            if parts:
                primary_studio_name = parts[0]

        if primary_studio_name:
            studio_art = f"resource://resource.images.animestudio.{artwork_studios_style}/{primary_studio_name}.png"
            art['studio'] = studio_art
            art['tvshow.studio'] = studio_art
            liz.setProperty('StudioIcon', studio_art)
            liz.setProperty('StudioLogo', studio_art)
            liz.setProperty('Studio.Icon', studio_art)
            liz.setProperty('Studio.Logo', studio_art)
            liz.setProperty('Studio.1.Icon', studio_art)
            liz.setProperty('Studio.1.Logo', studio_art)
            liz.setProperty('Studio.1.Art', studio_art)
            liz.setProperty('tvshow.studio', studio_art)
            liz.setProperty('Studio', primary_studio_name)

    if isplayable:
        if 'poster' in art and art['poster']:
            art['tvshow.poster'] = art.pop('poster')
        liz.setProperties({'Video': 'true', 'IsPlayable': 'true'})
    clean_art = {k: str(v) for k, v in art.items() if v and isinstance(v, str)}
    liz.setArt(clean_art)
    return u, liz, isfolder if bulk_add else xbmcplugin.addDirectoryItem(HANDLE, u, liz, isfolder)


def item_looks_like_next_page_row(item):
    """True when *item* is the standard Next page folder row (next.png artwork)."""
    if not isinstance(item, dict):
        return False
    img = item.get('image')
    if isinstance(img, dict):
        icon = img.get('icon') or ''
    elif isinstance(img, str):
        icon = img
    else:
        icon = ''
    norm = icon.replace('\\', '/').lower()
    return norm.endswith('/next.png') or norm.endswith('next.png')


def schedule_next_page_prefetch(items, prefetch_callable):
    """Warm ``database.get`` / API cache for the following page after the directory is shown."""
    if not items or not callable(prefetch_callable):
        return
    if not item_looks_like_next_page_row(items[-1]):
        return

    def _run():
        try:
            prefetch_callable()
        except Exception as e:
            log(f'prefetch next page: {e}', level='debug')

    threading.Thread(target=_run, daemon=True).start()


def bulk_draw_items(video_data):
    list_items = bulk_dir_list(video_data, True)
    return xbmcplugin.addDirectoryItems(HANDLE, list_items)


def draw_items(video_data, content_type='', cacheToDisc=True):
    bulk_draw_items(video_data)
    if content_type:
        xbmcplugin.setContent(HANDLE, content_type)
    if content_type == 'episodes':
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE, "%H. %T", "%R | %P")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_EPISODE, "%H. %T", "%R | %P")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING, "%R", "%L")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE, "%Y", "%L")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_PLAYCOUNT, "%P", "%L")
    elif content_type in ('tvshows', 'movies', 'videos', 'seasons'):
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE, "%L", "%R")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE, "%L", "%R")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE, "%Y", "%R")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING, "%R", "%L")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_EPISODE, "%E", "%L")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_PLAYCOUNT, "%P", "%L")
    else:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE, "%L", "%R")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cacheToDisc)
    closeAllDialogs()
    if getBool('interface.viewtype'):
        xbmc.sleep(100)  # Delay so the directory is painted before changing view mode
        if getBool('interface.viewidswitch'):
            if content_type == '' or content_type == 'addons':
                xbmc.executebuiltin('Container.SetViewMode(%d)' % getInt('interface.addon.view.id'))
            elif content_type == 'tvshows':
                xbmc.executebuiltin('Container.SetViewMode(%d)' % getInt('interface.show.view.id'))
            elif content_type == 'episodes':
                xbmc.executebuiltin('Container.SetViewMode(%d)' % getInt('interface.episode.view.id'))
        else:
            if content_type == '' or content_type == 'addons':
                xbmc.executebuiltin('Container.SetViewMode(%d)' % get_view_type(getSetting('interface.addon.view')))
            elif content_type == 'tvshows':
                xbmc.executebuiltin('Container.SetViewMode(%d)' % get_view_type(getSetting('interface.show.view')))
            elif content_type == 'episodes':
                xbmc.executebuiltin('Container.SetViewMode(%d)' % get_view_type(getSetting('interface.episode.view')))

    if content_type == "episodes" and getBool('general.smart.scroll.enable'):
        if getBool('interface.viewtype'):
            xbmc.sleep(150)  # View mode change can repaint the list; let infolabels settle
        wait_loop(50, 4500, f"plugin://{ADDON_ID}/animes", f'plugin://{ADDON_ID}/watchlist_to_ep',
                  require_item_count=True)
        win_obj = None
        try:
            for _ in range(16):
                try:
                    window_id = xbmcgui.getCurrentWindowId()
                    if window_id != 10025:
                        xbmc.sleep(80)
                        continue
                    if win_obj is None:
                        win_obj = xbmcgui.Window(10025)
                    active_id = win_obj.getFocusId()
                except Exception:
                    xbmc.sleep(80)
                    continue
                if not active_id:
                    xbmc.sleep(80)
                    continue
                try:
                    num_watched = int(xbmc.getInfoLabel("Container.TotalWatched"))
                    total_ep = int(xbmc.getInfoLabel('Container.NumItems'))
                    all_items = int(xbmc.getInfoLabel('Container.NumAllItems'))
                except ValueError:
                    xbmc.sleep(80)
                    continue
                if all_items <= 0:
                    xbmc.sleep(80)
                    continue
                offset = 1 if all_items > total_ep else 0
                target_index = num_watched + offset
                if not (0 < target_index < all_items):
                    break
                xbmc.executebuiltin('Action(firstpage)')
                xbmc.sleep(50)
                xbmc.executebuiltin(f'Control.SetFocus({active_id}, {target_index})')
                break
        finally:
            if win_obj is not None:
                del win_obj


def _dir_list_item_worker(item, bulk_add, bulk_prefs):
    return xbmc_add_dir(
        item['name'], item['url'], item['image'], item['info'], item['cm'],
        bulk_add, item['isfolder'], item['isplayable'], bulk_prefs,
    )


def bulk_dir_list(video_data, bulk_add=True):
    artwork_fanart_enabled = getBool('artwork.fanart')
    fanart_select_enabled = getBool('context.otaku.fanartselect')
    bulk_prefs = {
        'artwork_fanart_enabled': artwork_fanart_enabled,
        'fanart_select_enabled': fanart_select_enabled,
        'artwork_clearlogo_enabled': getBool('artwork.clearlogo'),
        'artwork_studios_style': getSetting('artwork.studios') or 'coloured',
    }
    if artwork_fanart_enabled and fanart_select_enabled:
        f_ids = getStringList('fanart.mal_ids')
        f_sels = getStringList('fanart.selections')
        bulk_prefs['fanart_mal_ids'] = f_ids
        bulk_prefs['fanart_selections'] = f_sels
        bulk_prefs['fanart_map'] = dict(zip(f_ids, f_sels))
    mapfunc = partial(_dir_list_item_worker, bulk_add=bulk_add, bulk_prefs=bulk_prefs)
    with ThreadPoolExecutor(max_workers=max_threads) as executor:
        list_items = list(executor.map(mapfunc, filter(None, video_data)))
    return list_items


# ═══════════════════════════════════════════════════════════════════════════
#  View Types
# ═══════════════════════════════════════════════════════════════════════════

def get_view_type(viewtype):
    viewTypes = {
        'Default': 50,
        'Poster': 51,
        'Icon Wall': 52,
        'Shift': 53,
        'Info Wall': 54,
        'Wide List': 55,
        'Wall': 500,
        'Banner': 501,
        'Fanart': 502,
        'List': 0
    }
    return viewTypes[viewtype]


# ═══════════════════════════════════════════════════════════════════════════
#  Utilities
# ═══════════════════════════════════════════════════════════════════════════

def clear_settings(silent=False):
    from resources.lib.ui.database_sync import SyncDatabase
    if not silent:
        confirm = yesno_dialog(ADDON_NAME, lang(30090))
        if confirm == 0:
            return

    if os.path.exists(dataPath):
        shutil.rmtree(dataPath)

    os.mkdir(dataPath)
    refresh()

    if getSetting('version') != '0.5.43':
        SyncDatabase().re_build_database(True)


def exit_(code):
    sys.exit(code)


def is_addon_visible():
    return xbmc.getInfoLabel('Container.PluginName') == 'plugin.video.otaku.rpdev'


def abort_requested():
    monitor = xbmc.Monitor()
    abort_requested_ = monitor.abortRequested()
    del monitor
    return abort_requested_


def wait_for_abort(timeout=1.0):
    monitor = xbmc.Monitor()
    abort_requested_ = monitor.waitForAbort(timeout)
    del monitor
    return abort_requested_


def arc4(t, n):
    u = 0
    h = ''
    s = list(range(256))
    for e in range(256):
        x = t[e % len(t)]
        u = (u + s[e] + (x if isinstance(x, int) else ord(x))) % 256
        s[e], s[u] = s[u], s[e]

    e = u = 0
    for c in range(len(n)):
        e = (e + 1) % 256
        u = (u + s[e]) % 256
        s[e], s[u] = s[u], s[e]
        h += chr((n[c] if isinstance(n[c], int) else ord(n[c])) ^ s[(s[e] + s[u]) % 256])
    return h


def safe_call(func, *args, default=None, log_msg='', **kwargs):
    """Call func(*args, **kwargs), returning default on any exception.
    Optionally logs the error via control.log() if log_msg is provided."""
    try:
        return func(*args, **kwargs)
    except Exception as e:
        if log_msg:
            log(f'{log_msg}: {e}', 'error')
        return default


def safe_json(response, default=None):
    """Safely parse a response as JSON, returning default on failure."""
    if default is None:
        default = {}
    if not response:
        return default
    try:
        return response.json()
    except (ValueError, AttributeError, TypeError):
        return default


def loads_json(text, default=None):
    """Safely parse a JSON string, returning `default` on error or empty string."""
    if not text:
        return default
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError, ValueError):
        return default


def safe_next(iterable, default=None):
    """Safe wrapper around next() that returns default on StopIteration."""
    try:
        return next(iterable)
    except StopIteration:
        return default


def atomic_write_json(file_path: str, data: any, indent: int = 2) -> bool:
    """Atomically write JSON data to file_path via temporary swap."""
    parent_dir = os.path.dirname(os.path.abspath(file_path))
    if not os.path.exists(parent_dir):
        os.makedirs(parent_dir, exist_ok=True)
    tmp_path = f"{file_path}.{os.getpid()}.{threading.get_ident()}.tmp"
    try:
        with open(tmp_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=indent)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, file_path)
        return True
    except Exception as e:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError as rm_err:
                log(f"Failed to remove tmp file {tmp_path}: {rm_err}", 'debug')
        log(f"atomic_write_json failed for {file_path}: {e}", 'error')
        return False


def atomic_write_text(file_path: str, content: str, encoding: str = 'utf-8') -> bool:
    """Atomically write text content to file_path via temporary swap."""
    parent_dir = os.path.dirname(os.path.abspath(file_path))
    if not os.path.exists(parent_dir):
        os.makedirs(parent_dir, exist_ok=True)
    tmp_path = f"{file_path}.{os.getpid()}.{threading.get_ident()}.tmp"
    try:
        with open(tmp_path, 'w', encoding=encoding) as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, file_path)
        return True
    except Exception as e:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError as rm_err:
                log(f"Failed to remove tmp file {tmp_path}: {rm_err}", 'debug')
        log(f"atomic_write_text failed for {file_path}: {e}", 'error')
        return False


def atomic_write_bytes(file_path: str, content: bytes) -> bool:
    """Atomically write binary content to file_path via temporary swap."""
    parent_dir = os.path.dirname(os.path.abspath(file_path))
    if not os.path.exists(parent_dir):
        os.makedirs(parent_dir, exist_ok=True)
    tmp_path = f"{file_path}.{os.getpid()}.{threading.get_ident()}.tmp"
    try:
        with open(tmp_path, 'wb') as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, file_path)
        return True
    except Exception as e:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError as rm_err:
                log(f"Failed to remove tmp file {tmp_path}: {rm_err}", 'debug')
        log(f"atomic_write_bytes failed for {file_path}: {e}", 'error')
        return False


def print(string, *args):
    for i in list(args):
        string = f'{string} {i}'
    textviewer_dialog('print', f'{string}')
    del args, string


def timeIt(func):
    # Thanks to 123Venom
    def wrap(*args, **kwargs):
        import time
        started_at = time.perf_counter()
        result = func(*args, **kwargs)
        log(f">> {__name__}.{func.__name__} <<: {time.perf_counter() - started_at}")
        return result

    return wrap
