"""
control.py - Otaku Addon Control & Settings Layer
==================================================
Central hub for addon-wide constants, settings access, GUI helpers,
directory listing, and Kodi integration utilities.

Architecture
------------
Constants    - Addon ID, paths, database files, Kodi objects
Settings     - Cached getters/setters (window property → in-memory → Kodi API)
Logging      - Unified log() helper with level mapping
Debrid/WL    - Helper functions for enabled services
GUI/Dialogs  - Dialog wrappers, notifications, keyboard input
VideoTags    - ListItem metadata builder (set_videotags)
Directory    - draw_items / bulk_dir_list / xbmc_add_dir
View Types   - Container view mode helpers
Context Menu - process_context() for dynamic context menu caching
Utilities    - Misc helpers (clipboard, color, refresh, abort)
"""

import random
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import xbmcvfs
import os
import sys
import json
import shutil
import subprocess
import threading
import re

from concurrent.futures import ThreadPoolExecutor
from functools import partial
from urllib import parse


# ═══════════════════════════════════════════════════════════════════════════
#  Constants - Addon Identity & Paths
# ═══════════════════════════════════════════════════════════════════════════

_artwork_cache = {}


def get_device_ram_mb() -> int | None:
    """Return total physical RAM in MB, or None if undetermined."""
    ram_mb = None
    try:
        with open('/proc/meminfo', 'r') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    ram_mb = int(line.split()[1]) // 1024
                    break
    except (OSError, ValueError, IndexError):
        pass

    if ram_mb is None:
        try:
            ram_mb = (os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES')) // (1024 * 1024)
        except (AttributeError, ValueError, OSError):
            pass
    return ram_mb


def is_low_memory() -> bool:
    """Return True if device has <= 2GB RAM or is running on a 32-bit architecture."""
    if sys.maxsize <= 2**31 - 1:
        return True
    ram_mb = get_device_ram_mb()
    return ram_mb is not None and ram_mb <= 2048


def _detect_max_threads() -> int:
    """Determine thread limit based on available physical memory and CPU count."""
    cpu = os.cpu_count() or 4
    ram_mb = get_device_ram_mb()

    if ram_mb is not None and ram_mb <= 2048:
        # Low-spec Android TV / Fire TV stick (<= 2 GB RAM)
        return max(2, min(cpu, 4))
    elif ram_mb is not None and ram_mb <= 4096:
        # Mid-tier box (<= 4 GB RAM)
        return max(2, min(cpu, 6))
    else:
        # High-spec device or PC
        return max(2, min(cpu, 8))


max_threads = _detect_max_threads()

try:
    HANDLE = int(sys.argv[1])
except (IndexError, ValueError):
    HANDLE = 0
    try:
        xbmc.log('OTAKU RPDEV (0): No handle found, using default 0', xbmc.LOGDEBUG)
    except Exception:
        pass

class _SettingsProxy:
    """Session-cached proxy for xbmcaddon.Settings avoiding persistent SWIG wrapper leaks."""

    def __init__(self, addon_id=None):
        self._addon_id = addon_id
        self._addon = None
        self._cached = None
        self._unavailable_warned = False

    def _get_addon(self):
        if self._addon is None:
            try:
                self._addon = xbmcaddon.Addon(self._addon_id) if self._addon_id else xbmcaddon.Addon()
            except Exception as e:
                if self._addon_id and not self._unavailable_warned:
                    self._unavailable_warned = True
                    try:
                        xbmc.log(
                            f'OTAKU RPDEV (0): Companion add-on {self._addon_id} unavailable ({e}); falling back to defaults',
                            xbmc.LOGWARNING,
                        )
                    except Exception:
                        pass
                raise
        return self._addon

    def _get_settings(self):
        if self._cached is None:
            self._cached = self._get_addon().getSettings()
        return self._cached

    def cleanup(self):
        self._cached = None
        self._addon = None
        self._unavailable_warned = False

    def getBool(self, key, default=False):
        try:
            return self._get_settings().getBool(key)
        except Exception:
            return default

    def getInt(self, key, default=0):
        try:
            return self._get_settings().getInt(key)
        except Exception:
            return default

    def getNumber(self, key, default=0.0):
        try:
            return self._get_settings().getNumber(key)
        except Exception:
            return default

    def getString(self, key, default=''):
        try:
            return self._get_settings().getString(key)
        except Exception:
            return default

    def getBoolList(self, key, default=None):
        if default is None:
            default = []
        try:
            return self._get_settings().getBoolList(key)
        except Exception:
            return default

    def getIntList(self, key, default=None):
        if default is None:
            default = []
        try:
            return self._get_settings().getIntList(key)
        except Exception:
            return default

    def getStringList(self, key, default=None):
        if default is None:
            default = []
        try:
            return self._get_settings().getStringList(key)
        except Exception:
            return default

    def getNumberList(self, key, default=None):
        if default is None:
            default = []
        try:
            return self._get_settings().getNumberList(key)
        except Exception:
            return default

    def setBool(self, key, value):
        try:
            return self._get_settings().setBool(key, bool(value))
        except Exception:
            return False

    def setInt(self, key, value):
        try:
            return self._get_settings().setInt(key, int(value))
        except Exception:
            return False

    def setNumber(self, key, value):
        try:
            return self._get_settings().setNumber(key, float(value))
        except Exception:
            return False

    def setString(self, key, value):
        try:
            return self._get_settings().setString(key, str(value))
        except Exception:
            return False

    def setStringList(self, key, value):
        try:
            return self._get_settings().setStringList(key, value)
        except Exception:
            return False

    def setBoolList(self, key, value):
        try:
            return self._get_settings().setBoolList(key, value)
        except Exception:
            return False

    def setIntList(self, key, value):
        try:
            return self._get_settings().setIntList(key, value)
        except Exception:
            return False

    def setNumberList(self, key, value):
        try:
            return self._get_settings().setNumberList(key, value)
        except Exception:
            return False


class _AddonProxy:
    """Lightweight session-cached proxy for xbmcaddon.Addon avoiding persistent SWIG wrapper leaks."""

    def __init__(self, addon_id=None):
        self._addon_id = addon_id
        self._cached = None

    def _get_addon(self):
        if self._cached is None:
            if self._addon_id:
                self._cached = xbmcaddon.Addon(self._addon_id)
            else:
                self._cached = xbmcaddon.Addon()
        return self._cached

    def cleanup(self):
        self._cached = None

    def getAddonInfo(self, info_id):
        return self._get_addon().getAddonInfo(info_id)

    def getLocalizedString(self, string_id):
        return self._get_addon().getLocalizedString(string_id)

    def getSetting(self, setting_id):
        return self._get_addon().getSetting(setting_id)

    def setSetting(self, setting_id, value):
        return self._get_addon().setSetting(str(setting_id or ''), str(value if value is not None else ''))

    def getSettings(self):
        return _SettingsProxy(self._addon_id)

    def openSettings(self):
        return self._get_addon().openSettings()


class _WindowProxy:
    """Lightweight session-cached proxy for xbmcgui.Window avoiding persistent SWIG wrapper leaks."""

    def __init__(self, window_id=10000):
        self._window_id = window_id
        self._cached = None

    def _get_win(self):
        if self._cached is None:
            self._cached = xbmcgui.Window(self._window_id)
        return self._cached

    def cleanup(self):
        self._cached = None

    def getProperty(self, key):
        return self._get_win().getProperty(key)

    def setProperty(self, key, value):
        val_str = str(value if value is not None else '')
        if len(val_str.encode('utf-8')) > 65536:
            try:
                log(f"Window property '{key}' exceeds 64KB ceiling ({len(val_str.encode('utf-8'))} bytes), rejecting write", 'warning')
            except Exception:
                pass
            return
        self._get_win().setProperty(key, val_str)

    def clearProperty(self, key):
        self._get_win().clearProperty(key)

    def clearProperties(self):
        self._get_win().clearProperties()


class _PlayListProxy:
    """Lightweight session-cached proxy for xbmc.PlayList avoiding persistent SWIG wrapper leaks."""

    def __init__(self, playlist_type=xbmc.PLAYLIST_VIDEO):
        self._type = playlist_type
        self._cached = None

    def _get_pl(self):
        if self._cached is None:
            self._cached = xbmc.PlayList(self._type)
        return self._cached

    def cleanup(self):
        self._cached = None

    def clear(self):
        self._get_pl().clear()

    def add(self, url, listitem=None, index=-1):
        pl = self._get_pl()
        if listitem is not None:
            pl.add(url=url, listitem=listitem, index=index)
        else:
            pl.add(url=url, index=index)

    def size(self):
        return self._get_pl().size()

    def getposition(self):
        return self._get_pl().getposition()

    def __getitem__(self, index):
        return self._get_pl()[index]

    def __len__(self):
        return self._get_pl().size()


class _ProgressDialogProxy:
    """Lightweight on-demand proxy for xbmcgui.DialogProgress avoiding persistent SWIG wrapper leaks."""

    def __init__(self):
        self._dialog = None

    def _ensure_dialog(self):
        if self._dialog is None:
            self._dialog = xbmcgui.DialogProgress()
        return self._dialog

    def create(self, heading, *args):
        self._ensure_dialog()
        try:
            return self._dialog.create(heading, *args)
        except TypeError:
            msg = "\n".join(str(a) for a in args if a)
            return self._dialog.create(heading, msg)

    def update(self, percent, *args):
        if self._dialog is not None:
            try:
                return self._dialog.update(percent, *args)
            except TypeError:
                msg = "\n".join(str(a) for a in args if a)
                return self._dialog.update(percent, msg)

    def iscanceled(self):
        if self._dialog is not None:
            return self._dialog.iscanceled()
        return False

    def close(self):
        if self._dialog is not None:
            try:
                self._dialog.close()
            except Exception:
                pass
            self._dialog = None

    def cleanup(self):
        self.close()


class _MonitorProxy:
    """Lightweight session-cached proxy for xbmc.Monitor avoiding repeated SWIG instantiation."""

    def __init__(self):
        self._cached = None

    def _get_monitor(self):
        if self._cached is None:
            self._cached = xbmc.Monitor()
        return self._cached

    def abortRequested(self):
        return self._get_monitor().abortRequested()

    def waitForAbort(self, timeout=1.0):
        return self._get_monitor().waitForAbort(timeout)

    def cleanup(self):
        self._cached = None


try:
    _init_addon = xbmcaddon.Addon()
    _detected_id = _init_addon.getAddonInfo('id')
    # When imported by companion add-ons (service.subtitles.otaku.rpdev, context.otaku.rpdev, service.otaku.rpdev),
    # always bind settings, dataPath, and identity to plugin.video.otaku.rpdev so Kodi 22
    # resolves paths and main settings cleanly without Invalid setting type errors.
    if _detected_id in ('service.subtitles.otaku.rpdev', 'context.otaku.rpdev', 'service.otaku.rpdev'):
        ADDON_ID = 'plugin.video.otaku.rpdev'
    else:
        ADDON_ID = _detected_id
    _target_addon = xbmcaddon.Addon(ADDON_ID)
    ADDON_NAME = _target_addon.getAddonInfo('name')
    ADDON_VERSION = _target_addon.getAddonInfo('version')
    ADDON_ICON = _target_addon.getAddonInfo('icon')
    OTAKU_FANART = _target_addon.getAddonInfo('fanart')
    ADDON_PATH = _target_addon.getAddonInfo('path')
    dataPath = xbmcvfs.translatePath(_target_addon.getAddonInfo('profile'))
    del _target_addon
    del _init_addon
except Exception:
    ADDON_ID = 'plugin.video.otaku.rpdev'
    ADDON_NAME = 'Otaku RPDev'
    ADDON_VERSION = '6.0.2'
    ADDON_ICON = ''
    OTAKU_FANART = ''
    ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/')
    dataPath = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')

try:
    _kodi_addon = xbmcaddon.Addon('xbmc.addon')
    kodi_version = float(_kodi_addon.getAddonInfo('version')[:4])
    del _kodi_addon
except Exception:
    kodi_version = 22.0

ADDONS_PATH = xbmcvfs.translatePath('special://home/addons/')
pathExists = xbmcvfs.exists

_settings_cache = {}

CONTEXT_ADDON_ID = 'context.otaku.rpdev'
try:
    _temp_context = xbmcaddon.Addon(CONTEXT_ADDON_ID)
    CONTEXT_ADDON_PATH = _temp_context.getAddonInfo('path')
    del _temp_context
except Exception:
    CONTEXT_ADDON_PATH = ADDON_PATH
infoDB = os.path.join(CONTEXT_ADDON_PATH, 'info.db')
if not pathExists(infoDB):
    infoDB = os.path.join(ADDON_PATH, 'info.db')

SERVICE_ADDON_ID = 'service.otaku.rpdev'
try:
    _temp_service = xbmcaddon.Addon(SERVICE_ADDON_ID)
    SERVICE_ADDON_PATH = _temp_service.getAddonInfo('path')
    del _temp_service
except Exception:
    SERVICE_ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{SERVICE_ADDON_ID}/')

SERVICE_SETTING_IDS = frozenset({
    # Category 1: Cache & Database
    'general.kodi.cache',
    'cache.scrapers.ttl',
    'cache.torrents.ttl',
    'cache.metadata.ttl',
    'cache.calendar.ttl',
    'db.sqlite.cache_size_mb',
    'db.sqlite.mmap_size_mb',
    'db.sqlite.synchronous',
    'db.sqlite.temp_store_ram',
    # Category 2: Service, Storage & Maintenance
    'general.memory_watermark_mb',
    'general.standby_throttling',
    'download.location',
    'dub.etag',
    'mappings.etag',
    'mappings.last_modified',
    'update.time.1',
    'update.time.7',
    'update.time.30',
    'clean.memory',
    'service.migrated_from_plugin_v1',
    # Category 3: Solvers, Network & Debug
    'fs_enable',
    'fs_url',
    'fs_timeout',
    'ms_enable',
    'ms_url',
    'ipv6.status',
    'http2.status',
    'webpdb.enabled',
    'webpdb.port',
    'webpdb.mode',
})

_SERVICE_SETTINGS_EPOCH_PROP = 'otaku.service_settings_epoch'
_last_service_settings_epoch = ''

ADDON = _AddonProxy(ADDON_ID)
CONTEXT_ADDON = _AddonProxy(CONTEXT_ADDON_ID)
SERVICE_ADDON = _AddonProxy(SERVICE_ADDON_ID)
settings = _SettingsProxy(ADDON_ID)
service_settings = _SettingsProxy(SERVICE_ADDON_ID)
monitor = _MonitorProxy()


def language(string_id):
    return xbmcaddon.Addon(ADDON_ID).getLocalizedString(string_id)


def addonInfo(info_id):
    return xbmcaddon.Addon(ADDON_ID).getAddonInfo(info_id)


# — External API endpoints —
# Jikan v4-schema-compatible MAL metadata provider. Centralized here so a
# future provider swap (e.g. Jikan -> Tenrai) is a one-line change instead
# of a multi-file find/replace.
MAL_API_BASE_URL = "https://api.tenrai.org/v1"

# — Database files —
cacheFile = os.path.join(dataPath, 'cache.db')
searchHistoryDB = os.path.join(dataPath, 'search.db')
malSyncDB = os.path.join(dataPath, 'malSync.db')
mappingDB = os.path.join(dataPath, 'mappings.db')
metadataDB = os.path.join(dataPath, 'anime_metadata.db')

# — JSON data files —
maldubFile = os.path.join(dataPath, 'mal_dub.json')
downloads_json = os.path.join(dataPath, 'downloads.json')
completed_json = os.path.join(dataPath, 'completed.json')
genre_json = os.path.join(dataPath, 'genres.json')
sort_options_json = os.path.join(dataPath, 'sort_options.json')
watch_history_json = os.path.join(dataPath, 'watch_history.json')
embeds_json = os.path.join(dataPath, 'embeds.json')
animeschedule_calendar_json = os.path.join(dataPath, 'animeschedule_calendar.json')
mal_calendar_json = os.path.join(dataPath, 'mal_calendar.json')
simkl_calendar_json = os.path.join(dataPath, 'simkl_calendar.json')

# — Kodi system paths —
kodi_userdata_path = xbmcvfs.translatePath('special://userdata/')
kodi_advancedsettings_path = os.path.join(kodi_userdata_path, 'advancedsettings.xml')

# — Image / artwork paths —
IMAGES_PATH = os.path.join(ADDON_PATH, 'resources', 'images')
OTAKU_LOGO_PATH = os.path.join(ADDON_PATH, 'resources', 'images', 'trans-goku.png')
OTAKU_LOGO2_PATH = os.path.join(ADDON_PATH, 'resources', 'images', 'trans-goku-small.png')
OTAKU_LOGO3_PATH = os.path.join(ADDON_PATH, 'resources', 'images', 'trans-goku-large.png')
OTAKU_ICONS_PATH = os.path.join(CONTEXT_ADDON_PATH, 'resources', 'images', 'icons', ADDON.getSetting("interface.icons"))
OTAKU_GENRE_PATH = os.path.join(CONTEXT_ADDON_PATH, 'resources', 'images', 'genres')
OTAKU_STUDIOS_PATH = os.path.join(CONTEXT_ADDON_PATH, 'resources', 'images', 'studios')

# — Kodi GUI objects —
dialogWindow = xbmcgui.WindowDialog
homeWindow = _WindowProxy(10000)
playerWindow = _WindowProxy(10000)
menuItem = xbmcgui.ListItem
execute = xbmc.executebuiltin
get_region = xbmc.getRegion
trakt_gmt_format = '%Y-%m-%dT%H:%M:%S.000Z'
progressDialog = _ProgressDialogProxy()
playList = _PlayListProxy(xbmc.PLAYLIST_VIDEO)
sleep = xbmc.sleep


# ═══════════════════════════════════════════════════════════════════════════
#  Logging
# ═══════════════════════════════════════════════════════════════════════════

def closeBusyDialog():
    if xbmc.getCondVisibility('Window.IsActive(busydialog)'):
        execute('Dialog.Close(busydialog)')
    if xbmc.getCondVisibility('Window.IsActive(busydialognocancel)'):
        execute('Dialog.Close(busydialognocancel)')


# Pre-compiled regex patterns for sensitive data sanitization
_RE_AUTH_BEARER = re.compile(r'(?i)(bearer\s+)([a-zA-Z0-9_\-\.]{8,})')
_RE_URL_PARAMS = re.compile(r'(?i)([\?&][a-zA-Z0-9_\-\.]*?(?:key|token|auth|secret|password)[a-zA-Z0-9_\-\.]*?=)([^&\s]+)')
_RE_JSON_FIELDS = re.compile(r'(?i)(["\']?[a-zA-Z0-9_\-\.]*?(?:key|token|auth|secret|password)[a-zA-Z0-9_\-\.]*?["\']?\s*[:=]\s*["\'])([^"\']{6,})(["\'])')
_RE_BASIC_AUTH = re.compile(r'(?i)(https?://[^:\s@]+:)([^@\s]+)(@)')

_studio_logo_index_cache = {}
_STUDIO_LOGO_ALIASES = {
    'ajiadoanimationworks': 'ajiado',
    'bandainamcopictures': 'bnpictures',
    'bnp': 'bnpictures',
    'bibury': 'biburyanimationstudios',
    'biburyanimationstudio': 'biburyanimationstudios',
    'bonesfilm': 'bones',
    'cygames': 'cygamespictures',
    'eightbit': '8bit',
    'gokumi': 'studiogokumi',
    'haoliners': 'haolinersanimation',
    'haolinersanimationleague': 'haolinersanimation',
    'nbcuniversal': 'nbcuniversalentertainmentjapan',
    'olmdigital': 'olm',
    'pierrotfilms': 'pierrot',
    'studio4degc': 'studio4c',
    'studioghibli': 'ghibli',
    'studiogokimi': 'studiogokumi',
    'studiopierrot': 'pierrot',
}


def _normalize_studio_slug(name: str) -> str:
    import unicodedata
    ascii_name = unicodedata.normalize('NFKD', str(name or '')).encode('ascii', 'ignore').decode('ascii')
    return re.sub(r'[^a-z0-9]+', '', ascii_name.lower())


def get_studio_logo_path(studio_name: str, style: str = 'coloured') -> str:
    """Resolve high-resolution anime studio logo path in context.otaku.rpdev with normalization."""
    if not studio_name or style in (None, '', 'none'):
        return ''
    style_dir = 'white' if str(style).lower() == 'white' else 'coloured'
    studios_root = os.path.join(CONTEXT_ADDON_PATH, 'resources', 'images', 'studios', style_dir)

    # 1. Exact file match
    exact_path = os.path.join(studios_root, f"{studio_name}.png")
    if os.path.exists(exact_path):
        return exact_path

    # 2. Normalized alphanumeric match via cached directory index
    if style_dir not in _studio_logo_index_cache:
        try:
            if os.path.exists(studios_root):
                _studio_logo_index_cache[style_dir] = {
                    _normalize_studio_slug(os.path.splitext(f)[0]): os.path.join(studios_root, f)
                    for f in os.listdir(studios_root) if f.lower().endswith('.png')
                }
            else:
                _studio_logo_index_cache[style_dir] = {}
        except Exception:
            _studio_logo_index_cache[style_dir] = {}

    norm_target = _normalize_studio_slug(studio_name)
    norm_target = _STUDIO_LOGO_ALIASES.get(norm_target, norm_target)
    match = _studio_logo_index_cache[style_dir].get(norm_target)
    if match and os.path.exists(match):
        return match

    return exact_path


_SENSITIVE_SETTING_KEYS = (
    'realdebrid.token', 'alldebrid.token', 'premiumize.token', 'torbox.token',
    'debridlink.token', 'easydebrid.token', 'simkl.token',
    'mal.token', 'kitsu.token',
    'subtitles.subdl.apikey', 'subtitles.subsource.apikey',
    'subtitles.opensubtitles.password', 'animeskip.apikey', 'easynews.password',
)


def sanitize_log(msg) -> str:
    """Scrub authentication tokens, passwords, and sensitive keys from log messages."""
    if not isinstance(msg, str):
        msg = str(msg)

    # Fast-path check: avoid regex passes if no sensitive keywords exist
    lower_msg = msg.lower()
    if not any(k in lower_msg for k in ('bearer', 'token', 'key', 'auth', 'secret', 'pass', 'http://', 'https://')):
        return msg

    msg = _RE_AUTH_BEARER.sub(r'\1[REDACTED]', msg)
    msg = _RE_URL_PARAMS.sub(r'\1[REDACTED]', msg)
    msg = _RE_JSON_FIELDS.sub(r'\1[REDACTED]\3', msg)
    msg = _RE_BASIC_AUTH.sub(r'\1[REDACTED]\3', msg)

    # Scrub active user tokens if configured in settings
    for key in _SENSITIVE_SETTING_KEYS:
        try:
            token = getSetting(key)
            if token and len(token) >= 6 and token in msg:
                msg = msg.replace(token, '[REDACTED]')
        except (TypeError, KeyError, ValueError):
            pass

    return msg


def log(msg, level="debug"):
    if level == 'info':
        level = xbmc.LOGINFO
    elif level == 'warning':
        level = xbmc.LOGWARNING
    elif level == 'error':
        level = xbmc.LOGERROR
    elif level == 'debug':
        level = xbmc.LOGDEBUG
    else:
        level = xbmc.LOGNONE
    sanitized = sanitize_log(msg)
    xbmc.log(f'{ADDON_NAME.upper()} ({HANDLE}): {sanitized}', level)


_METRIC_TOKEN_RE = re.compile(r'[^A-Za-z0-9_.\-/:]+')


def log_metric(event, level='info', **fields):
    """Emit a single-line structured OTAKU_METRIC key=value telemetry marker via log()."""
    clean_event = _METRIC_TOKEN_RE.sub('_', str(event or 'unknown').strip()) or 'unknown'
    parts = [f"OTAKU_METRIC event={clean_event}"]
    for k in sorted(fields.keys()):
        v = fields[k]
        if v is None:
            continue
        clean_k = _METRIC_TOKEN_RE.sub('_', str(k).strip())
        if not clean_k:
            continue
        if isinstance(v, bool):
            clean_v = 'true' if v else 'false'
        elif isinstance(v, float):
            clean_v = f"{v:.3f}".rstrip('0').rstrip('.') if '.' in f"{v:.3f}" else str(v)
        else:
            raw_v = str(v).replace('\r', ' ').replace('\n', ' ').strip()
            clean_v = _METRIC_TOKEN_RE.sub('_', raw_v) if raw_v else 'none'
        parts.append(f"{clean_k}={clean_v}")
    log(' '.join(parts), level=level)


def bin(s):
    return s.encode('latin-1')


# ═══════════════════════════════════════════════════════════════════════════
#  Debrid & Watchlist Helpers
# ═══════════════════════════════════════════════════════════════════════════

def enabled_debrid():
    debrids = ['realdebrid', 'debridlink', 'alldebrid', 'premiumize', 'torbox', 'easydebrid']
    return {x: getSetting(f'{x}.token') != '' and getBool(f'{x}.enabled') for x in debrids}


def easynews_enabled():
    """Easynews: account toggle + provider toggle + HTTP Basic credentials (no pin OAuth)."""
    if not getBool('easynews.enabled'):
        return False
    if not getBool('provider.easynews'):
        return False
    return bool(getSetting('easynews.user') and getSetting('easynews.password'))


def enabled_cloud():
    clouds = ['realdebrid', 'alldebrid', 'premiumize', 'torbox']
    return {x: getSetting(f'{x}.token') != '' and getBool(f'{x}.cloudInspection') for x in clouds}


def enabled_watchlists():
    watchlists = ['anilist', 'kitsu', 'mal', 'simkl']
    return [x for x in watchlists if getSetting(f'{x}.token') != '' and getBool(f'{x}.enabled')]


def copy2clip(txt):
    platform = sys.platform
    if platform == 'win32':
        try:
            subprocess.run(['clip'], input=str(txt), text=True, check=False)
            return True
        except (AttributeError, OSError):
            pass
    return False


def colorstr(text, color='deepskyblue'):
    return f"[COLOR {color}]{text}[/COLOR]"


def refresh():
    execute('Container.Refresh')


# ═══════════════════════════════════════════════════════════════════════════
#  Settings - Cached Getters & Setters
# ═══════════════════════════════════════════════════════════════════════════

def _settings_target(key):
    """Return (settings_proxy, addon_id) for key, routing SERVICE_SETTING_IDS to service.otaku.rpdev."""
    if key in SERVICE_SETTING_IDS:
        return service_settings, SERVICE_ADDON_ID
    return settings, ADDON_ID


def bump_service_settings_epoch():
    """Increment shared Window(10000) epoch so plugin & service immediately observe cross-addon writes."""
    global _last_service_settings_epoch
    try:
        cur = homeWindow.getProperty(_SERVICE_SETTINGS_EPOCH_PROP) or '0'
        next_epoch = str(int(cur) + 1)
    except (ValueError, TypeError):
        next_epoch = '1'
    _last_service_settings_epoch = next_epoch
    try:
        homeWindow.setProperty(_SERVICE_SETTINGS_EPOCH_PROP, next_epoch)
    except Exception:
        pass
    return next_epoch


def _sync_service_settings_epoch():
    """Evict cached SERVICE_SETTING_IDS entries if another invoker/addon bumped otaku.service_settings_epoch."""
    global _last_service_settings_epoch
    try:
        cur = homeWindow.getProperty(_SERVICE_SETTINGS_EPOCH_PROP) or ''
    except Exception:
        cur = ''
    if cur and cur != _last_service_settings_epoch:
        _last_service_settings_epoch = cur
        for sid in SERVICE_SETTING_IDS:
            for prefix in ('s_', 'gs_', 'b_', 'i_', 'n_', 'sl_', 'bl_', 'il_', 'nl_'):
                _settings_cache.pop(f'{prefix}{sid}', None)
        service_settings.cleanup()


def getSetting(key):
    """Get setting as string - checks in-memory cache, then Kodi API, then window property fallback"""
    is_svc = key in SERVICE_SETTING_IDS
    if is_svc:
        _sync_service_settings_epoch()
    ck = f's_{key}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    proxy, aid = _settings_target(key)
    try:
        val = proxy.getString(key)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{aid}_{key}')
    if cache:
        _settings_cache[ck] = cache
        return cache
    _settings_cache[ck] = ''
    return ''


getString = getSetting


def getBool(key, default=False):
    """Get setting as boolean - checks in-memory cache, then Kodi API, then window property fallback"""
    if key in SERVICE_SETTING_IDS:
        _sync_service_settings_epoch()
    ck = f'b_{key}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    proxy, aid = _settings_target(key)
    try:
        val = proxy.getBool(key, default)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{aid}_{key}')
    if cache:
        val = (cache == 'true')
        _settings_cache[ck] = val
        return val
    _settings_cache[ck] = default
    return default


def getInt(key, default=0):
    """Get setting as integer - checks in-memory cache, then Kodi API, then window property fallback"""
    if key in SERVICE_SETTING_IDS:
        _sync_service_settings_epoch()
    ck = f'i_{key}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    proxy, aid = _settings_target(key)
    try:
        val = proxy.getInt(key, default)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{aid}_{key}')
    if cache:
        try:
            val = int(cache)
            _settings_cache[ck] = val
            return val
        except ValueError:
            pass
    _settings_cache[ck] = default
    return default


def getStr(key):
    """Get setting as string - checks in-memory cache, then window property, then Kodi API"""
    return getSetting(key)


def getNumber(key, default=0.0):
    """Get setting as float/number - checks in-memory cache, then Kodi API, then window property fallback"""
    if key in SERVICE_SETTING_IDS:
        _sync_service_settings_epoch()
    ck = f'n_{key}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    proxy, aid = _settings_target(key)
    try:
        val = proxy.getNumber(key, default)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{aid}_{key}')
    if cache:
        try:
            val = float(cache)
            _settings_cache[ck] = val
            return val
        except ValueError:
            pass
    _settings_cache[ck] = default
    return default


def getStringList(settingid):
    """Get setting as list of strings - checks in-memory cache, then Kodi API, then window property fallback"""
    if settingid in SERVICE_SETTING_IDS:
        _sync_service_settings_epoch()
    ck = f'sl_{settingid}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    proxy, aid = _settings_target(settingid)
    try:
        val = proxy.getStringList(settingid)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{aid}_{settingid}')
    if cache:
        try:
            val = json.loads(cache)
            _settings_cache[ck] = val
            return val
        except (ValueError, TypeError):
            pass
    _settings_cache[ck] = []
    return []


def getBoolList(settingid):
    """Get setting as list of booleans - checks in-memory cache, then Kodi API, then window property fallback"""
    if settingid in SERVICE_SETTING_IDS:
        _sync_service_settings_epoch()
    ck = f'bl_{settingid}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    proxy, aid = _settings_target(settingid)
    try:
        val = proxy.getBoolList(settingid)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{aid}_{settingid}')
    if cache:
        try:
            val = json.loads(cache)
            _settings_cache[ck] = val
            return val
        except (ValueError, TypeError):
            pass
    _settings_cache[ck] = []
    return []


def getIntList(settingid):
    """Get setting as list of integers - checks in-memory cache, then Kodi API, then window property fallback"""
    if settingid in SERVICE_SETTING_IDS:
        _sync_service_settings_epoch()
    ck = f'il_{settingid}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    proxy, aid = _settings_target(settingid)
    try:
        val = proxy.getIntList(settingid)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{aid}_{settingid}')
    if cache:
        try:
            val = json.loads(cache)
            _settings_cache[ck] = val
            return val
        except (ValueError, TypeError):
            pass
    _settings_cache[ck] = []
    return []


def getNumberList(settingid):
    """Get setting as list of numbers - checks in-memory cache, then Kodi API, then window property fallback"""
    if settingid in SERVICE_SETTING_IDS:
        _sync_service_settings_epoch()
    ck = f'nl_{settingid}'
    if ck in _settings_cache:
        return _settings_cache[ck]
    proxy, aid = _settings_target(settingid)
    try:
        val = proxy.getNumberList(settingid)
        _settings_cache[ck] = val
        return val
    except Exception:
        pass
    cache = homeWindow.getProperty(f'{aid}_{settingid}')
    if cache:
        try:
            val = json.loads(cache)
            _settings_cache[ck] = val
            return val
        except (ValueError, TypeError):
            pass
    _settings_cache[ck] = []
    return []


def _evict_setting(settingid):
    """Evict all cached variants of a setting key."""
    for prefix in ('s_', 'gs_', 'b_', 'i_', 'n_', 'sl_', 'bl_', 'il_', 'nl_'):
        _settings_cache.pop(f'{prefix}{settingid}', None)
    _, aid = _settings_target(settingid)
    homeWindow.clearProperty(f'{aid}_{settingid}')


def setSetting(settingid, value):
    """Set setting as string - kept for backward compatibility"""
    val_str = str(value if value is not None else '')
    sid_str = str(settingid or '')
    proxy, aid = _settings_target(sid_str)
    try:
        proxy.setString(sid_str, val_str)
    except Exception:
        pass
    _evict_setting(sid_str)
    _settings_cache[f's_{sid_str}'] = val_str
    homeWindow.setProperty(f'{aid}_{sid_str}', val_str)
    if aid == SERVICE_ADDON_ID:
        bump_service_settings_epoch()


def setBool(settingid, value):
    """Set setting as boolean"""
    sid_str = str(settingid or '')
    val_bool = bool(value)
    proxy, aid = _settings_target(sid_str)
    try:
        proxy.setBool(sid_str, val_bool)
    except Exception:
        pass
    _evict_setting(sid_str)
    _settings_cache[f'b_{sid_str}'] = val_bool
    homeWindow.setProperty(f'{aid}_{sid_str}', 'true' if val_bool else 'false')
    if aid == SERVICE_ADDON_ID:
        bump_service_settings_epoch()


def setInt(settingid, value):
    """Set setting as integer"""
    sid_str = str(settingid or '')
    try:
        val_int = int(value)
    except (ValueError, TypeError):
        val_int = 0
    proxy, aid = _settings_target(sid_str)
    try:
        proxy.setInt(sid_str, val_int)
    except Exception:
        pass
    _evict_setting(sid_str)
    _settings_cache[f'i_{sid_str}'] = val_int
    homeWindow.setProperty(f'{aid}_{sid_str}', str(val_int))
    if aid == SERVICE_ADDON_ID:
        bump_service_settings_epoch()


def setStr(settingid, value):
    """Set setting as string"""
    sid_str = str(settingid or '')
    val_str = str(value if value is not None else '')
    proxy, aid = _settings_target(sid_str)
    try:
        proxy.setString(sid_str, val_str)
    except Exception:
        pass
    _evict_setting(sid_str)
    _settings_cache[f's_{sid_str}'] = val_str
    homeWindow.setProperty(f'{aid}_{sid_str}', val_str)
    if aid == SERVICE_ADDON_ID:
        bump_service_settings_epoch()


setString = setSetting


def setNumber(settingid, value):
    """Set setting as float/number"""
    sid_str = str(settingid or '')
    try:
        val_num = float(value)
    except (ValueError, TypeError):
        val_num = 0.0
    proxy, aid = _settings_target(sid_str)
    try:
        proxy.setNumber(sid_str, val_num)
    except Exception:
        pass
    _evict_setting(sid_str)
    _settings_cache[f'n_{sid_str}'] = val_num
    homeWindow.setProperty(f'{aid}_{sid_str}', str(val_num))
    if aid == SERVICE_ADDON_ID:
        bump_service_settings_epoch()


def setStringList(settingid, value):
    """Set setting as list of strings"""
    sid_str = str(settingid or '')
    val_list = [str(x) for x in value] if isinstance(value, (list, tuple)) else []
    proxy, aid = _settings_target(sid_str)
    try:
        proxy.setStringList(sid_str, val_list)
    except Exception:
        pass
    _evict_setting(sid_str)
    _settings_cache[f'sl_{sid_str}'] = val_list
    try:
        homeWindow.setProperty(f'{aid}_{sid_str}', json.dumps(val_list))
    except Exception:
        pass
    if aid == SERVICE_ADDON_ID:
        bump_service_settings_epoch()


def setBoolList(settingid, value):
    """Set setting as list of booleans"""
    sid_str = str(settingid or '')
    val_list = [bool(x) for x in value] if isinstance(value, (list, tuple)) else []
    proxy, aid = _settings_target(sid_str)
    try:
        proxy.setBoolList(sid_str, val_list)
    except Exception:
        pass
    _evict_setting(sid_str)
    _settings_cache[f'bl_{sid_str}'] = val_list
    try:
        homeWindow.setProperty(f'{aid}_{sid_str}', json.dumps(val_list))
    except Exception:
        pass
    if aid == SERVICE_ADDON_ID:
        bump_service_settings_epoch()


def setIntList(settingid, value):
    """Set setting as list of integers"""
    sid_str = str(settingid or '')
    val_list = []
    if isinstance(value, (list, tuple)):
        for x in value:
            try:
                val_list.append(int(x))
            except (ValueError, TypeError):
                val_list.append(0)
    proxy, aid = _settings_target(sid_str)
    try:
        proxy.setIntList(sid_str, val_list)
    except Exception:
        pass
    _evict_setting(sid_str)
    _settings_cache[f'il_{sid_str}'] = val_list
    try:
        homeWindow.setProperty(f'{aid}_{sid_str}', json.dumps(val_list))
    except Exception:
        pass
    if aid == SERVICE_ADDON_ID:
        bump_service_settings_epoch()


def setNumberList(settingid, value):
    """Set setting as list of numbers"""
    sid_str = str(settingid or '')
    val_list = []
    if isinstance(value, (list, tuple)):
        for x in value:
            try:
                val_list.append(float(x))
            except (ValueError, TypeError):
                val_list.append(0.0)
    proxy, aid = _settings_target(sid_str)
    try:
        proxy.setNumberList(sid_str, val_list)
    except Exception:
        pass
    _evict_setting(sid_str)
    _settings_cache[f'nl_{sid_str}'] = val_list
    try:
        homeWindow.setProperty(f'{aid}_{sid_str}', json.dumps(val_list))
    except Exception:
        pass
    if aid == SERVICE_ADDON_ID:
        bump_service_settings_epoch()


def clearSettingsCache():
    """Clear the in-memory settings cache (call after settings change)."""
    _settings_cache.clear()
    _artwork_cache.clear()
    settings.cleanup()
    service_settings.cleanup()


# ═══════════════════════════════════════════════════════════════════════════
#  Context Menu - Dynamic Property Caching
# ═══════════════════════════════════════════════════════════════════════════

def process_context():
    """Cache context menu settings into window properties for main, testing, and rpdev addons."""
    context_settings = [
        "context.otaku.findrecommendations",
        "context.otaku.findrelations",
        "context.otaku.getwatchorder",
        "context.otaku.viewreviews",
        "context.otaku.viewstatistics",
        "context.otaku.rescrape",
        "context.otaku.sourceselect",
        "context.otaku.logout",
        "context.otaku.deletefromdatabase",
        "context.otaku.watchlist",
        "context.otaku.markedaswatched",
        "context.otaku.markpreviouswatched",
        "context.otaku.fanartselect",
        "context.otaku.clearcache",
        "context.otaku.inspectmappings",
        "context.otaku.seriesprofile",
    ]
    for s_id in context_settings:
        try:
            val_str = str(settings.getBool(s_id)).lower()
            for prefix in ('context.otaku', 'context.otaku.testing', 'context.otaku.rpdev'):
                prop_id = s_id.replace('context.otaku', prefix)
                if homeWindow.getProperty(prop_id) != val_str:
                    homeWindow.setProperty(prop_id, val_str)
                if s_id == 'context.otaku.markedaswatched':
                    unw_prop = f'{prefix}.markedasunwatched'
                    if homeWindow.getProperty(unw_prop) != val_str:
                        homeWindow.setProperty(unw_prop, val_str)
        except Exception:
            log(f'Failed to cache context setting: {s_id}', 'error')


# ═══════════════════════════════════════════════════════════════════════════
#  Window Properties & URL Helpers
# ═══════════════════════════════════════════════════════════════════════════

def setGlobalProp(property, value):
    val_str = str(value if value is not None else '')
    if len(val_str.encode('utf-8')) > 65536:
        try:
            log(f"Global property '{property}' exceeds 64KB ceiling ({len(val_str.encode('utf-8'))} bytes), rejecting write", 'warning')
        except Exception:
            pass
        return
    homeWindow.setProperty(property, val_str)


def getGlobalProp(property):
    return homeWindow.getProperty(property)


def clearGlobalProp(property):
    homeWindow.clearProperty(property)


def getInfoLabel(label):
    return xbmc.getInfoLabel(label)


def lang(x):
    return language(x)


def addon_url(url):
    return f"plugin://{ADDON_ID}/{url}"


def get_plugin_url(url):
    addon_base = addon_url('')
    return url[len(addon_base):]


def get_plugin_params(param):
    return dict(parse.parse_qsl(param.replace('?', '')))


def get_payload_params(url):
    url_list = url.rsplit('?', 1)
    if len(url_list) == 1:
        url_list.append('')
    payload, params = url_list
    return get_plugin_url(payload), get_plugin_params(params)


def exit_code():
    if getSetting('reuselanguageinvoker.status') == 'Enabled':
        exit_(0)


def keyboard(title, text=''):
    keyboard_ = xbmc.Keyboard(text, title, False)
    keyboard_.doModal()
    if keyboard_.isConfirmed():
        return keyboard_.getText()
    return keyboard_.getText() if keyboard_.isConfirmed() else ""


# ═══════════════════════════════════════════════════════════════════════════
#  GUI - Dialogs & Notifications
# ═══════════════════════════════════════════════════════════════════════════

def wait_loop(step: int, timeout: int, path: str, path2: str = '', *, require_item_count=False):
    """
    :param step: Step wait time in ms
    :param timeout: max timeout time in ms
    :param path: path to match Container.FolderPath
    :param path2: path2 to match Container.FolderPath
    :param require_item_count: if True, also wait until Container.NumItems parses as int > 0
    """
    step = max(1, step)
    max_loop = max(1, int(timeout / step))
    for i in range(max_loop):
        xbmc.sleep(step)
        if xbmcgui.getCurrentWindowId() == 10025:
            kodi_path = xbmc.getInfoLabel('Container.FolderPath')
            paths_ok = path in kodi_path or (path2 and path2 in kodi_path)
            if paths_ok:
                if xbmc.getCondVisibility("Container.IsUpdating"):
                    continue
                if require_item_count:
                    try:
                        n = int(xbmc.getInfoLabel('Container.NumItems'))
                    except ValueError:
                        continue
                    if n <= 0:
                        continue
                break
    else:
        log(f"Waited ({step * max_loop}ms) for path {xbmc.getInfoLabel('Container.FolderPath')}")


_32BIT_VMSIZE_GUARD_MB = 2600.0
_MEMORY_PRESSURE_PROP = 'otaku.memory_pressure'
_MEMORY_CONCURRENCY_PROP = 'otaku.memory_concurrency_limit'


def is_32bit_process(force_override=None) -> bool:
    """Return True when running in a 32-bit process (or when explicitly overridden in tests)."""
    if force_override is not None:
        return bool(force_override)
    return sys.maxsize <= (2**32)


def get_process_memory_mb(status_path='/proc/self/status'):
    """Read Linux /proc/self/status VmRSS and VmSize in MB, returning None on unsupported platforms."""
    try:
        with open(status_path, 'r', encoding='utf-8', errors='replace') as f:
            rss_kb = None
            vmsize_kb = None
            for line in f:
                if line.startswith('VmRSS:'):
                    parts = line.split()
                    if len(parts) >= 2:
                        rss_kb = int(parts[1])
                elif line.startswith('VmSize:'):
                    parts = line.split()
                    if len(parts) >= 2:
                        vmsize_kb = int(parts[1])
                if rss_kb is not None and vmsize_kb is not None:
                    break
            if rss_kb is None and vmsize_kb is None:
                return None
            return {
                'rss_mb': round((rss_kb or 0) / 1024.0, 2),
                'vmsize_mb': round((vmsize_kb or 0) / 1024.0, 2),
            }
    except (OSError, ValueError, TypeError, IndexError):
        return None


def _trim_native_heap(trim_fn=None) -> bool:
    """Release freed native heap pages via glibc malloc_trim(0) or Android Bionic mallopt(-101, 0)."""
    if trim_fn is not None:
        try:
            return bool(trim_fn())
        except Exception:
            return False
    try:
        import ctypes
        for lib_name in ('libc.so.6', 'libc.so', None):
            try:
                libc = ctypes.CDLL(lib_name)
                trim_func = getattr(libc, 'malloc_trim', None)
                if trim_func:
                    trim_func.argtypes = [ctypes.c_size_t]
                    trim_func.restype = ctypes.c_int
                    trim_func(0)
                    return True
                mallopt_func = getattr(libc, 'mallopt', None)
                if mallopt_func and lib_name == 'libc.so':
                    mallopt_func.argtypes = [ctypes.c_int, ctypes.c_int]
                    mallopt_func.restype = ctypes.c_int
                    if mallopt_func(-101, 0):
                        return True
            except (OSError, AttributeError, TypeError, ValueError):
                continue
    except Exception as e:
        log(f"malloc_trim warning: {e}", 'debug')
    return False


def enforce_memory_watermark(
    context='service',
    multipage_worker=None,
    status_path='/proc/self/status',
    force_32bit=None,
    trim_fn=None,
):
    """Enforce C-37 32-bit Android ARM RSS/VmSize watermark guard with hysteresis recovery."""
    is_32bit = is_32bit_process(force_override=force_32bit)
    mem = get_process_memory_mb(status_path=status_path)
    watermark_mb = float(getInt('general.memory_watermark_mb', default=900) or 900)
    if watermark_mb <= 0:
        watermark_mb = 900.0
    vmsize_guard_mb = _32BIT_VMSIZE_GUARD_MB

    result = {
        'is_32bit': is_32bit,
        'rss_mb': mem.get('rss_mb', 0.0) if mem else None,
        'vmsize_mb': mem.get('vmsize_mb', 0.0) if mem else None,
        'watermark_mb': watermark_mb,
        'vmsize_guard_mb': vmsize_guard_mb,
        'triggered': False,
        'recovered': False,
        'action': 'none',
    }
    if not is_32bit or mem is None:
        return result

    rss_mb = mem.get('rss_mb', 0.0)
    vmsize_mb = mem.get('vmsize_mb', 0.0)
    rss_hit = rss_mb >= watermark_mb
    vmsize_hit = vmsize_mb >= vmsize_guard_mb

    if rss_hit or vmsize_hit:
        setGlobalProp(_MEMORY_PRESSURE_PROP, 'true')
        setGlobalProp(_MEMORY_CONCURRENCY_PROP, '1')
        if multipage_worker is not None and hasattr(multipage_worker, 'set_memory_pressure'):
            try:
                multipage_worker.set_memory_pressure(True, max_workers=1)
            except Exception:
                pass
        clean_memory(trim_fn=trim_fn)
        trimmed = _trim_native_heap(trim_fn=trim_fn)
        action = 'throttle_gc_trim' if trimmed else 'throttle_gc_only'
        result['triggered'] = True
        result['action'] = action
        log(
            f"MemoryWatermarkGuard: 32-bit memory pressure ({context}) "
            f"VmRSS={rss_mb:.1f}MB (watermark={watermark_mb:.0f}MB), "
            f"VmSize={vmsize_mb:.1f}MB (guard={vmsize_guard_mb:.0f}MB) -> {action}",
            'warning',
        )
        log_metric(
            'memory_guard',
            level='warning',
            context=context,
            rss_mb=rss_mb,
            vmsize_mb=vmsize_mb,
            watermark_mb=watermark_mb,
            action=action,
        )
        return result

    # Hysteresis clear when pressure flag is currently active and both RSS & VmSize drop < 85%
    if getGlobalProp(_MEMORY_PRESSURE_PROP) == 'true':
        if rss_mb < (watermark_mb * 0.85) and vmsize_mb < (vmsize_guard_mb * 0.85):
            clearGlobalProp(_MEMORY_PRESSURE_PROP)
            clearGlobalProp(_MEMORY_CONCURRENCY_PROP)
            if multipage_worker is not None and hasattr(multipage_worker, 'set_memory_pressure'):
                try:
                    multipage_worker.set_memory_pressure(False, max_workers=None)
                except Exception:
                    pass
            result['recovered'] = True
            result['action'] = 'hysteresis_cleared'
            log_metric(
                'memory_guard',
                level='info',
                context=context,
                rss_mb=rss_mb,
                vmsize_mb=vmsize_mb,
                watermark_mb=watermark_mb,
                action='hysteresis_cleared',
            )
    return result


def clean_memory(trim_fn=None):
    """Trigger Python garbage collection, close idle connections, and release heap via malloc_trim/mallopt."""
    # 1. Clear excessive in-memory artwork cache
    global _artwork_cache
    if len(_artwork_cache) > 200:
        _artwork_cache.clear()

    try:
        from resources.lib.windows import base_window
        base_window.clear_artwork_cache()
    except (ImportError, AttributeError):
        pass

    # 2. Close thread-local SQLite connections for this thread
    try:
        from resources.lib.ui import database
        database.close_thread_connections()
    except (ImportError, AttributeError):
        pass

    # 3. Garbage collection
    try:
        import gc
        gc.collect()
    except Exception as e:
        log(f"gc.collect warning: {e}", 'debug')

    # 4. Release freed heap pages to OS (Linux glibc & Android Bionic)
    _trim_native_heap(trim_fn=trim_fn)


def init_session():
    """Refresh session state (HANDLE, _directory_ended, service_settings_epoch) on script entry."""
    global HANDLE, _directory_ended
    _directory_ended = False
    _sync_service_settings_epoch()
    try:
        HANDLE = int(sys.argv[1])
    except (IndexError, ValueError):
        HANDLE = 0


def _load_webpdb():
    """Import and return web_pdb, adding script.module.web-pdb paths if needed."""
    try:
        import web_pdb
        return web_pdb
    except ImportError:
        for rel in (
            'special://home/addons/script.module.web-pdb/libs',
            'special://home/addons/script.module.web-pdb/lib',
        ):
            try:
                p = xbmcvfs.translatePath(rel)
                if p and os.path.isdir(p) and p not in sys.path:
                    sys.path.append(p)
            except Exception:
                pass
        import web_pdb
        return web_pdb


def get_webpdb_port(port=None) -> int:
    """Resolve configured Web-PDB port, ensuring port 5555 (ADB) is redirected to 5566."""
    try:
        target_port = int(port if port is not None else (getInt('webpdb.port') or 5566))
    except (TypeError, ValueError):
        target_port = 5566
    if target_port <= 0 or target_port == 5555:
        target_port = 5566
    return target_port


def is_webpdb_port_in_use(port=None) -> bool:
    """Return True if a local TCP listener (such as an active Web-PDB session) is already bound to port."""
    import socket
    target_port = get_webpdb_port(port)
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.settimeout(0.15)
            return sock.connect_ex(('127.0.0.1', target_port)) == 0
        finally:
            sock.close()
    except Exception:
        return False


def stop_webpdb_trace(port=None) -> bool:
    """Stop an active Web-PDB debugging server by closing in-process instances and sending 'c' over ws://127.0.0.1:<port>/ws."""
    import socket
    target_port = get_webpdb_port(port)
    stopped = False

    # 1. If WebPdb.active_instance exists in the current interpreter, release it
    try:
        if 'web_pdb' in sys.modules:
            web_pdb = sys.modules['web_pdb']
            active = getattr(getattr(web_pdb, 'WebPdb', None), 'active_instance', None)
            if active is not None:
                try:
                    active.set_continue()
                except Exception:
                    pass
                try:
                    if hasattr(active, 'console') and active.console is not None:
                        active.console.close()
                except Exception:
                    pass
                stopped = True
    except Exception:
        pass

    # 2. If port is bound (e.g. in another CPythonInvoker sub-interpreter), send 'c\n' via RFC 6455 WebSocket to /ws
    if is_webpdb_port_in_use(target_port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                sock.settimeout(1.0)
                sock.connect(('127.0.0.1', target_port))
                handshake = (
                    f"GET /ws HTTP/1.1\r\n"
                    f"Host: 127.0.0.1:{target_port}\r\n"
                    f"Upgrade: websocket\r\n"
                    f"Connection: Upgrade\r\n"
                    f"Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n"
                    f"Sec-WebSocket-Version: 13\r\n\r\n"
                ).encode('ascii')
                sock.sendall(handshake)
                resp = sock.recv(1024)
                if b"101" in resp:
                    # Masked RFC 6455 text frame (opcode 0x81) with payload b"c\n" (len 2, mask 0x12345678)
                    mask = b"\x12\x34\x56\x78"
                    payload = b"c\n"
                    masked_payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
                    frame = b"\x81\x82" + mask + masked_payload
                    # Follow with masked close frame (opcode 0x88, len 0)
                    close_frame = b"\x88\x80" + mask
                    sock.sendall(frame + close_frame)
                    stopped = True
                    log(f"Stopped active Web-PDB server on port {target_port}", 'info')
            finally:
                sock.close()
        except Exception as e:
            log(f"Web-PDB stop probe on port {target_port}: {e}", 'debug')

    return stopped


def start_webpdb_trace(port=None) -> bool:
    """Start an interactive Web-PDB debugging session on the configured port (default 5566)."""
    target_port = get_webpdb_port(port)
    if is_webpdb_port_in_use(target_port):
        log(f"Web-PDB port {target_port} is already active; skipping duplicate set_trace.", 'info')
        return True
    try:
        web_pdb = _load_webpdb()
        log(f"Starting Web-PDB trace on port {target_port}", 'info')
        web_pdb.set_trace(port=target_port)
        return True
    except Exception as e:
        log(f"Web-PDB set_trace failed on port {target_port}: {e}", 'warning')
        return False


class _NullContext:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        return False


def webpdb_post_mortem_context(port=None):
    """Return web_pdb.catch_post_mortem(port=...) context manager or a safe no-op context."""
    target_port = get_webpdb_port(port)
    try:
        web_pdb = _load_webpdb()
        if hasattr(web_pdb, 'catch_post_mortem'):
            return web_pdb.catch_post_mortem(port=target_port)
    except Exception as e:
        log(f"Web-PDB catch_post_mortem unavailable on port {target_port}: {e}", 'debug')
    return _NullContext()


def cleanup():
    """Explicitly release Kodi GUI dialogs, SQLite connections, and C++ resources on script shutdown."""
    global _directory_ended
    end_directory(succeeded=True, cacheToDisc=False)
    _directory_ended = False
    clearSettingsCache()
    try:
        from resources.lib.ui import database
        database.close_all_connections()
    except Exception:
        pass
    for proxy in (progressDialog, homeWindow, playerWindow, playList, ADDON, CONTEXT_ADDON, SERVICE_ADDON, settings, service_settings, monitor):
        try:
            proxy.cleanup()
        except Exception:
            pass
    try:
        from resources.lib.windows.base_window import BaseWindow
        BaseWindow.cleanup_all()
    except Exception:
        pass
    clean_memory()


_RE_KODI_TAG = re.compile(r'\[/?(?:COLOR(?:\s+[^\]]+|=.*?)?|B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE|CR)\]', re.IGNORECASE)
_RE_CONTROL_CHARS = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]')


def sanitize_dialog_text(text, strip_formatting=False) -> str:
    """Sanitize strings passed to Kodi UI dialogs to prevent formatting spoofing and control char injection."""
    if text is None:
        return ''
    if not isinstance(text, str):
        text = str(text)
    # Strip dangerous non-printable control characters and null bytes
    text = _RE_CONTROL_CHARS.sub('', text)
    if strip_formatting:
        text = _RE_KODI_TAG.sub('', text)
    return text.strip()


def closeAllDialogs():
    execute('Dialog.Close(all,true)')


def ok_dialog(title, text):
    return xbmcgui.Dialog().ok(sanitize_dialog_text(title), sanitize_dialog_text(text))


def textviewer_dialog(title, text):
    xbmcgui.Dialog().textviewer(sanitize_dialog_text(title), sanitize_dialog_text(text))


def yesno_dialog(title, text, nolabel=None, yeslabel=None):
    return xbmcgui.Dialog().yesno(sanitize_dialog_text(title), sanitize_dialog_text(text), nolabel, yeslabel)


def yesnocustom_dialog(title, text, customlabel='', nolabel='', yeslabel='', autoclose=0, defaultbutton=0):
    return xbmcgui.Dialog().yesnocustom(
        sanitize_dialog_text(title),
        sanitize_dialog_text(text),
        sanitize_dialog_text(customlabel),
        sanitize_dialog_text(nolabel),
        sanitize_dialog_text(yeslabel),
        autoclose,
        defaultbutton
    )


def notify(title, text, icon=OTAKU_LOGO3_PATH, time=5000, sound=False):
    xbmcgui.Dialog().notification(sanitize_dialog_text(title), sanitize_dialog_text(text), icon, time, sound)


def input_dialog(title, input_='', option=0):
    return xbmcgui.Dialog().input(sanitize_dialog_text(title), input_, option)


def multiselect_dialog(title, dialog_list, preselect=None):
    clean_list = [sanitize_dialog_text(item) if isinstance(item, str) else item for item in dialog_list]
    return xbmcgui.Dialog().multiselect(sanitize_dialog_text(title), clean_list, preselect=preselect)


def select_dialog(title, dialog_list, preselect=0):
    clean_list = [sanitize_dialog_text(item) if isinstance(item, str) else item for item in dialog_list]
    return xbmcgui.Dialog().select(sanitize_dialog_text(title), clean_list, preselect=preselect)


def numeric_dialog(type_, heading, default_value=''):
    return xbmcgui.Dialog().numeric(type_, sanitize_dialog_text(heading), default_value)


def context_menu(context_list):
    return xbmcgui.Dialog().contextmenu(context_list)


def browse(type_, heading, shares, mask=''):
    return xbmcgui.Dialog().browse(type_, heading, shares, mask)


# ═══════════════════════════════════════════════════════════════════════════
#  VideoTags - ListItem Metadata Builder
# ═══════════════════════════════════════════════════════════════════════════

def set_videotags(li, info):
    vinfo: xbmc.InfoTagVideo = li.getVideoInfoTag()
    if title := info.get('title') or info.get('title_userPreferred'):
        vinfo.setTitle(str(title))
    if media_type := info.get('mediatype') or info.get('format'):
        vinfo.setMediaType(str(media_type))
    if tvshow_title := info.get('tvshowtitle'):
        vinfo.setTvShowTitle(str(tvshow_title))
    if plot := info.get('plot'):
        vinfo.setPlot(str(plot))
    if season_plot := info.get('season_plot'):
        if hasattr(vinfo, 'setSeasonPlot'):
            try:
                vinfo.setSeasonPlot(str(season_plot))
            except Exception:
                pass
        li.setProperty('SeasonPlot', str(season_plot))
    if year := info.get('year'):
        try:
            vinfo.setYear(int(year))
        except (ValueError, TypeError):
            pass
    elif premiered := info.get('premiered'):
        # Fallback year extraction from Premiered date (YYYY-MM-DD)
        if len(str(premiered)) >= 4 and str(premiered)[:4].isdigit():
            try:
                vinfo.setYear(int(str(premiered)[:4]))
            except (ValueError, TypeError):
                pass
    dt_str = None
    if premiered := info.get('premiered'):
        vinfo.setPremiered(str(premiered))
        dt_str = str(premiered)
    elif aired := info.get('aired'):
        dt_str = str(aired)
    elif year := info.get('year'):
        try:
            fallback_date = f"{int(year):04d}-01-01"
            vinfo.setPremiered(fallback_date)
            dt_str = fallback_date
        except (ValueError, TypeError):
            pass
    if dt_str and hasattr(li, 'setDateTime'):
        dt_clean = dt_str.strip()[:10]
        if len(dt_clean) == 10 and dt_clean[4] == '-' and dt_clean[7] == '-':
            try:
                li.setDateTime(f"{dt_clean}T00:00:00")
            except Exception:
                pass
        elif len(dt_clean) >= 4 and dt_clean[:4].isdigit():
            try:
                li.setDateTime(f"{dt_clean[:4]}-01-01T00:00:00")
            except Exception:
                pass
    if status := info.get('status'):
        vinfo.setTvShowStatus(str(status))
    if genre := info.get('genre'):
        vinfo.setGenres([str(g) for g in genre] if isinstance(genre, list) else [str(genre)])
    if mpaa := info.get('mpaa'):
        vinfo.setMpaa(str(mpaa))
    if rating := info.get('rating') or info.get('score'):
        if isinstance(rating, dict):
            try:
                vinfo.setRating(float(rating.get('score', 0) or 0), int(rating.get('votes', 0) or 0))
            except (ValueError, TypeError):
                vinfo.setRating(0.0, 0)
        else:
            try:
                vinfo.setRating(float(rating), 0)
            except (ValueError, TypeError):
                vinfo.setRating(0.0, 0)
    if (season := info.get('season')) is not None and str(season).strip() != '':
        try:
            vinfo.setSeason(int(season))
        except (ValueError, TypeError):
            pass
    if episode := info.get('episode') or info.get('episodes') or info.get('total_episodes') or info.get('total_episodes_count'):
        try:
            vinfo.setEpisode(int(episode))
        except (ValueError, TypeError):
            pass
    if aired := info.get('aired'):
        vinfo.setFirstAired(str(aired))
    if playcount := info.get('playcount'):
        try:
            vinfo.setPlaycount(int(playcount))
        except (ValueError, TypeError):
            pass
    if duration := info.get('duration'):
        try:
            vinfo.setDuration(int(duration))
        except (ValueError, TypeError):
            pass
    if code := info.get('code'):
        vinfo.setProductionCode(str(code))
    if studio := info.get('studio'):
        if isinstance(studio, list):
            primary_studio = [s.strip() for s in studio if s and isinstance(s, str) and s.strip()][:1]
            if primary_studio:
                vinfo.setStudios(primary_studio)
                li.setProperty('Studios', ' / '.join(str(s) for s in studio if s))
                li.setProperty('Studio', primary_studio[0])
        elif isinstance(studio, str) and studio:
            clean_studios = [s.strip() for s in studio.split(' / ') if s.strip()]
            if clean_studios:
                vinfo.setStudios(clean_studios[:1])
                li.setProperty('Studios', studio)
                li.setProperty('Studio', clean_studios[0])
    if cast := info.get('cast'):
        vinfo.setCast([
            xbmc.Actor(
                str(c.get('name') or ''),
                str(c.get('role') or ''),
                int(c.get('index') or 0),
                str(c.get('thumbnail') or '')
            )
            for c in cast if isinstance(c, dict)
        ])
    if country := info.get('country'):
        vinfo.setCountries([str(c) for c in country] if isinstance(country, list) else [str(country)])
    if originaltitle := info.get('OriginalTitle') or info.get('originaltitle') or info.get('original_title'):
        vinfo.setOriginalTitle(str(originaltitle))
        li.setProperty('originaltitle', str(originaltitle))
        li.setProperty('OriginalTitle', str(originaltitle))
    if trailer := info.get('trailer'):
        vinfo.setTrailer(str(trailer))

    # Kodi 22+ InfoTagVideo enhancements: Tagline & BCP 47 OriginalLanguage
    if tagline := info.get('tagline'):
        if hasattr(vinfo, 'setTagLine'):
            try:
                vinfo.setTagLine(str(tagline))
            except Exception:
                pass
        li.setProperty('tagline', str(tagline))

    if original_language := info.get('originallanguage') or info.get('original_language'):
        if hasattr(vinfo, 'setOriginalLanguage'):
            try:
                vinfo.setOriginalLanguage(str(original_language))
            except Exception:
                pass
        li.setProperty('OriginalLanguage', str(original_language))
    elif country := info.get('country'):
        lang_map = {'JP': 'ja', 'CN': 'zh', 'KR': 'ko', 'US': 'en', 'GB': 'en'}
        c_code = country[0] if isinstance(country, list) and country else country
        if isinstance(c_code, str) and c_code.upper() in lang_map:
            inferred_lang = lang_map[c_code.upper()]
            if hasattr(vinfo, 'setOriginalLanguage'):
                try:
                    vinfo.setOriginalLanguage(inferred_lang)
                except Exception:
                    pass
            li.setProperty('OriginalLanguage', inferred_lang)

    # Kodi 22+ InfoTagVideo available fanart registration
    if fanarts := info.get('available_fanart') or info.get('fanarts'):
        if hasattr(vinfo, 'setAvailableFanart'):
            try:
                if isinstance(fanarts, list):
                    vinfo.setAvailableFanart([str(f) for f in fanarts if f])
            except Exception:
                pass

    if uniqueids := info.get('UniqueIDs'):
        uniqueids = {
            str(key): str(value)
            for key, value in uniqueids.items()
            if value is not None and str(value).strip() not in ('', 'None', 'null')
        }
        if uniqueids:
            default_uid = next(
                (k for k in ('tvdb', 'tmdb', 'imdb', 'trakt', 'mal', 'mal_id', 'anilist') if k in uniqueids),
                next(iter(uniqueids)),
            )
            try:
                vinfo.setUniqueIDs(uniqueids, default_uid)
            except TypeError:
                vinfo.setUniqueIDs(uniqueids)
            if 'imdb' in uniqueids:
                vinfo.setIMDBNumber(str(uniqueids['imdb']))
            for key, value in uniqueids.items():
                li.setProperty(key, str(value))

    if resume := info.get('resume'):
        try:
            vinfo.setResumePoint(float(resume), 1)
        except (ValueError, TypeError):
            pass

    # HDR surfacing: detect ONLY from explicit hdrtype/hdr_type/hdr, stream_info, or release_title
    # (never from generic anime display title info['title'])
    raw_hdr_hint = info.get('hdrtype') or info.get('hdr_type') or info.get('hdr') or ''
    stream_info_obj = info.get('stream_info')
    rel_title_hint = info.get('release_title') or ''
    if raw_hdr_hint or stream_info_obj is not None or rel_title_hint:
        from resources.lib.ui import source_utils as _su
        hdr_type = _su.detect_hdr_type(raw_hdr_hint or rel_title_hint, stream_info=stream_info_obj)
        hdr_badge = _su.format_hdr_badge(hdr_type)
        if hdr_type:
            if hasattr(vinfo, 'setHdrType'):
                try:
                    hdr_map = {'none': 0, 'hdr10': 1, 'hlg': 2, 'dolbyvision': 3, 'dv': 3, 'hdr10plus': 4, 'hdr': 1}
                    raw_low = str(raw_hdr_hint or hdr_type).strip().lower()
                    val = hdr_map.get(raw_low, hdr_map.get(hdr_type.lower(), int(raw_low) if raw_low.isdigit() else 1))
                    vinfo.setHdrType(val)
                except Exception:
                    pass
            li.setProperty('hdr_type', hdr_type)
            li.setProperty('hdr_badge', hdr_badge)
            li.setProperty('VideoResolution.HDRType', str(raw_hdr_hint or hdr_type))


def jsonrpc(json_data):
    return json.loads(xbmc.executeJSONRPC(json.dumps(json_data)))


def kodi_get_setting(setting_id):
    """Retrieve a Kodi system/GUI setting value via JSON-RPC."""
    try:
        res = jsonrpc({'jsonrpc': '2.0', 'method': 'Settings.GetSettingValue', 'params': {'setting': setting_id}, 'id': 1})
        val = res.get('result', {}).get('value')
        return val if val is not None else ''
    except Exception:
        return ''


# ═══════════════════════════════════════════════════════════════════════════
#  Kodi 22 Native Power, CEC & Database Helpers
# ═══════════════════════════════════════════════════════════════════════════

_CEC_INT_POWER_MAP = {
    0: 'on',
    1: 'standby',
    2: 'in_transition_to_on',
    3: 'in_transition_to_standby',
}
_STANDBY_POWER_STATES = frozenset({
    'standby', 'suspend', 'sleep', 'off', 'dpms', 'in_standby',
    'in_transition_to_standby', 'transition_to_standby',
})
_ACTIVE_POWER_STATES = frozenset({'on', 'active', 'in_transition_to_on', 'transition_to_on'})


def _query_kodi22_power_status():
    """Return ``(status, is_explicit)`` from Kodi 22 ``xbmc.getDevicePowerStatus()``.

    ``is_explicit`` is True only when the Kodi 22 C++ API exists and returned a
    recognized active or standby state; otherwise False (Kodi 20/21 or unknown).
    """
    getter = getattr(xbmc, 'getDevicePowerStatus', None)
    if callable(getter):
        try:
            status = getter()
            if isinstance(status, int) and not isinstance(status, bool):
                mapped = _CEC_INT_POWER_MAP.get(status, 'unknown')
                return mapped, (mapped != 'unknown')
            if isinstance(status, str):
                norm = status.strip().lower()
                if norm.isdigit():
                    mapped = _CEC_INT_POWER_MAP.get(int(norm), 'unknown')
                    return mapped, (mapped != 'unknown')
                if norm and norm != 'unknown':
                    return norm, (norm in _STANDBY_POWER_STATES or norm in _ACTIVE_POWER_STATES)
        except Exception:
            pass
    return 'unknown', False


def get_device_power_status():
    """Query HDMI/CEC display power state natively via Kodi 22 C++ API (defaults to 'on' when unavailable)."""
    status, is_explicit = _query_kodi22_power_status()
    return status if is_explicit else 'on'


def is_device_in_standby():
    """Return True if connected display/AVR is in standby/suspend mode (NF-16).

    Gated by ``general.standby_throttling`` (default True). On Kodi 22, trusts an
    explicit active ('on') response from ``xbmc.getDevicePowerStatus()`` without
    falling back to screensaver visibility; falls back to DPMS/screensaver only
    when power status is unavailable or 'unknown' (e.g., Kodi 20/21).
    """
    if not getBool('general.standby_throttling', True):
        return False
    status, is_explicit = _query_kodi22_power_status()
    if status in _STANDBY_POWER_STATES:
        return True
    if is_explicit and status in _ACTIVE_POWER_STATES:
        return False
    try:
        return bool(xbmc.getCondVisibility('System.DPMSActive | System.ScreenSaverActive'))
    except Exception:
        return False


def get_cec_adapter_names():
    """Enumerate active HDMI-CEC adapters via Kodi 22 C++ API."""
    getter = getattr(xbmc, 'getCecAdapterNames', None)
    if callable(getter):
        try:
            names = getter()
            if isinstance(names, (list, tuple)):
                return [str(n) for n in names if n is not None]
        except Exception:
            pass
    return []


def get_database_name(db_type='video'):
    """Resolve Kodi database filename dynamically via Kodi 22 C++ API or JSON-RPC."""
    if hasattr(xbmc, 'getDatabaseName'):
        try:
            name = xbmc.getDatabaseName(db_type)
            if isinstance(name, str):
                return name
        except Exception:
            pass
    try:
        res = jsonrpc({'jsonrpc': '2.0', 'method': 'Database.GetDatabaseName', 'params': {'type': db_type}, 'id': 1})
        if name := res.get('result', {}).get('name'):
            return name
    except Exception:
        pass
    return 'MyVideos149.db' if db_type == 'video' else 'MyMusic84.db'


# ═══════════════════════════════════════════════════════════════════════════
#  Directory Listing - draw_items / bulk_dir_list / xbmc_add_dir
# ═══════════════════════════════════════════════════════════════════════════

def clean_art_dict(art):
    """
    Sanitize an artwork dictionary to guarantee string keys and string values
    required by Kodi's C++ SWIG contracts (ListItem.setArt).
    Unwraps single-item lists/tuples to their first string element and drops non-strings.
    """
    if not isinstance(art, dict):
        return {}
    clean = {}
    for k, v in art.items():
        if not k or v is None:
            continue
        key_str = str(k)
        if isinstance(v, str):
            v_stripped = v.strip()
            if v_stripped:
                clean[key_str] = v_stripped
        elif isinstance(v, (list, tuple)) and v:
            first = v[0]
            if isinstance(first, str):
                first_stripped = first.strip()
                if first_stripped:
                    clean[key_str] = first_stripped
    return clean


def xbmc_add_dir(name, url, art, info, draw_cm, bulk_add, isfolder, isplayable, bulk_prefs=None):
    u = addon_url(url)
    liz = xbmcgui.ListItem(str(name or ''), offscreen=True)
    if info:
        set_videotags(liz, info)
        # Upcoming dub release: render in Label2 (right-aligned between title and watch indicator)
        _code = info.get('code')
        if isinstance(_code, str) and _code.startswith(('Dub ', 'Sub ')):
            liz.setLabel2(_code)
    if draw_cm:
        cm = [
            (
                x[0],
                x[1]
                if x[1].startswith(('RunPlugin(', 'PlayMedia(', 'Container.', 'ActivateWindow('))
                else f'RunPlugin(plugin://{ADDON_ID}/{x[1]}/{url})'
            )
            for x in draw_cm
        ]
        liz.addContextMenuItems(cm)
    # Check new artwork.fanart setting (inverted logic from old fanart_disable)
    if bulk_prefs is not None:
        artwork_fanart_enabled = bulk_prefs['artwork_fanart_enabled']
        fanart_select_enabled = bulk_prefs['fanart_select_enabled']
        artwork_clearlogo_enabled = bulk_prefs['artwork_clearlogo_enabled']
        artwork_studios_style = bulk_prefs.get('artwork_studios_style', 'coloured')
        fanart_mal_ids = bulk_prefs.get('fanart_mal_ids')
        fanart_selections = bulk_prefs.get('fanart_selections')
        fanart_map = bulk_prefs.get('fanart_map')
    else:
        artwork_fanart_enabled = getBool('artwork.fanart')
        fanart_select_enabled = getBool('context.otaku.fanartselect')
        artwork_clearlogo_enabled = getBool('artwork.clearlogo')
        artwork_studios_style = getSetting('artwork.studios') or 'coloured'
        fanart_mal_ids = None
        fanart_selections = None
        fanart_map = None

    art = dict(art or {})
    if not art.get('fanart') or not artwork_fanart_enabled:
        art['fanart'] = OTAKU_FANART
    else:
        if isinstance(art['fanart'], list):
            if fanart_select_enabled:
                if info.get('UniqueIDs', {}).get('mal_id'):
                    mal_id = str(info["UniqueIDs"]["mal_id"])

                    # Check cache first
                    cache_key = f"fanart_{mal_id}"
                    if cache_key in _artwork_cache:
                        art['fanart'] = _artwork_cache[cache_key]
                    else:
                        fanart_select = ''
                        if fanart_map is not None:
                            fanart_select = fanart_map.get(mal_id, '')
                        else:
                            if fanart_mal_ids is not None:
                                mal_ids = fanart_mal_ids
                                fanart_selections_list = fanart_selections or []
                            else:
                                mal_ids = getStringList('fanart.mal_ids')
                                fanart_selections_list = getStringList('fanart.selections')
                            f_map = dict(zip(mal_ids, fanart_selections_list))
                            fanart_select = f_map.get(mal_id, '')

                        selected = fanart_select if fanart_select else random.choice(art['fanart'])
                        _artwork_cache[cache_key] = selected
                        art['fanart'] = selected
                else:
                    art['fanart'] = OTAKU_FANART
            else:
                # Use cached random selection if available
                cache_key = f"fanart_{url}"
                if cache_key in _artwork_cache:
                    art['fanart'] = _artwork_cache[cache_key]
                else:
                    selected = random.choice(art['fanart'])
                    _artwork_cache[cache_key] = selected
                    art['fanart'] = selected
        # If fanart is already a string (pre-selected), use it directly

    # Check new artwork.clearlogo setting (inverted logic from old clearlogo_disable)
    if not artwork_clearlogo_enabled or not art.get('clearlogo'):
        art.pop('clearlogo', None)
    # If clearlogo is already a string (pre-selected), use it directly
    # No need for random.choice() since get_meta.py pre-selects it

    # Resolve anime studio logo from context.otaku.rpdev studio resources
    if artwork_studios_style and artwork_studios_style != 'none' and info:
        studio_val = info.get('studio')
        primary_studio_name = None
        if isinstance(studio_val, list):
            primary_studio_name = next((s.strip() for s in studio_val if s and isinstance(s, str) and s.strip()), None)
        elif isinstance(studio_val, str) and studio_val:
            parts = [s.strip() for s in studio_val.split(' / ') if s.strip()]
            if parts:
                primary_studio_name = parts[0]

        if primary_studio_name:
            studio_art = get_studio_logo_path(primary_studio_name, artwork_studios_style)
            if studio_art:
                art['studio'] = studio_art
                art['tvshow.studio'] = studio_art
                liz.setProperty('StudioIcon', studio_art)
                liz.setProperty('StudioLogo', studio_art)
                liz.setProperty('Studio.Icon', studio_art)
                liz.setProperty('Studio.Logo', studio_art)
                liz.setProperty('Studio.1.Icon', studio_art)
                liz.setProperty('Studio.1.Logo', studio_art)
                liz.setProperty('Studio.1.Art', studio_art)
                liz.setProperty('tvshow.studio', studio_art)
                liz.setProperty('Studio', primary_studio_name)

    if isplayable:
        if 'poster' in art and art['poster']:
            art['tvshow.poster'] = art.pop('poster')
        liz.setProperties({'Video': 'true', 'IsPlayable': 'true'})
    clean_art = clean_art_dict(art)
    liz.setArt(clean_art)
    # Pin pagination and filter control rows so Kodi sorting never scatters them into content
    if item_looks_like_next_page_row({'image': art}) or str(name or '').startswith('Next Page ('):
        liz.setProperty('SpecialSort', 'bottom')
    elif str(url or '').startswith(('multipage_filter', 'multipage_clear_filter', 'browse_year_filter')):
        liz.setProperty('SpecialSort', 'top')
    return (u, liz, isfolder) if bulk_add else xbmcplugin.addDirectoryItem(HANDLE, u, liz, isfolder)


def item_looks_like_next_page_row(item):
    """True when *item* is the standard Next page folder row (next.png artwork)."""
    if not isinstance(item, dict):
        return False
    img = item.get('image')
    if isinstance(img, dict):
        icon = img.get('icon') or ''
    elif isinstance(img, str):
        icon = img
    else:
        icon = ''
    norm = icon.replace('\\', '/').lower()
    return norm.endswith('/next.png') or norm.endswith('next.png')


def schedule_next_page_prefetch(items, prefetch_callable):
    """Prefetching inside short-lived directory invokers causes Kodi CPythonInvoker::onExecutionDone()
    to block waiting for thread termination, leading to 10-30s UI hangs and blocking subsequent directory navigation.
    Retained as safe no-op for backward compatibility."""
    return


def bulk_draw_items(video_data):
    list_items = bulk_dir_list(video_data, True)
    return xbmcplugin.addDirectoryItems(HANDLE, list_items)


_directory_ended = False


def end_directory(handle=None, succeeded=True, cacheToDisc=False):
    global _directory_ended
    if _directory_ended:
        return
    try:
        h = HANDLE if handle is None else handle
        if h is not None and h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=succeeded, cacheToDisc=cacheToDisc)
    except Exception:
        pass
    _directory_ended = True


def draw_items(video_data, content_type='', cacheToDisc=True):
    global _directory_ended
    bulk_draw_items(video_data)
    if content_type:
        xbmcplugin.setContent(HANDLE, content_type)
    if content_type == 'episodes':
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED, "%H. %T", "%R | %P")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_EPISODE, "%H. %T", "%R | %P")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING, "%H. %T", "%R")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE, "%H. %T", "%Y")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_PLAYCOUNT, "%H. %T", "%P")
    elif content_type in ('tvshows', 'movies', 'videos', 'seasons'):
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED, "%L", "%R")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE, "%L", "%R")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_DATE, "%L", "%Y")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING, "%L", "%R")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_EPISODE, "%L", "%E")
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_PLAYCOUNT, "%L", "%P")
    else:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED, "%L", "%R")
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cacheToDisc)
    _directory_ended = True
    closeAllDialogs()
    if getBool('interface.viewtype'):
        xbmc.sleep(100)  # Delay so the directory is painted before changing view mode
        if getBool('interface.viewidswitch'):
            if content_type == '' or content_type == 'addons':
                xbmc.executebuiltin('Container.SetViewMode(%d)' % getInt('interface.addon.view.id'))
            elif content_type == 'tvshows':
                xbmc.executebuiltin('Container.SetViewMode(%d)' % getInt('interface.show.view.id'))
            elif content_type == 'episodes':
                xbmc.executebuiltin('Container.SetViewMode(%d)' % getInt('interface.episode.view.id'))
        else:
            if content_type == '' or content_type == 'addons':
                xbmc.executebuiltin('Container.SetViewMode(%d)' % get_view_type(getSetting('interface.addon.view')))
            elif content_type == 'tvshows':
                xbmc.executebuiltin('Container.SetViewMode(%d)' % get_view_type(getSetting('interface.show.view')))
            elif content_type == 'episodes':
                xbmc.executebuiltin('Container.SetViewMode(%d)' % get_view_type(getSetting('interface.episode.view')))

    if content_type == "episodes" and getBool('general.smart.scroll.enable'):
        if getBool('interface.viewtype'):
            xbmc.sleep(150)  # View mode change can repaint the list; let infolabels settle
        wait_loop(50, 4500, f"plugin://{ADDON_ID}/animes", f'plugin://{ADDON_ID}/watchlist_to_ep',
                  require_item_count=True)
        win_obj = None
        try:
            for _ in range(16):
                try:
                    window_id = xbmcgui.getCurrentWindowId()
                    if window_id != 10025:
                        xbmc.sleep(80)
                        continue
                    if win_obj is None:
                        win_obj = xbmcgui.Window(10025)
                    active_id = win_obj.getFocusId()
                except Exception:
                    xbmc.sleep(80)
                    continue
                if not active_id:
                    xbmc.sleep(80)
                    continue
                try:
                    num_watched = int(xbmc.getInfoLabel("Container.TotalWatched"))
                    total_ep = int(xbmc.getInfoLabel('Container.NumItems'))
                    all_items = int(xbmc.getInfoLabel('Container.NumAllItems'))
                except ValueError:
                    xbmc.sleep(80)
                    continue
                if all_items <= 0:
                    xbmc.sleep(80)
                    continue
                offset = 1 if all_items > total_ep else 0
                target_index = num_watched + offset
                if not (0 < target_index < all_items):
                    break
                xbmc.executebuiltin('Action(firstpage)')
                xbmc.sleep(50)
                xbmc.executebuiltin(f'Control.SetFocus({active_id}, {target_index})')
                break
        finally:
            if win_obj is not None:
                del win_obj


def _dir_list_item_worker(item, bulk_add, bulk_prefs):
    return xbmc_add_dir(
        item['name'], item['url'], dict(item.get('image') or {}), item['info'], item['cm'],
        bulk_add, item['isfolder'], item['isplayable'], bulk_prefs,
    )


def bulk_dir_list(video_data, bulk_add=True):
    artwork_fanart_enabled = getBool('artwork.fanart')
    fanart_select_enabled = getBool('context.otaku.fanartselect')
    bulk_prefs = {
        'artwork_fanart_enabled': artwork_fanart_enabled,
        'fanart_select_enabled': fanart_select_enabled,
        'artwork_clearlogo_enabled': getBool('artwork.clearlogo'),
        'artwork_studios_style': getSetting('artwork.studios') or 'coloured',
    }
    if artwork_fanart_enabled and fanart_select_enabled:
        f_ids = getStringList('fanart.mal_ids')
        f_sels = getStringList('fanart.selections')
        bulk_prefs['fanart_mal_ids'] = f_ids
        bulk_prefs['fanart_selections'] = f_sels
        bulk_prefs['fanart_map'] = dict(zip(f_ids, f_sels))
    mapfunc = partial(_dir_list_item_worker, bulk_add=bulk_add, bulk_prefs=bulk_prefs)
    with ThreadPoolExecutor(max_workers=max_threads) as executor:
        list_items = list(executor.map(mapfunc, filter(None, video_data)))
    return list_items


# ═══════════════════════════════════════════════════════════════════════════
#  View Types
# ═══════════════════════════════════════════════════════════════════════════

def get_view_type(viewtype):
    viewTypes = {
        'Default': 50,
        'Poster': 51,
        'Icon Wall': 52,
        'Shift': 53,
        'Info Wall': 54,
        'Wide List': 55,
        'Wall': 500,
        'Banner': 501,
        'Fanart': 502,
        'List': 0
    }
    return viewTypes.get(viewtype, 50)


# ═══════════════════════════════════════════════════════════════════════════
#  Utilities
# ═══════════════════════════════════════════════════════════════════════════

def clear_settings(silent=False):
    """Factory reset add-on data, database, and settings to clean install state."""
    from resources.lib.ui import settings_manager
    return settings_manager.wipe_addon_data(silent=silent)


def exit_(code):
    sys.exit(code)


def is_addon_visible():
    try:
        if xbmcgui.getCurrentWindowId() == 10025:
            return True
    except Exception:
        pass
    if xbmc.getInfoLabel('Container.PluginName') == 'plugin.video.otaku.rpdev':
        return True
    folder_path = xbmc.getInfoLabel('Container.FolderPath')
    if folder_path and 'plugin.video.otaku.rpdev' in folder_path:
        return True
    return False


def abort_requested():
    return monitor.abortRequested()


def wait_for_abort(timeout=1.0):
    return monitor.waitForAbort(timeout)


def arc4(t, n):
    u = 0
    h = ''
    s = list(range(256))
    for e in range(256):
        x = t[e % len(t)]
        u = (u + s[e] + (x if isinstance(x, int) else ord(x))) % 256
        s[e], s[u] = s[u], s[e]

    e = u = 0
    for c in range(len(n)):
        e = (e + 1) % 256
        u = (u + s[e]) % 256
        s[e], s[u] = s[u], s[e]
        h += chr((n[c] if isinstance(n[c], int) else ord(n[c])) ^ s[(s[e] + s[u]) % 256])
    return h


def safe_call(func, *args, default=None, log_msg='', **kwargs):
    """Call func(*args, **kwargs), returning default on any exception.
    Optionally logs the error via control.log() if log_msg is provided."""
    try:
        return func(*args, **kwargs)
    except Exception as e:
        if log_msg:
            log(f'{log_msg}: {e}', 'error')
        return default


_JSON_DEFAULT_SENTINEL = object()


def safe_json(response, default=_JSON_DEFAULT_SENTINEL):
    """Safely parse a response or string/bytes as JSON, returning default on failure."""
    def_val = {} if default is _JSON_DEFAULT_SENTINEL else default
    if not response:
        return def_val
    if hasattr(response, 'json'):
        try:
            res = response.json()
            return res if res is not None else def_val
        except (ValueError, AttributeError, TypeError, json.JSONDecodeError):
            return def_val
    if isinstance(response, (str, bytes)):
        try:
            res = json.loads(response)
            return res if res is not None else def_val
        except (ValueError, AttributeError, TypeError, json.JSONDecodeError):
            return def_val
    try:
        res = response.json()
        return res if res is not None else def_val
    except (ValueError, AttributeError, TypeError, json.JSONDecodeError):
        return def_val


def loads_json(text, default=None):
    """Safely parse a JSON string, returning `default` on error or empty string."""
    if not text:
        return default
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError, ValueError):
        return default


def safe_next(iterable, default=None):
    """Safe wrapper around next() that returns default on StopIteration."""
    try:
        return next(iterable)
    except StopIteration:
        return default


def atomic_write_json(file_path: str, data: any, indent: int = 2) -> bool:
    """Atomically write JSON data to file_path via temporary swap."""
    parent_dir = os.path.dirname(os.path.abspath(file_path))
    if not os.path.exists(parent_dir):
        os.makedirs(parent_dir, exist_ok=True)
    tmp_path = f"{file_path}.{os.getpid()}.{threading.get_ident()}.tmp"
    try:
        with open(tmp_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=indent)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, file_path)
        return True
    except Exception as e:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError as rm_err:
                log(f"Failed to remove tmp file {tmp_path}: {rm_err}", 'debug')
        log(f"atomic_write_json failed for {file_path}: {e}", 'error')
        return False


def atomic_write_text(file_path: str, content: str, encoding: str = 'utf-8', vfs_path=None) -> bool:
    """Atomically write text content to file_path via temporary swap and Kodi VFS registration."""
    parent_dir = os.path.dirname(os.path.abspath(file_path))
    if not os.path.exists(parent_dir):
        os.makedirs(parent_dir, exist_ok=True)
    suffix = f".{os.getpid()}.{threading.get_ident()}.tmp"
    tmp_path = f"{file_path}{suffix}"
    try:
        with open(tmp_path, 'w', encoding=encoding) as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        renamed_via_vfs = False
        try:
            # Prefer xbmcvfs.rename() so Kodi C++ CFile::Rename() calls
            # g_directoryCache.ClearFile(tmp) + g_directoryCache.AddFile(dest).
            # When targeting special://temp/ (explicitly or by translated path),
            # rename via the special:// URI so COverrideFile::Rename() updates
            # BOTH the special:// and translated OS g_directoryCache keys.
            effective_vfs_path = vfs_path
            if not effective_vfs_path and hasattr(xbmcvfs, 'translatePath'):
                try:
                    temp_root = xbmcvfs.translatePath('special://temp/')
                    if temp_root and os.path.normpath(parent_dir) == os.path.normpath(temp_root):
                        effective_vfs_path = f"special://temp/{os.path.basename(file_path)}"
                except Exception:
                    pass
            if hasattr(xbmcvfs, 'rename'):
                if effective_vfs_path:
                    vfs_tmp = f"{effective_vfs_path}{suffix}"
                    if xbmcvfs.rename(vfs_tmp, effective_vfs_path):
                        if os.path.exists(file_path) and not os.path.exists(tmp_path):
                            renamed_via_vfs = True
                if not renamed_via_vfs and xbmcvfs.rename(tmp_path, file_path):
                    if os.path.exists(file_path) and not os.path.exists(tmp_path):
                        renamed_via_vfs = True
        except Exception:
            renamed_via_vfs = False
        if not renamed_via_vfs:
            os.replace(tmp_path, file_path)
        return True
    except Exception as e:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError as rm_err:
                log(f"Failed to remove tmp file {tmp_path}: {rm_err}", 'debug')
        log(f"atomic_write_text failed for {file_path}: {e}", 'error')
        return False


def atomic_write_bytes(file_path: str, content: bytes) -> bool:
    """Atomically write binary content to file_path via temporary swap."""
    parent_dir = os.path.dirname(os.path.abspath(file_path))
    if not os.path.exists(parent_dir):
        os.makedirs(parent_dir, exist_ok=True)
    tmp_path = f"{file_path}.{os.getpid()}.{threading.get_ident()}.tmp"
    try:
        with open(tmp_path, 'wb') as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, file_path)
        return True
    except Exception as e:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError as rm_err:
                log(f"Failed to remove tmp file {tmp_path}: {rm_err}", 'debug')
        log(f"atomic_write_bytes failed for {file_path}: {e}", 'error')
        return False


def print(string, *args):
    for i in list(args):
        string = f'{string} {i}'
    textviewer_dialog('print', f'{string}')
    del args, string


def timeIt(func):
    # Thanks to 123Venom
    def wrap(*args, **kwargs):
        import time
        started_at = time.perf_counter()
        result = func(*args, **kwargs)
        log(f">> {__name__}.{func.__name__} <<: {time.perf_counter() - started_at}")
        return result

    return wrap
