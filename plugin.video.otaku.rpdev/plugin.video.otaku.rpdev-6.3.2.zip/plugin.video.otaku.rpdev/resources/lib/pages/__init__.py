import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from functools import partial

from resources.lib.pages import (
    nyaa, animetosho, nekobt, torrentio, debrid_cloudfiles, easynews,
    animepahe, anikoto, hianime, watchnixtoons2, localfiles,
    bitsearch, piratebay, gogoanime
)
from resources.lib.ui import control, database, domains, source_utils
from resources.lib.windows.get_sources_window import GetSources
from resources.lib.windows import sort_select

_SIZE_RE = re.compile(r'([\d.]+)\s*([KMGTP]?B)', re.IGNORECASE)
_RELEASE_GROUP_RE = re.compile(r'^\[([^\]]+)\]')


# (python_module, database.get cache key) — provider ids = dict keys below (insertion order)
_TORRENT_MODULES = {
    'nyaa': (nyaa, 'nyaa'),
    'animetosho': (animetosho, 'animetosho'),
    'nekobt': (nekobt, 'nekobt'),
    'torrentio': (torrentio, 'torrentio'),
    'bitsearch': (bitsearch, 'bitsearch'),
    'piratebay': (piratebay, 'piratebay'),
}

# (module, cache_key, enabled_fn, merge_mode) — provider ids = dict keys below
# merge_mode: 'torrent_full' (cached+uncached → torrent lists) | 'cached_only' (cached only → hosterSources)
_HOSTER_MODULES = {
    'easynews': (easynews, 'easynews', control.easynews_enabled, 'cached_only'),
}

# (provider_id, module, database.get key, skip window prefix or None, pass_media_type)
# skip prefix drives _apply_embed_skip (hianime / anikoto)
_EMBED_MODULES = (
    ('animepahe', animepahe, 'animepahe', None, False),
    ('gogo', gogoanime, 'gogoanime', None, False),
    # ('animix', animixplay, 'animix', None, False),
    # ('aniwave', aniwave, 'aniwave', 'aniwave', False),
    ('hianime', hianime, 'hianime', 'hianime', False),
    # ('animekai', animekai, 'animekai', 'animekai', False),
    ('anikoto', anikoto, 'anikoto', 'anikoto', False),
    ('watchnixtoons2', watchnixtoons2, 'watchnixtoons2', None, True),
)

# Single source of truth for active embed skip-time prefixes
EMBED_SKIP_PREFIXES = tuple(dict.fromkeys(row[3] for row in _EMBED_MODULES if row[3]))


ScraperCircuitBreaker = domains.AdaptiveCircuitBreaker
circuit_breaker = domains.adaptive_circuit_breaker


def getSourcesHelper(actionArgs):
    sources_window = None
    try:
        if control.getInt('general.dialog') in (5, 6):
            sources_window = Sources('get_sources_alt.xml', control.ADDON_PATH, actionArgs=actionArgs)
        else:
            sources_window = Sources('get_sources.xml', control.ADDON_PATH, actionArgs=actionArgs)
        return sources_window.doModal()
    finally:
        if sources_window:
            try:
                sources_window.close()
            except Exception:
                pass
            del sources_window


def _scraper_cache_ttl():
    return control.getInt('cache.scrapers.ttl') or 8


_scrape_semaphore = threading.Semaphore(control.max_threads)
_current_workers = None
_semaphore_lock = threading.Lock()


def _get_scrape_semaphore():
    global _scrape_semaphore, _current_workers
    workers = control.getInt('scraper.concurrency.workers') or control.max_threads
    if _current_workers != workers:
        with _semaphore_lock:
            if _current_workers != workers:
                _current_workers = workers
                _scrape_semaphore = threading.Semaphore(max(2, min(workers, 16)))
    return _scrape_semaphore


class Sources(GetSources):
    _scrape_semaphore = _scrape_semaphore
    _current_semaphore = None
    _current_workers = None

    @classmethod
    def _get_semaphore(cls):
        sem = _get_scrape_semaphore()
        try:
            cls._current_workers = _current_workers
            cls._current_semaphore = sem
            cls._scrape_semaphore = sem
        except Exception:
            pass
        return sem

    def __init__(self, xml_file, location, actionArgs=None):
        super().__init__(xml_file, location, actionArgs=actionArgs)
        self.torrentProviders = [row[0] for row in _TORRENT_MODULES.items()]
        self.embedProviders = [row[0] for row in _EMBED_MODULES]
        self.hosterProviders = [row[0] for row in _HOSTER_MODULES.items()]
        self.CloudProviders = ['Cloud Inspection']
        self.localProviders = ['Local Inspection']
        self.remainingProviders = (
            self.embedProviders + self.torrentProviders + self.hosterProviders + self.localProviders + self.CloudProviders
        )

        self.torrents_qual_len = [0, 0, 0, 0, 0]
        self.hosters_qual_len = [0, 0, 0, 0, 0]
        self.embeds_qual_len = [0, 0, 0, 0, 0]
        self.return_data = []
        self.progress = 1
        self.threads = []

        self.torrentSources = []
        self.torrentCacheSources = []
        self.torrentUnCacheSources = []
        self.hosterSources = []
        self.embedSources = []
        self.cloud_files = []
        self.local_files = []
        self._results_lock = threading.Lock()

    @classmethod
    def _start_worker(cls, fn):
        sem = _get_scrape_semaphore()
        def _throttled_fn():
            with sem:
                fn()
        t = threading.Thread(target=_throttled_fn, daemon=True)
        t.start()
        return t

    def getSources(self, args):
        query = args['query']
        mal_id = args['mal_id']
        episode = args['episode']
        status = args['status']
        media_type = args['media_type']
        duration = args['duration']
        rescrape = args['rescrape']
        season = args.get('season')
        part = args.get('part')
        hints = args.get('hints')

        self.setProperty('process_started', 'true')

        for prefix in EMBED_SKIP_PREFIXES:
            for key in ('skipintro.start', 'skipintro.end', 'skipoutro.start', 'skipoutro.end'):
                control.setInt(f'{prefix}.{key}', -1)

        enabled_debrids = control.enabled_debrid()
        enabled_clouds = control.enabled_cloud()
        common_debrids = [
            service for service, is_enabled in enabled_debrids.items()
            if is_enabled and enabled_clouds.get(service, False)
        ]

        debrid_on = any(enabled_debrids.values())
        t_args = (query, mal_id, episode, status, media_type, rescrape, season, part, hints)

        if rescrape:
            circuit_breaker.reset()

        for provider in self.torrentProviders:
            if debrid_on and control.getBool(f'provider.{provider}'):
                if not rescrape and circuit_breaker.is_tripped(provider):
                    control.log(f"CircuitBreaker: Skipping '{provider}' (circuit open)", 'info')
                    with self._results_lock:
                        if provider in self.remainingProviders:
                            self.remainingProviders.remove(provider)
                    continue
                self.threads.append(self._start_worker(partial(self._torrent_sources_worker, provider, *t_args)))
            else:
                with self._results_lock:
                    if provider in self.remainingProviders:
                        self.remainingProviders.remove(provider)

        for hoster in self.hosterProviders:
            spec = _HOSTER_MODULES.get(hoster)
            if spec and spec[2]():
                if not rescrape and circuit_breaker.is_tripped(hoster):
                    control.log(f"CircuitBreaker: Skipping '{hoster}' (circuit open)", 'info')
                    with self._results_lock:
                        if hoster in self.remainingProviders:
                            self.remainingProviders.remove(hoster)
                    continue
                self.threads.append(self._start_worker(partial(self._hoster_sources_worker, hoster, *t_args)))
            else:
                with self._results_lock:
                    if hoster in self.remainingProviders:
                        self.remainingProviders.remove(hoster)

        if common_debrids:
            self.threads.append(self._start_worker(partial(self.user_cloud_inspection, query, mal_id, episode, season)))
        else:
            with self._results_lock:
                if 'Cloud Inspection' in self.remainingProviders:
                    self.remainingProviders.remove('Cloud Inspection')

        if control.getBool('provider.localfiles'):
            self.threads.append(self._start_worker(partial(self.user_local_inspection, query, mal_id, episode, season)))
        else:
            with self._results_lock:
                if 'Local Inspection' in self.remainingProviders:
                    self.remainingProviders.remove('Local Inspection')

        for pid, mod, cache_key, skip_prefix, needs_media_type in _EMBED_MODULES:
            if control.getBool(f'provider.{pid}'):
                if not rescrape and circuit_breaker.is_tripped(pid):
                    control.log(f"CircuitBreaker: Skipping '{pid}' (circuit open)", 'info')
                    with self._results_lock:
                        if pid in self.remainingProviders:
                            self.remainingProviders.remove(pid)
                    continue
                self.threads.append(self._start_worker(partial(
                    self._embed_sources_worker,
                    pid, mod, cache_key, skip_prefix, needs_media_type,
                    mal_id, episode, media_type, rescrape,
                )))
            else:
                with self._results_lock:
                    if pid in self.remainingProviders:
                        self.remainingProviders.remove(pid)

        timeout = 30 if rescrape else min(30, max(5, control.getInt('general.timeout') or 20))
        start_time = time.perf_counter()
        runtime = 0

        try:
            while runtime < timeout:
                if not self.silent:
                    self.updateProgress()
                    self.update_properties("4K: %s | 1080: %s | 720: %s | SD: %s| EQ: %s" % (
                        control.colorstr(self.torrents_qual_len[0] + self.hosters_qual_len[0] + self.embeds_qual_len[0]),
                        control.colorstr(self.torrents_qual_len[1] + self.hosters_qual_len[1] + self.embeds_qual_len[1]),
                        control.colorstr(self.torrents_qual_len[2] + self.hosters_qual_len[2] + self.embeds_qual_len[2]),
                        control.colorstr(self.torrents_qual_len[3] + self.hosters_qual_len[3] + self.embeds_qual_len[3]),
                        control.colorstr(self.torrents_qual_len[4] + self.hosters_qual_len[4] + self.embeds_qual_len[4])
                    ))
                control.sleep(100)

                with self._results_lock:
                    no_remaining = not self.remainingProviders
                    has_cloud = len(self.cloud_files) > 0
                    has_local = len(self.local_files) > 0
                    has_torrent = len(self.torrentSources) > 0

                if (
                    self.canceled
                    or control.abort_requested()
                    or no_remaining
                    or (control.getBool('general.terminate.oncloud') and has_cloud)
                    or (control.getBool('general.terminate.onlocal') and has_local)
                    or (control.getBool('general.terminate.ontorrent') and has_torrent)
                ):
                    break

                runtime = time.perf_counter() - start_time
                self.progress = runtime / timeout * 100

            if len(self.torrentSources) + len(self.hosterSources) + len(self.embedSources) + len(self.cloud_files) + len(self.local_files) == 0:
                self.return_data = []
            else:
                from resources.lib.ui import part_filter
                self.torrentSources = part_filter.filter_sources(self.torrentSources, mal_id=mal_id, episode=episode, season=season, part=part)
                self.hosterSources = part_filter.filter_sources(self.hosterSources, mal_id=mal_id, episode=episode, season=season, part=part)
                self.embedSources = part_filter.filter_sources(self.embedSources, mal_id=mal_id, episode=episode, season=season, part=part)
                self.cloud_files = part_filter.filter_sources(self.cloud_files, mal_id=mal_id, episode=episode, season=season, part=part)
                self.return_data = self.sortSources(self.torrentSources, self.hosterSources, self.embedSources, self.cloud_files, self.local_files, media_type, duration, mal_id=mal_id, show_title=query, season=season)
        except Exception as e:
            control.log(f"Error in getSources: {e}", 'error')
            self.return_data = []
        finally:
            self.canceled = True
            self.close()
        return self.return_data

    def _torrent_sources_worker(self, provider, query, mal_id, episode, status, media_type, rescrape, season, part, hints=None):
        if self.canceled or control.abort_requested():
            return
        try:
            import inspect
            mod, cache_key = _TORRENT_MODULES[provider]
            get_sources = mod.Sources().get_sources
            call_args = (query, mal_id, episode, status, media_type, season, part)
            accepts_hints = False
            try:
                accepts_hints = 'hints' in inspect.signature(get_sources).parameters
            except Exception:
                pass
            if rescrape:
                if accepts_hints:
                    all_sources = get_sources(*call_args, rescrape=True, hints=hints)
                else:
                    all_sources = get_sources(*call_args, rescrape=True)
            else:
                if accepts_hints and hints:
                    all_sources = database.get(get_sources, _scraper_cache_ttl(), *call_args, False, hints, key=cache_key)
                else:
                    all_sources = database.get(get_sources, _scraper_cache_ttl(), *call_args, key=cache_key)
            if self.canceled or control.abort_requested():
                return
            if not all_sources:
                all_sources = {'cached': [], 'uncached': []}
            cached_list = all_sources.get('cached', [])
            uncached_list = all_sources.get('uncached', [])
            if cached_list or uncached_list:
                circuit_breaker.record_success(provider)
            control.log(
                f"{provider}: {len(cached_list)} cached, {len(uncached_list)} uncached torrent source(s)",
                'info',
            )
            with self._results_lock:
                self.torrentUnCacheSources += uncached_list
                self.torrentCacheSources += cached_list
                self.torrentSources += cached_list + uncached_list
        except Exception as e:
            circuit_breaker.record_failure(provider)
            control.log(f"Error in torrent worker '{provider}': {e}", 'error')
        finally:
            with self._results_lock:
                if provider in self.remainingProviders:
                    self.remainingProviders.remove(provider)

    def _hoster_sources_worker(self, hoster, query, mal_id, episode, status, media_type, rescrape, season, part, hints=None):
        if self.canceled or control.abort_requested():
            return
        try:
            import inspect
            mod, cache_key, _, merge_mode = _HOSTER_MODULES[hoster]
            get_sources = mod.Sources().get_sources
            call_args = (query, mal_id, episode, status, media_type, season, part)
            accepts_hints = False
            try:
                accepts_hints = 'hints' in inspect.signature(get_sources).parameters
            except Exception:
                pass
            if rescrape:
                if accepts_hints:
                    all_sources = get_sources(*call_args, rescrape=True, hints=hints)
                else:
                    all_sources = get_sources(*call_args)
            else:
                if accepts_hints and hints:
                    all_sources = database.get(get_sources, _scraper_cache_ttl(), *call_args, False, hints, key=cache_key)
                else:
                    all_sources = database.get(get_sources, _scraper_cache_ttl(), *call_args, key=cache_key)
            if self.canceled or control.abort_requested():
                return
            if not all_sources:
                all_sources = {'cached': [], 'uncached': []}
            if all_sources.get('cached') or all_sources.get('uncached'):
                circuit_breaker.record_success(hoster)
            with self._results_lock:
                if merge_mode == 'cached_only':
                    self.hosterSources += all_sources.get('cached', [])
                else:
                    self.torrentUnCacheSources += all_sources.get('uncached', [])
                    self.torrentCacheSources += all_sources.get('cached', [])
                    self.torrentSources += all_sources.get('cached', []) + all_sources.get('uncached', [])
        except Exception as e:
            circuit_breaker.record_failure(hoster)
            control.log(f"Error in hoster worker '{hoster}': {e}", 'error')
        finally:
            with self._results_lock:
                if hoster in self.remainingProviders:
                    self.remainingProviders.remove(hoster)

    def _embed_sources_worker(self, pid, mod, cache_key, skip_prefix, needs_media_type, mal_id, episode, media_type, rescrape):
        if self.canceled or control.abort_requested():
            return
        try:
            get_sources = mod.Sources().get_sources
            if needs_media_type:
                if rescrape:
                    src = get_sources(mal_id, episode, media_type)
                else:
                    src = database.get(get_sources, _scraper_cache_ttl(), mal_id, episode, media_type, key=cache_key)
            else:
                if rescrape:
                    src = get_sources(mal_id, episode)
                else:
                    src = database.get(get_sources, _scraper_cache_ttl(), mal_id, episode, key=cache_key)
            if self.canceled or control.abort_requested():
                return
            if not src:
                src = []
            else:
                circuit_breaker.record_success(pid)
            with self._results_lock:
                self.embedSources += src
            if skip_prefix:
                self._apply_embed_skip(skip_prefix, src)
        except Exception as e:
            circuit_breaker.record_failure(pid)
            control.log(f"Error in embed worker '{pid}': {e}", 'error')
        finally:
            with self._results_lock:
                if pid in self.remainingProviders:
                    self.remainingProviders.remove(pid)

    def user_local_inspection(self, query, mal_id, episode, season):
        if self.canceled or control.abort_requested():
            return
        try:
            res = localfiles.Sources().get_sources(query, mal_id, episode, season)
            if self.canceled or control.abort_requested():
                return
            if res:
                with self._results_lock:
                    self.local_files += res
        except Exception as e:
            control.log(f"Error in local inspection worker: {e}", 'error')
        finally:
            with self._results_lock:
                if 'Local Inspection' in self.remainingProviders:
                    self.remainingProviders.remove('Local Inspection')

    def user_cloud_inspection(self, query, mal_id, episode, season):
        if self.canceled or control.abort_requested():
            return
        try:
            res = debrid_cloudfiles.Sources().get_sources(query, mal_id, episode, season)
            if self.canceled or control.abort_requested():
                return
            if res:
                with self._results_lock:
                    self.cloud_files += res
        except Exception as e:
            control.log(f"Error in cloud inspection worker: {e}", 'error')
        finally:
            with self._results_lock:
                if 'Cloud Inspection' in self.remainingProviders:
                    self.remainingProviders.remove('Cloud Inspection')

    def _apply_embed_skip(self, prefix, sources):
        for x in sources:
            sk = x.get('skip')
            if not sk:
                continue
            intro = sk.get('intro')
            if intro and intro.get('start'):
                control.setInt(f'{prefix}.skipintro.start', int(intro['start']))
                control.setInt(f'{prefix}.skipintro.end', int(intro['end']))
            outro = sk.get('outro')
            if outro and outro.get('start'):
                control.setInt(f'{prefix}.skipoutro.start', int(outro['start']))
                control.setInt(f'{prefix}.skipoutro.end', int(outro['end']))

    @staticmethod
    def sortSources(torrent_list, hoster_list, embed_list, cloud_files, local_files, media_type, duration, mal_id=None, show_title=None, aliases=None, season=None):
        all_list = torrent_list + hoster_list + embed_list + cloud_files + local_files
        sortedList = [x for x in all_list if control.getInt('general.minResolution') <= x['quality'] <= control.getInt('general.maxResolution')]

        combined = torrent_list + hoster_list

        # Filter by size
        filter_option = control.getInt('general.fileFilter')

        def _get_size_in_gb(item):
            size_gb = None
            byte_size = item.get('byte_size')
            if byte_size and isinstance(byte_size, (int, float)) and byte_size > 0:
                size_gb = byte_size / (1024.0 ** 3)
            else:
                raw_size = item.get('size')
                if raw_size and isinstance(raw_size, str):
                    raw_size = raw_size.strip()
                    if raw_size.upper() not in ('NA', 'N/A', 'UNKNOWN', 'NONE', ''):
                        match = _SIZE_RE.search(raw_size)
                        if match:
                            try:
                                num = float(match.group(1))
                                unit = match.group(2).upper()
                                if unit == 'TB':
                                    size_gb = num * 1024.0
                                elif unit == 'GB':
                                    size_gb = num
                                elif unit == 'MB':
                                    size_gb = num / 1024.0
                                elif unit == 'KB':
                                    size_gb = num / (1024.0 ** 2)
                                elif unit == 'B':
                                    size_gb = num / (1024.0 ** 3)
                                else:
                                    size_gb = num
                            except (ValueError, TypeError):
                                size_gb = None
            if size_gb is not None and media_type != 'movie' and source_utils.is_season_pack(item):
                ep_range = source_utils.extract_episode_range(item.get('release_title') or '')
                ep_count = max(1, ep_range[1] - ep_range[0] + 1) if ep_range else 12
                size_gb = size_gb / ep_count
            return size_gb

        if filter_option == 1:
            # web speed limit
            webspeed = control.getInt('general.webspeed')
            try:
                dur_val = float(duration) if duration else 0
            except (ValueError, TypeError):
                dur_val = 0
            len_in_sec = dur_val * 60

            if len_in_sec > 0:
                _combined = combined
                combined = []
                for i in _combined:
                    size_gb = _get_size_in_gb(i)
                    if size_gb is not None:
                        if ((size_gb * 8000) / len_in_sec) <= webspeed:
                            combined.append(i)
                    else:
                        combined.append(i)

        elif filter_option == 2:
            # hard limit
            if media_type == 'movie':
                max_GB = float(control.getInt('general.movie.maxGB'))
                min_GB = control.getNumber('general.movie.minGB')
            else:
                max_GB = float(control.getInt('general.episode.maxGB'))
                min_GB = control.getNumber('general.episode.minGB')

            _combined = combined
            combined = []
            for i in _combined:
                size_gb = _get_size_in_gb(i)
                if size_gb is not None:
                    if min_GB <= size_gb <= max_GB:
                        combined.append(i)
                else:
                    combined.append(i)

        # Filter by release title
        if control.getBool('general.release_title_filter.enabled'):
            release_title_filter1 = control.getSetting('general.release_title_filter.value1')
            release_title_filter2 = control.getSetting('general.release_title_filter.value2')
            release_title_filter3 = control.getSetting('general.release_title_filter.value3')
            release_title_filter4 = control.getSetting('general.release_title_filter.value4')
            release_title_filter5 = control.getSetting('general.release_title_filter.value5')

            # Get the new settings
            exclude_filter1 = control.getBool('general.release_title_filter.exclude1')
            exclude_filter2 = control.getBool('general.release_title_filter.exclude2')
            exclude_filter3 = control.getBool('general.release_title_filter.exclude3')
            exclude_filter4 = control.getBool('general.release_title_filter.exclude4')
            exclude_filter5 = control.getBool('general.release_title_filter.exclude5')

            _combined = combined
            release_title_logic = control.getInt('general.release_title_filter.logic')
            if release_title_logic == 0:
                # AND filter (case-insensitive)
                combined = [
                    i for i in _combined
                    if (not exclude_filter1 or release_title_filter1.lower() not in i['release_title'].lower())
                    and (not exclude_filter2 or release_title_filter2.lower() not in i['release_title'].lower())
                    and (not exclude_filter3 or release_title_filter3.lower() not in i['release_title'].lower())
                    and (not exclude_filter4 or release_title_filter4.lower() not in i['release_title'].lower())
                    and (not exclude_filter5 or release_title_filter5.lower() not in i['release_title'].lower())
                ]
            if release_title_logic == 1:
                # OR filter (case-insensitive)
                combined = [
                    i for i in _combined
                    if (release_title_filter1 != "" and (exclude_filter1 ^ (release_title_filter1.lower() in i['release_title'].lower())))
                    or (release_title_filter2 != "" and (exclude_filter2 ^ (release_title_filter2.lower() in i['release_title'].lower())))
                    or (release_title_filter3 != "" and (exclude_filter3 ^ (release_title_filter3.lower() in i['release_title'].lower())))
                    or (release_title_filter4 != "" and (exclude_filter4 ^ (release_title_filter4.lower() in i['release_title'].lower())))
                    or (release_title_filter5 != "" and (exclude_filter5 ^ (release_title_filter5.lower() in i['release_title'].lower())))
                ]

        sortedList = [x for x in sortedList if x in combined or x in embed_list or x in cloud_files or x in local_files]

        # Apply general.filters (comprehensive filtering like Seren)
        filter_list = control.getStringList("general.filters")
        if filter_list:
            current_filters = set(filter_list)
            # Special HDR/DV handling (like Seren does for HYBRID sources)
            disable_dv = "DV" in current_filters
            disable_hdr = "HDR" in current_filters
            filter_set = current_filters.difference({"HDR", "DV"})

            filtered = []
            for source in sortedList:
                s_info = source.get('info') or []
                # Skip if ANY filtered tag is in source info (set intersection)
                if filter_set & set(s_info):
                    continue
                # DV filter: exclude DV sources unless they're HYBRID
                if disable_dv and "DV" in s_info and "HYBRID" not in s_info:
                    continue
                # HDR filter: exclude HDR sources unless they're HYBRID
                if disable_hdr and "HDR" in s_info and "HYBRID" not in s_info:
                    continue
                # Hybrid filter: if both DV and HDR are disabled, exclude HYBRID too
                if disable_dv and disable_hdr and "HYBRID" in s_info:
                    continue
                filtered.append(source)
            sortedList = filtered

        # Filter by language source (supports Multi/Dual-Audio releases carrying MULTI-SUB info tags)
        source = control.getInt("general.source")
        before_audio_torrents = sum(1 for x in sortedList if 'torrent' in str(x.get('type', '')))
        if source != 0:
            sortedList = source_utils.filter_sources_by_audio(sortedList, source)
        after_audio_torrents = sum(1 for x in sortedList if 'torrent' in str(x.get('type', '')))

        # Resolve target show title, aliases, and premiere year for relevance scoring
        target_title = show_title
        target_aliases = list(aliases) if aliases else []
        target_year = None

        def _append_alias(val):
            if val and isinstance(val, str):
                cleaned = val.strip()
                if cleaned and cleaned != target_title and cleaned not in target_aliases:
                    target_aliases.append(cleaned)

        if target_title and '|' in target_title:
            parsed_titles = source_utils.parse_query_titles(target_title)
            if parsed_titles:
                target_title = parsed_titles[0]
                for extra in parsed_titles[1:]:
                    _append_alias(extra)

        if mal_id:
            try:
                show_row = database.get_show(mal_id)
                if show_row and isinstance(show_row, dict):
                    kodi_meta = database.loads(show_row.get('kodi_meta'))
                    if isinstance(kodi_meta, dict) and kodi_meta:
                        if not target_title:
                            target_title = kodi_meta.get('name') or kodi_meta.get('ename')
                        for key in ('name', 'ename', 'title_userPreferred', 'title_english', 'title_romaji'):
                            _append_alias(kodi_meta.get(key))
                        if kodi_meta.get('year'):
                            target_year = str(kodi_meta.get('year'))
                    else:
                        if not target_title:
                            target_title = show_row.get('name') or show_row.get('ename')
                        for key in ('name', 'ename', 'title_english', 'title_romaji'):
                            _append_alias(show_row.get(key))
                        if show_row.get('year'):
                            target_year = str(show_row.get('year'))
            except Exception:
                pass
            try:
                show_meta = database.get_show_meta(mal_id)
                if show_meta and isinstance(show_meta, dict):
                    meta_ids = database.loads(show_meta.get('meta_ids'))
                    if isinstance(meta_ids, dict) and meta_ids:
                        _append_alias(meta_ids.get('mal_title'))
                    else:
                        if not target_title:
                            target_title = show_meta.get('name') or show_meta.get('ename')
                        for key in ('name', 'ename', 'title_english', 'title_romaji'):
                            _append_alias(show_meta.get(key))
            except Exception:
                pass
            try:
                mal_id_int = int(mal_id)
                enrichment_map = database.get_anilist_enrichment_batch([mal_id_int], max_age_hours=24 * 365)
                enrich = enrichment_map.get(mal_id_int) if isinstance(enrichment_map, dict) else None
                if isinstance(enrich, dict):
                    al_titles = enrich.get('title') or {}
                    if isinstance(al_titles, dict):
                        for key in ('romaji', 'english', 'userPreferred'):
                            _append_alias(al_titles.get(key))
                    for syn in (enrich.get('synonyms') or []):
                        _append_alias(syn)
                    start_date = enrich.get('startDate') or {}
                    if not target_year and isinstance(start_date, dict) and start_date.get('year'):
                        target_year = str(start_date.get('year'))
            except Exception:
                pass

        # C-20: For sequel seasons (season >= 2) with arc subtitles (e.g. "Blue Exorcist: Shimane Illuminati Saga"),
        # register "<Franchise Base> Season N" aliases so season-numbered releases ("Blue Exorcist S03") pass the gate.
        resolved_season_int = None
        try:
            if season is not None and str(season).isdigit():
                resolved_season_int = int(season)
            elif mal_id:
                mp = database.get_mappings(mal_id, 'mal_id')
                tvdb_s = mp.get('thetvdb_season') if isinstance(mp, dict) else None
                if tvdb_s is not None and str(tvdb_s).isdigit():
                    resolved_season_int = int(tvdb_s)
        except Exception:
            resolved_season_int = None

        if resolved_season_int and resolved_season_int >= 2:
            target_aliases = source_utils.expand_sequel_season_aliases(target_title, target_aliases, resolved_season_int)

        if target_title:
            for s in sortedList:
                if 'relevance' not in s:
                    s_title = s.get('release_title') or s.get('name') or ''
                    if s_title:
                        s['relevance'] = source_utils.score_title_candidate(
                            target_title, s_title, aliases=target_aliases, year=target_year
                        )

        # Gate out derivative/unrelated sources (relevance <= 40) when high-confidence sources exist
        has_high_relevance = any(x.get('relevance') is not None and x.get('relevance') >= 100 for x in sortedList)
        if has_high_relevance:
            sortedList = [x for x in sortedList if x.get('relevance') is None or x.get('relevance') > 40]
        after_rel_torrents = sum(1 for x in sortedList if 'torrent' in str(x.get('type', '')))
        control.log(
            f"sortSources: torrents raw={len(torrent_list)} -> audio_filter={after_audio_torrents} "
            f"(before_audio={before_audio_torrents}, lang_pref={source}) -> relevance_gate={after_rel_torrents}; "
            f"total_final={len(sortedList)}",
            'info',
        )

        # Sort sources (Seren-style composite keys; fresh sort_options.json)
        sortedList = sort_select.sort_sources_list(sortedList)

        # Relevance tier sorting: enforce exact/canonical matches (Tier 0) and high-confidence
        # matches (Tier 1) rank above partial/unrated/derivative matches before quality/size.
        def _get_relevance_tier(item):
            rel = item.get('relevance')
            if rel is None:
                return 2
            if rel >= 140:
                return 0
            if rel >= 100:
                return 1
            if rel > 40:
                return 2
            return 3

        sortedList.sort(key=_get_relevance_tier)

        # NF-06: Per-Series Preferred Provider Override
        series_override = database.get_series_override(mal_id) if mal_id else None
        override_prov = (series_override.get('preferred_provider') or '').strip().lower() if isinstance(series_override, dict) else ''
        if override_prov and override_prov not in ('auto', 'default', 'none'):
            match_idx = -1
            for idx, src in enumerate(sortedList):
                if str(src.get('provider') or '').lower() == override_prov or str(src.get('debrid_provider') or '').lower() == override_prov:
                    match_idx = idx
                    break
            if match_idx > 0:
                matching_source = sortedList[match_idx]
                if not sortedList or _get_relevance_tier(matching_source) <= _get_relevance_tier(sortedList[0]):
                    sortedList.insert(0, sortedList.pop(match_idx))

        # SmartPlay: prioritize preferred embed provider and matching quality/release if enabled
        if mal_id and control.getBool('general.smartplay', default=True):
            last_played_profile = database.get_last_played_source(mal_id)
            if last_played_profile:
                if control.getBool('smartplay.prefer_same_embed', default=True) and last_played_profile.get('type') in ('embed', 'direct'):
                    last_prov = last_played_profile.get('provider')
                    last_lang = last_played_profile.get('lang')
                    match_idx = -1
                    for idx, src in enumerate(sortedList):
                        if src.get('provider') == last_prov:
                            if not last_lang or src.get('lang') == last_lang:
                                match_idx = idx
                                break
                            elif match_idx == -1:
                                match_idx = idx
                    if match_idx > 0:
                        matching_source = sortedList[match_idx]
                        if not sortedList or _get_relevance_tier(matching_source) <= _get_relevance_tier(sortedList[0]):
                            matching_source = sortedList.pop(match_idx)
                            sortedList.insert(0, matching_source)
                elif control.getBool('smartplay.match_quality', default=True) and last_played_profile.get('type') not in ('embed', 'direct'):
                    last_quality = last_played_profile.get('quality')
                    last_provider = last_played_profile.get('provider')
                    last_release_title = last_played_profile.get('release_title', '')
                    match = _RELEASE_GROUP_RE.match(last_release_title)
                    last_group = match.group(1).lower() if match else ''

                    match_idx = -1
                    for idx, src in enumerate(sortedList):
                        src_title = src.get('release_title', '')
                        group_match = bool(last_group and f'[{last_group}]' in src_title.lower())
                        quality_match = (src.get('quality') == last_quality)
                        provider_match = (src.get('provider') == last_provider)

                        if group_match and quality_match:
                            match_idx = idx
                            break
                        elif quality_match and provider_match and match_idx == -1:
                            match_idx = idx
                        elif quality_match and match_idx == -1:
                            match_idx = idx

                    if match_idx > 0:
                        matching_source = sortedList[match_idx]
                        if not sortedList or _get_relevance_tier(matching_source) <= _get_relevance_tier(sortedList[0]):
                            matching_source = sortedList.pop(match_idx)
                            sortedList.insert(0, matching_source)

        return sortedList

    def updateProgress(self):
        t_counts, h_counts, e_counts = [0] * 5, [0] * 5, [0] * 5
        with self._results_lock:
            t_sources = list(self.torrentSources)
            h_sources = list(self.hosterSources)
            e_sources = list(self.embedSources)
        for s in t_sources:
            q = s.get('quality', 0)
            if 0 <= q <= 4:
                t_counts[4 - q] += 1
        for s in h_sources:
            q = s.get('quality', 0)
            if 0 <= q <= 4:
                h_counts[4 - q] += 1
        for s in e_sources:
            q = s.get('quality', 0)
            if 0 <= q <= 4:
                e_counts[4 - q] += 1
        self.torrents_qual_len = t_counts
        self.hosters_qual_len = h_counts
        self.embeds_qual_len = e_counts
