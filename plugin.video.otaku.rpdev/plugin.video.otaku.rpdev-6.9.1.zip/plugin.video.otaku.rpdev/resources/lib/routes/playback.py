# -*- coding: utf-8 -*-
import ast
import json
import re
import time

from resources.lib import MetaBrowser
from resources.lib.routes.history import save_to_watch_history
from resources.lib.ui import control, database, utils
from resources.lib.ui.router import Route, multi_route

_BROWSER_ROUTE_SUFFIXES = ('tv_show', 'movie', 'tv_short', 'special', 'ova', 'ona', 'music')


def _browser_list_route_paths(prefix):
    return (prefix,) + tuple('%s_%s' % (prefix, s) for s in _BROWSER_ROUTE_SUFFIXES)


def _wildcard_browser_paths(prefix):
    """Paths like ``marked_as_watched/*``, ``marked_as_watched_tv_show/*``, …"""
    return tuple('%s/*' % p for p in _browser_list_route_paths(prefix))


def _show_source_select(mock_args, sources, rescrape):
    from resources.lib.windows.source_select import SourceSelect
    xml_file = 'source_select_alt.xml' if control.getInt('general.dialog') in (5, 6) else 'source_select.xml'
    dlg = None
    try:
        dlg = SourceSelect(xml_file, control.ADDON_PATH, actionArgs=mock_args, sources=sources, rescrape=rescrape)
        return dlg.doModal()
    finally:
        if dlg:
            try:
                dlg.close()
            except Exception:
                pass
            del dlg


def _show_resolver(mock_args, sources):
    from resources.lib.windows.resolver import Resolver
    xml_file = 'resolver_alt.xml' if control.getInt('general.dialog') in (5, 6) else 'resolver.xml'
    dlg = None
    try:
        dlg = Resolver(xml_file, control.ADDON_PATH, actionArgs=mock_args)
        return dlg.doModal(sources, {}, False)
    finally:
        if dlg:
            try:
                dlg.close()
            except Exception:
                pass
            del dlg


def _param_flag_true(params, key):
    if not isinstance(params, dict):
        return False
    val = params.get(key)
    if isinstance(val, bool):
        return val
    if val is None:
        return False
    return str(val).strip().lower() in ('true', '1', 'yes')


def _clear_preresolved_handoff():
    for prop in (
        'otaku.preResolved_url',
        'otaku.preResolved_malId',
        'otaku.preResolved_episode',
        'otaku.preResolved_data',
    ):
        control.playerWindow.clearProperty(prop)


def _enrich_video_info(mal_id, episode, info_dict, media_type='episode'):
    """Ensure clean non-null UniqueIDs and fallback season/episode metadata for Kodi/Trakt."""
    video_info = dict(info_dict or {})
    if mal_id:
        uids = dict(video_info.get('UniqueIDs') or {}) if isinstance(video_info.get('UniqueIDs'), dict) else {}
        if 'tvdb' not in uids and 'tmdb' not in uids:
            uids.update(database.get_unique_ids(mal_id, 'mal_id') or {})
        uids.setdefault('mal_id', str(mal_id))
        uids.setdefault('mal', str(mal_id))
        video_info['UniqueIDs'] = {
            str(k): str(v) for k, v in uids.items()
            if v is not None and str(v).strip() not in ('', 'None', 'null')
        }
        if media_type != 'movie' and video_info.get('season') in (None, ''):
            from resources.lib.ui import player as _player_mod
            mapped_s, mapped_ep = _player_mod.resolve_trakt_season_episode(mal_id, episode, is_movie=False)
            if mapped_s is not None:
                video_info['season'] = mapped_s
                if video_info.get('episode') in (None, '', 0):
                    video_info['episode'] = mapped_ep
    return video_info


def _try_preresolved_handoff(mal_id, episode, params, resume, media_type='episode', source_select=False, rescrape=False):
    """Consume Zero-Wait pre-resolved window properties across PLAY & PLAY_MOVIE."""
    preresolved_url = control.playerWindow.getProperty('otaku.preResolved_url')
    preresolved_mal_id = control.playerWindow.getProperty('otaku.preResolved_malId')
    preresolved_ep = control.playerWindow.getProperty('otaku.preResolved_episode')
    preresolved_data_str = control.playerWindow.getProperty('otaku.preResolved_data')

    if not (
        preresolved_url
        and preresolved_mal_id == str(mal_id)
        and preresolved_ep == str(episode)
        and not source_select
        and not rescrape
        and control.getBool('smartplay.preresolve', default=True)
    ):
        return False

    control.log(f"Playback: Zero-Wait Pre-Resolved Stream Hit for {mal_id} Ep {episode} ({media_type})!", 'info')
    control.log_metric(
        'zero_wait_hit',
        level='info',
        mal_id=mal_id,
        episode=episode,
        media_type=media_type,
        stage='handoff',
    )
    _clear_preresolved_handoff()

    preresolved_data = control.loads_json(preresolved_data_str, default={}) if preresolved_data_str else {}
    if not isinstance(preresolved_data, dict):
        preresolved_data = {}

    # Re-verify only if the pre-resolved URL has been sitting idle >30 minutes (e.g. long pause)
    resolved_at = preresolved_data.get('resolved_at')
    try:
        resolved_ts = float(resolved_at) if resolved_at else 0.0
    except (TypeError, ValueError):
        resolved_ts = 0.0
    if resolved_ts > 0 and (time.time() - resolved_ts) > 1800:
        from resources.lib.windows.resolver import Resolver, _mark_candidate_mirror_failure
        if not Resolver.prefetch_play_link(preresolved_url):
            control.log(
                f"Playback: Pre-resolved stream expired after {int(time.time() - resolved_ts)}s; falling back to Resolver",
                'warning',
            )
            _mark_candidate_mirror_failure(preresolved_data.get('source') or {}, preresolved_url, cooldown=900)
            control.log_metric(
                'zero_wait_miss',
                level='warning',
                mal_id=mal_id,
                episode=episode,
                reason='stale_expired',
            )
            return False

    import xbmc, xbmcgui, xbmcplugin
    item = xbmcgui.ListItem(path=preresolved_url, offscreen=True)

    # Always purge stale temporary subtitle files and embed sub flags before preparing new playback
    from resources.lib.ui import embed_extractor, source_utils, player
    embed_extractor.del_subs()
    control.clearGlobalProp('otaku.embed_sub_signs_only')
    control.clearGlobalProp('otaku.embed_sub_has_full_dialog')

    if preresolved_data.get('sub'):
        from resources.lib.subtitles import languages
        pref_lang = languages.get_preferred_subtitle_language()
        sub_entries = []
        if pref_lang != 'none':
            for idx, sub in enumerate(preresolved_data['sub']):
                sub_lang = sub.get('lang') or embed_extractor.detect_sub_lang(sub.get('url'), sub.get('name'))
                if pref_lang and not languages.is_language_match(sub_lang, pref_lang):
                    control.log(f"Playback: Skipping embed subtitle '{sub.get('name', '')}' ({sub_lang}) - does not match preferred '{pref_lang}'", 'debug')
                    continue
                entry = embed_extractor.get_sub(
                    sub.get('url'),
                    sub.get('lang'),
                    headers=sub.get('headers'),
                    sub_index=sub.get('index', idx),
                    display_name=sub.get('name'),
                    source_url=sub.get('file'),
                    sub_tag=f"{mal_id}_{episode}_{int(time.time() * 1000)}",
                )
                if entry:
                    if entry.get('is_signs_only') and control.getInt('subtitles.keywords') == 1 and not control.getBool('subtitles.prefer_forced'):
                        control.log(f"Playback: Skipping sparse Signs-only sidecar '{entry.get('path')}' in Full Dialogue mode", 'info')
                    else:
                        sub_entries.append(entry)
        if sub_entries:
            item.setSubtitles([e['path'] for e in sub_entries])

    headers = preresolved_data.get('headers') or {}
    from resources.lib.windows.resolver import _get_header_ci, hook_mimetype
    content_type = _get_header_ci(headers, 'Content-Type')
    if content_type:
        item.setProperty('MimeType', content_type.split(';', 1)[0].strip())
        item = hook_mimetype.trigger(content_type, item)

    source_dict = preresolved_data.get('source') or {}
    source_tags = source_dict.get('info', []) if isinstance(source_dict, dict) else []
    is_dub_source = bool(
        isinstance(source_dict, dict)
        and (
            source_dict.get('lang') == 3
            or str(source_dict.get('lang') or '').lower() in ('dub', 'eng')
            or any('DUB' in str(t).upper().split() for t in (source_tags or []))
        )
    )
    control.playerWindow.setProperty('otaku.active_source_is_dub', 'true' if is_dub_source else 'false')
    hdr_type = None
    if 'DV' in source_tags:
        hdr_type = 'dolbyvision'
    elif 'HDR' in source_tags:
        hdr_type = 'hdr10'

    base_info = dict(params.get('info', {})) if params.get('info') else dict(params)
    if hdr_type and 'hdr_type' not in base_info:
        base_info['hdr_type'] = hdr_type
    video_info = _enrich_video_info(mal_id, episode, base_info, media_type=media_type)
    control.set_videotags(item, video_info)

    clean_filename = source_utils.format_video_filename(video_info)
    if clean_filename:
        item.setProperty('original_filename', clean_filename)
        item.setProperty('VideoPlayer.OriginalFilename', clean_filename)
        item.setLabel(clean_filename)
    if params.get('image'):
        clean_art = control.clean_art_dict(params.get('image'))
        if clean_art:
            item.setArt(clean_art)
            studio_art = clean_art.get('studio') or clean_art.get('tvshow.studio')
            if studio_art:
                item.setProperty('StudioIcon', studio_art)
                item.setProperty('StudioLogo', studio_art)
                item.setProperty('Studio.Icon', studio_art)
                item.setProperty('Studio.Logo', studio_art)
                item.setProperty('Studio.1.Icon', studio_art)
                item.setProperty('Studio.1.Logo', studio_art)
                item.setProperty('Studio.1.Art', studio_art)

    from resources.lib.WatchlistIntegration import watchlist_update_episode
    if source_dict:
        database.save_last_played_source(mal_id, source_dict)
        if source_dict.get('type') in ['embed', 'direct']:
            lp_key = f"{source_dict.get('provider', '')} {' '.join(map(str, source_dict.get('info') or []))}".strip()
        else:
            lp_key = str(source_dict.get('release_title') or source_dict.get('name') or '')
        control.setSetting('last_played_source', lp_key)
        control.setSetting('last_watched_series', str(mal_id))

    stype = source_dict.get('type', '')
    sprovider = source_dict.get('provider', '')
    import urllib.parse as _up
    pr_parsed = _up.urlparse(str(preresolved_url).split('|', 1)[0])
    existing_fc = database.get_playback_failover_context(mal_id, episode)
    fc_sources = (existing_fc.get('sources') if isinstance(existing_fc, dict) else None) or ([source_dict] if source_dict else [])
    fc_tried = list(existing_fc.get('tried_candidates') or []) if isinstance(existing_fc, dict) else []
    fc_idx = int(existing_fc.get('candidate_index') or 0) if isinstance(existing_fc, dict) else 0
    database.save_playback_failover_context(
        mal_id,
        episode,
        {
            'sources': fc_sources,
            'candidate_index': fc_idx,
            'tried_candidates': fc_tried,
            'active_url': str(preresolved_url),
            'active_host': pr_parsed.netloc.lower() if pr_parsed and pr_parsed.netloc else '',
            'debrid_provider': source_dict.get('debrid_provider', ''),
            'media_type': media_type,
        },
    )
    if control.getBool('trakt.enabled'):
        player.publish_trakt_ids(mal_id, fetch_remote=False)
    else:
        player.clear_trakt_ids()

    if control.HANDLE is not None and control.HANDLE < 0:
        control.playList.clear()
        control.playList.add(item.getPath(), item)
        pl_to_play = control.playList._get_pl() if hasattr(control.playList, '_get_pl') else control.playList
        xbmc.Player().play(pl_to_play, item)
    else:
        xbmcplugin.setResolvedUrl(control.HANDLE, True, item)

    player.WatchlistPlayer().handle_player(
        mal_id,
        watchlist_update_episode,
        int(episode),
        resume,
        params.get('path', ''),
        stype,
        sprovider,
        False,
        None,
    )
    control.exit_code()
    return True


@Route('play/*')
def PLAY(payload, params):
    parts = [p for p in payload.strip('/').split('/') if p]
    mal_id = parts[0] if parts else ''
    episode = parts[1] if len(parts) > 1 else '1'
    source_select = _param_flag_true(params, 'source_select')
    rescrape = _param_flag_true(params, 'rescrape')
    if source_select or rescrape:
        _clear_preresolved_handoff()
    last_played = control.getSetting('last_played_source')
    last_watched = control.getSetting('last_watched_series')
    resume = params.get('resume')
    auto_resume = _param_flag_true(params, 'auto_resume')
    if rating := params.get('rating'):
        try:
            params['rating'] = ast.literal_eval(rating)
        except (ValueError, SyntaxError):
            params['rating'] = rating
    play_path = params.get('path') or f"{control.addon_url(f'play/{payload}')}"
    params['path'] = play_path

    # Populate params with episode metadata from database if not already present
    # This ensures metadata is available even when playing from Information dialog
    if not params.get('tvshowtitle'):
        episode_data = database.get_episode(mal_id, episode)
        if not episode_data:
            MetaBrowser.get_anime_init(mal_id)
            episode_data = database.get_episode(mal_id, episode)
        if episode_data:
            params = database.loads(episode_data['kodi_meta'])
        else:
            # Fallback: build minimal params from show database
            # This ensures metadata is available even for episodes not yet indexed
            show_meta = database.get_show(mal_id)
            if show_meta:
                kodi_meta = database.loads(show_meta['kodi_meta'])
                show_art = database.get_show_meta(mal_id)
                art = database.loads(show_art['art']) if show_art and show_art.get('art') else {}
                ep_int = int(episode) if str(episode).isdigit() else 1
                info_dict = {
                    'title': f"{kodi_meta.get('title_userPreferred', '')} - Episode {episode}",
                    'tvshowtitle': kodi_meta.get('title_userPreferred', ''),
                    'episode': ep_int,
                    'plot': kodi_meta.get('plot', ''),
                    'mediatype': 'episode',
                    'UniqueIDs': {'mal_id': str(mal_id), 'mal': str(mal_id), **database.get_unique_ids(mal_id, 'mal_id')},
                }
                if kodi_meta.get('season') is not None:
                    info_dict['season'] = kodi_meta.get('season')
                params = {
                    'info': _enrich_video_info(mal_id, ep_int, info_dict, media_type='episode'),
                    'image': {
                        'poster': art.get('poster') or kodi_meta.get('poster', ''),
                        'fanart': art.get('fanart', ''),
                        'icon': art.get('poster') or kodi_meta.get('poster', ''),
                        'thumb': art.get('thumb', ''),
                    },
                    'path': play_path,
                }
        if isinstance(params, dict):
            params.setdefault('path', play_path)
            if auto_resume:
                params['auto_resume'] = '1'

    if resume:
        resume = float(resume)
        if not auto_resume and not _param_flag_true(params, 'auto_resume'):
            context = control.context_menu([f'Resume from {utils.format_time(resume)}', 'Play from beginning'])
            if context == -1:
                return control.exit_code()
            elif context == 1:
                resume = None

    # Guard against premature scraping of unaired episodes
    episode_info = params.get('info', {})
    aired_str = episode_info.get('aired')
    if aired_str and not rescrape and not source_select:
        try:
            from datetime import date
            aired_date = date.fromisoformat(aired_str[:10])
            today = date.today()
            if aired_date > today:
                diff_days = (aired_date - today).days
                day_str = "tomorrow" if diff_days == 1 else f"in {diff_days} days ({aired_date.strftime('%a, %b %d')})"
                confirmed = control.yesno_dialog(
                    control.ADDON_NAME,
                    f"Episode {episode} is not scheduled to air until {day_str}.\n\nSearch for early releases or raw leaks anyway?"
                )
                if not confirmed:
                    return control.exit_code()
        except Exception as e:
            control.log(f"playback aired_date check error: {e}", 'debug')

    # Zero-Wait Pre-Resolved Stream Handoff
    if _try_preresolved_handoff(mal_id, episode, params, resume, media_type='episode', source_select=source_select, rescrape=rescrape):
        return

    sources = MetaBrowser.get_sources(mal_id, episode, 'show', rescrape, source_select)
    if sources:
        _mock_args = {"mal_id": mal_id, "episode": episode, 'play': True, 'resume': resume, 'context': rescrape or source_select, 'params': params}

        # SmartPlay Enabled
        if control.getBool('general.smartplay'):
            last_played_profile = database.get_last_played_source(mal_id)
            has_last_source = (last_played not in ("None", "0", "", None)) or bool(last_played_profile)
            is_same_series = (last_watched == str(mal_id)) or bool(last_played_profile)
            control.setSetting('last_watched_series', str(mal_id))

            if is_same_series and has_last_source and not source_select and not rescrape:
                _show_resolver(_mock_args, sources)
            else:
                _show_source_select(_mock_args, sources, rescrape)
        # SmartPlay Disabled
        else:
            if control.getInt('general.playstyle.episode') == 1 or source_select or rescrape:
                _show_source_select(_mock_args, sources, rescrape)
            else:
                _show_resolver(_mock_args, sources)
    else:
        control.playList.clear()
    control.exit_code()


@Route('play_movie/*')
def PLAY_MOVIE(payload, params):
    parts = [p for p in payload.strip('/').split('/') if p]
    mal_id = parts[0] if parts else ''
    eps_watched = parts[1] if len(parts) > 1 else '0'
    source_select = _param_flag_true(params, 'source_select')
    rescrape = _param_flag_true(params, 'rescrape')
    if source_select or rescrape:
        _clear_preresolved_handoff()
    resume = params.get('resume')
    auto_resume = _param_flag_true(params, 'auto_resume')
    play_path = params.get('path') or f"{control.addon_url(f'play_movie/{payload}')}"
    params['path'] = play_path

    # Populate params with movie metadata from database if not already present
    # This ensures metadata is available even when playing from Information dialog
    if not params.get('name'):
        from resources.lib.OtakuBrowser import OtakuBrowser
        OtakuBrowser().get_anime_data(mal_id)
        anime_meta = database.get_show_meta(mal_id)
        anime_data = database.get_show(mal_id)
        if not anime_data or not anime_meta:
            control.exit_code()
            return
        kodi_meta = database.loads(anime_data['kodi_meta']) if anime_data.get('kodi_meta') else {}
        art_data = database.loads(anime_meta['art']) if anime_meta.get('art') else {}
        enriched_info = _enrich_video_info(mal_id, 1, kodi_meta, media_type='movie')

        params = {
            **kodi_meta,
            'info': enriched_info,  # video info tags
            'image': {  # art fields for UI
                k: (v[0] if isinstance(v, list) else v)
                for k, v in art_data.items()
            },
            'path': play_path,
        }
        if auto_resume:
            params['auto_resume'] = '1'

    if resume:
        resume = float(resume)
        if not auto_resume and not _param_flag_true(params, 'auto_resume'):
            context = control.context_menu([f'Resume from {utils.format_time(resume)}', 'Play from beginning'])
            if context == -1:
                return control.exit_code()
            elif context == 1:
                resume = None

    if _try_preresolved_handoff(mal_id, 1, params, resume, media_type='movie', source_select=source_select, rescrape=rescrape):
        return

    sources = MetaBrowser.get_sources(mal_id, 1, 'movie', rescrape, source_select)
    if sources:
        _mock_args = {'mal_id': mal_id, 'play': True, 'resume': resume, 'context': rescrape or source_select, 'params': params}
        if control.getInt('general.playstyle.movie') == 1 or source_select or rescrape:
            _show_source_select(_mock_args, sources, rescrape)
        else:
            _show_resolver(_mock_args, sources)
    else:
        control.playList.clear()
    control.exit_code()


def _extract_action_year(action_args):
    """Extract 4-digit release year from TMDb Helper actionArgs when provided."""
    for key in ('year', 'premiered', 'first_air_date', 'release_date'):
        val = str(action_args.get(key) or '').strip()
        if len(val) >= 4 and val[:4].isdigit():
            return val[:4]
    return ''


def _prefer_rows_by_year(rows, target_year):
    """Narrow candidate mapping rows to matching release year when multiple entries exist."""
    if not rows or not target_year:
        return rows
    matched = [r for r in rows if isinstance(r, dict) and str(r.get('year') or '') == str(target_year)]
    return matched or rows


@Route('tmdb_helper')
def TMDB_HELPER(payload, params):
    # --- Extract all relevant parameters from params and actionArgs ---
    from resources.lib.OtakuBrowser import OtakuBrowser
    from resources.lib.endpoints import tmdb

    action_args = params.pop('actionArgs', {})
    if isinstance(action_args, str):
        action_args = ast.literal_eval(action_args)
    # Now it's safe to use .get
    item_type = action_args.get('item_type')

    # Extract parameters from action_args
    item_type = action_args.get('item_type')
    tmdb_id = action_args.get('tmdb_id')
    tvdb_id = action_args.get('tvdb_id')
    imdb_id = action_args.get('imdb_id')
    trakt_id = action_args.get('trakt_id')
    season = action_args.get('season')
    episode = action_args.get('episode')
    target_year = _extract_action_year(action_args)

    # Extract source_select from params (default to False)
    source_select = params.pop('source_select', 'false') == 'true'
    params.update({'source_select': source_select})
    show_title = str(
        action_args.get('showtitle')
        or action_args.get('tvshowtitle')
        or action_args.get('title')
        or action_args.get('originaltitle')
        or ''
    ).strip()

    # Convert season and episode to int if present
    season_number = int(season) if season is not None else None
    episode_number = int(episode) if episode is not None else None

    # Grab Playstyle settings
    smartplay = control.getBool('general.smartplay')
    playstyle_movie = control.getInt('general.playstyle.movie')
    playstyle_episode = control.getInt('general.playstyle.episode')

    try:
        # Disable SmartPlay temporarily
        if smartplay:
            control.setBool('general.smartplay', False)

        # Parms cleanup
        parms = {}

        # Now all parameters are available: item_type, tmdb_id, title_url, season_number, episode_number, source_select
        control.log("Item Type: " + str(item_type))
        control.log("TMDB ID: " + str(tmdb_id))
        control.log("TVDB ID: " + str(tvdb_id))
        control.log("IMDB ID: " + str(imdb_id))
        control.log("Trakt ID: " + str(trakt_id))
        control.log("Season Number: " + str(season_number))
        control.log("Episode Number: " + str(episode_number))
        control.log("Source Select: " + str(source_select))

        if item_type == 'movie':
            mal_id = None
            id_sources = [
                ('themoviedb_id', tmdb_id),
                ('thetvdb_id', tvdb_id),
                ('imdb_id', imdb_id),
                ('trakt_id', trakt_id)
            ]

            for key, value in id_sources:
                if value:
                    rows = database.get_mal_ids(value, key) or []
                    movie_rows = [
                        r for r in rows
                        if isinstance(r, dict) and (
                            r.get('global_media_type') == 'movie'
                            or str(r.get('anime_media_type') or '').upper() == 'MOVIE'
                        )
                    ]
                    movie_rows = _prefer_rows_by_year(movie_rows, target_year)
                    rows = _prefer_rows_by_year(rows, target_year)
                    pick = movie_rows[0] if movie_rows else (rows[0] if rows else None)
                    if pick and pick.get('mal_id'):
                        mal_id = pick['mal_id']
                        break

            if not mal_id and show_title:
                search_rows = _prefer_rows_by_year(
                    database.search_mappings_by_title(show_title, limit=5, media_format='movie') or [],
                    target_year,
                )
                for row in search_rows:
                    if row and row.get('mal_id'):
                        mal_id = row['mal_id']
                        break

            if mal_id:
                OtakuBrowser().get_anime_data(mal_id)

                if source_select:
                    control.setInt('general.playstyle.movie', 1)
                else:
                    control.setInt('general.playstyle.movie', 0)

                PLAY_MOVIE(f"{mal_id}/", parms)
                if control.monitor.waitForAbort(3):
                    return
                return
            else:
                if not control.monitor.waitForAbort(3):
                    control.notify(control.ADDON_NAME, 'No MAL ID found from this movie')
                return

        else:
            mal_ids = set()
            id_sources = [
                ('themoviedb_id', tmdb_id),
                ('thetvdb_id', tvdb_id),
                ('imdb_id', imdb_id),
                ('trakt_id', trakt_id)
            ]

            for key, value in id_sources:
                if value:
                    mappings = database.get_mal_ids(value, key) or []  # Now returns a list
                    non_movies = [
                        r for r in mappings
                        if isinstance(r, dict)
                        and str(r.get('anime_media_type') or '').upper() != 'MOVIE'
                        and r.get('global_media_type') != 'movie'
                    ]
                    for anime_ids in _prefer_rows_by_year(non_movies or mappings, target_year):
                        if anime_ids and 'mal_id' in anime_ids and anime_ids['mal_id']:
                            if isinstance(anime_ids['mal_id'], list):
                                mal_ids.update(anime_ids['mal_id'])
                            else:
                                mal_ids.add(anime_ids['mal_id'])

            if not mal_ids and show_title:
                search_rows = _prefer_rows_by_year(
                    database.search_mappings_by_title(show_title, limit=10, media_format=item_type or '') or [],
                    target_year,
                )
                for row in search_rows:
                    if row and row.get('mal_id'):
                        mal_ids.add(row['mal_id'])

            if mal_ids:
                episode_titles = tmdb.get_episode_titles(tmdb_id, season_number, episode_number)
                match = (
                    tmdb_mapping_match(tmdb_id, id_sources, season_number, episode_number)
                    or find_episode_by_title(mal_ids, episode_titles, show_title=show_title)
                )
                if match:
                    mal_id = match['mal_id']
                    episode_num = match['episode_number']
                    matched_title = match['matched_title']
                    control.log(f"Matched MAL ID: {mal_id} for Episode {episode_num} titled '{matched_title}'")
                    OtakuBrowser().get_anime_data(mal_id)
                    MetaBrowser.get_anime_init(mal_id)

                    if source_select:
                        control.setInt('general.playstyle.episode', 1)
                    else:
                        control.setInt('general.playstyle.episode', 0)

                    PLAY(f"{mal_id}/{episode_num}", parms)
                    if control.monitor.waitForAbort(3):
                        return
                    return
                else:
                    if not control.monitor.waitForAbort(3):
                        control.notify(control.ADDON_NAME, 'No MAL ID found from this episode')
                    return
    finally:
        control.setInt('general.playstyle.movie', playstyle_movie)
        control.setInt('general.playstyle.episode', playstyle_episode)
        control.setBool('general.smartplay', smartplay)


def tmdb_mapping_match(tmdb_id, id_sources, season_number, episode_number):
    """Find the MAL id and episode for a TMDb season/episode using mappings.db, returns None if unsure"""
    try:
        return _tmdb_mapping_match(tmdb_id, id_sources, season_number, episode_number)
    except Exception as e:
        control.log(f'TMDB mapping: error, falling back to title matching: {e}', 'warning')
        return None


def _tmdb_mapping_match(tmdb_id, id_sources, season_number, episode_number):
    from resources.lib.ui import client
    from resources.lib.endpoints import tmdb as tmdb_api

    if not tmdb_id or not season_number or not episode_number:
        return None

    # Get all mapping rows for this show and only keep the ones for this TMDb id
    rows, seen = [], set()
    for key, value in id_sources:
        if not value:
            continue
        for row in database.get_mal_ids(value, key) or []:
            if row and row.get('mal_id') and row['mal_id'] not in seen:
                seen.add(row['mal_id'])
                rows.append(row)
    rows = [r for r in rows if str(r.get('themoviedb_id')) == str(tmdb_id)]
    if not rows:
        return None

    # Turn a range like '13-25' into (13, 25)
    def ep_range(value):
        m = re.match(r'\s*(\d+)\s*-\s*(\d+)', str(value or ''))
        return (int(m.group(1)), int(m.group(2))) if m else None

    # Check if the episode is inside this MAL entry and get its episode number there
    def result(row, number):
        g, a = ep_range(row.get('global_media_episodes')), ep_range(row.get('anime_media_episodes'))
        if not g or not (g[0] <= number <= g[1]):
            return None
        start = a[0] if a else 1
        control.log(f"TMDB mapping match: S{season_number}E{episode_number} -> MAL {row['mal_id']} ep {start + number - g[0]}")
        return {'mal_id': row['mal_id'], 'episode_number': start + number - g[0], 'matched_title': 'mappings.db'}

    # Get the episode count of each season from TMDb
    layout = {}
    try:
        res = control.safe_json(client.get(f'{tmdb_api.baseUrl}tv/{tmdb_id}', params={'api_key': tmdb_api.apiKey}))
        layout = {int(s['season_number']): int(s.get('episode_count') or 0)
                  for s in res.get('seasons', []) if s.get('season_number') is not None}
    except Exception as e:
        control.log(f'TMDB mapping: could not load season layout: {e}', 'warning')
    tmdb_before = sum(n for s, n in layout.items() if 0 < s < season_number) if layout else None

    # Try the TVDb season with the same number as the TMDb season first
    season_rows = [r for r in rows if str(r.get('thetvdb_season')) == str(season_number)]
    if season_rows:
        if tmdb_before is not None:
            # Only use it if the earlier seasons add up to the same episode count on TMDb and TVDb
            tvdb_ends = {}
            for r in rows:
                s, g = str(r.get('thetvdb_season')), ep_range(r.get('global_media_episodes'))
                if s.isdigit() and 0 < int(s) < season_number and g:
                    tvdb_ends[int(s)] = max(tvdb_ends.get(int(s), 0), g[1])
            complete = all(s in tvdb_ends for s in range(1, season_number))
            if not complete or sum(tvdb_ends.values()) != tmdb_before:
                control.log('TMDB mapping: TMDb and TVDb season layouts differ, falling back to title matching')
                season_rows = []
        for r in season_rows:
            match = result(r, episode_number)
            if match:
                return match

    # Consult tvdb_rules table (from Otaku-Mapping-DB v2.0+) for multi-cour / split offsets
    for r in rows:
        for rule in (database.get_tvdb_rules(r.get('mal_id')) or []):
            if str(rule.get('season')) != str(season_number):
                continue
            r_start = rule.get('range_start')
            r_end = rule.get('range_end')
            ep_start = rule.get('ep_start') or 1
            if r_start is None:
                continue
            if episode_number >= int(r_start) and (r_end is None or episode_number <= int(r_end)):
                mapped_ep = int(ep_start) + episode_number - int(r_start)
                control.log(f"TMDB rule match: S{season_number}E{episode_number} -> MAL {r['mal_id']} ep {mapped_ep}")
                return {'mal_id': r['mal_id'], 'episode_number': mapped_ep, 'matched_title': 'mappings.db'}

    # Absolute numbered shows like Naruto and One Piece
    abs_rows = [r for r in rows if str(r.get('thetvdb_season')) == 'a']
    if abs_rows and tmdb_before is not None:
        absolute = tmdb_before + episode_number
        for r in abs_rows:
            match = result(r, absolute)
            if match:
                return match
    return None


def remove_punctuation(s):
    return re.sub(r'[^\w\s]', '', s)


def _match_episode_title_candidates(cleaned_titles, candidate_pairs, get_fuzzy_match, clean_text):
    """Run fuzzy then direct normalized title match against [(candidate_title, ep_num, display_title)]."""
    if not cleaned_titles or not candidate_pairs:
        return None
    cleaned_candidates = [clean_text(c[0]) for c in candidate_pairs]
    best_idx = None
    for cleaned_query in cleaned_titles:
        match_indices = get_fuzzy_match(cleaned_query, cleaned_candidates)
        if match_indices:
            idx = match_indices[0]
            if best_idx is None or idx < best_idx:
                best_idx = idx
    if best_idx is not None:
        _, ep_num, disp = candidate_pairs[best_idx]
        return {'episode_number': ep_num, 'matched_title': disp}
    for idx, candidate in enumerate(cleaned_candidates):
        if candidate and candidate in cleaned_titles:
            _, ep_num, disp = candidate_pairs[idx]
            return {'episode_number': ep_num, 'matched_title': disp}
    return None


def find_episode_by_title(mal_ids, episode_titles, show_title=''):
    from resources.lib.indexers.jikanmoe import JikanAPI
    from resources.lib.ui.source_utils import get_fuzzy_match, clean_text
    # Split titles on '|' and clean each part
    split_titles = []
    for t in (episode_titles or []):
        if t:
            split_titles.extend([x.strip() for x in str(t).split('|') if x.strip()])
    cleaned_titles = [clean_text(t) for t in split_titles if clean_text(t)]
    if not cleaned_titles:
        return None

    ordered_mids = list(dict.fromkeys(mal_ids or []))
    if show_title and len(ordered_mids) > 1:
        q_clean = clean_text(show_title)

        def _mid_rank(mid):
            aliases = [clean_text(a) for a in (database.get_mapping_aliases(mid, limit=8) or []) if a]
            if q_clean and q_clean in aliases:
                return (0, str(mid))
            if q_clean and any(q_clean in a or a in q_clean for a in aliases if a):
                return (1, str(mid))
            return (2, str(mid))

        ordered_mids.sort(key=_mid_rank)

    jikan_api = JikanAPI()
    requests_made = 0
    last_request_time = time.time()
    for mal_id in ordered_mids:
        # 1. Offline cached episodes table (0 network requests)
        local_pairs = []
        try:
            for ep_row in (database.get_episode_list(mal_id) or []):
                ep_num = ep_row.get('number')
                ep_meta = database.loads(ep_row.get('kodi_meta') or '{}')
                ep_title = ((ep_meta.get('info') or {}).get('title') or '').strip() if isinstance(ep_meta, dict) else ''
                if ep_num and ep_title and not ep_title.lower().startswith('episode '):
                    local_pairs.append((ep_title, ep_num, ep_title))
        except Exception:
            local_pairs = []
        local_hit = _match_episode_title_candidates(cleaned_titles, local_pairs, get_fuzzy_match, clean_text)
        if local_hit:
            control.log(f"LOCAL EPISODE MATCH FOUND: '{local_hit['matched_title']}' -> MAL {mal_id} ep {local_hit['episode_number']}")
            return {'mal_id': mal_id, **local_hit}

        # 1b. Cached AniZip metadata check (0 network requests) before rate-limited Jikan
        try:
            from resources.lib.indexers import anizip as anizip_idx
            az_cached = database.peek(anizip_idx.ANIZIPAPI().get_anime_info, 24, mal_id)
            if isinstance(az_cached, dict) and isinstance(az_cached.get('episodes'), dict):
                az_cached_pairs = []
                for ep_key, ep_obj in az_cached['episodes'].items():
                    if not str(ep_key).isdigit() or not isinstance(ep_obj, dict):
                        continue
                    ep_num = int(ep_obj.get('episode') or ep_key)
                    tmap = ep_obj.get('title') if isinstance(ep_obj.get('title'), dict) else {}
                    for tlang in ('en', 'x-jat', 'ja'):
                        cand = str(tmap.get(tlang) or '').strip()
                        if cand:
                            az_cached_pairs.append((cand, ep_num, cand))
                az_cached_hit = _match_episode_title_candidates(cleaned_titles, az_cached_pairs, get_fuzzy_match, clean_text)
                if az_cached_hit:
                    control.log(f"CACHED ANIZIP EPISODE MATCH FOUND: '{az_cached_hit['matched_title']}' -> MAL {mal_id} ep {az_cached_hit['episode_number']}")
                    return {'mal_id': mal_id, **az_cached_hit}
        except Exception:
            pass

        # 2. Rate-limited Jikan lookup (title, title_romanji, title_japanese)
        if requests_made == 3:
            elapsed = time.time() - last_request_time
            if elapsed < 4.0:
                if control.monitor.waitForAbort(max(0.01, 4.0 - elapsed)):
                    break
            requests_made = 0
            last_request_time = time.time()
        if requests_made > 0:
            if control.monitor.waitForAbort(1.33):
                break
        retries = 0
        max_retries = 3
        backoff = 2
        while retries <= max_retries:
            try:
                episodes = jikan_api.get_episode_meta(mal_id)
                requests_made += 1
                break
            except Exception as e:
                if hasattr(e, 'response') and getattr(e.response, 'status_code', None) == 429:
                    control.log(f"Jikan API rate limited (429) for mal_id {mal_id}, retrying in {backoff} seconds...")
                    if control.monitor.waitForAbort(backoff):
                        break
                    retries += 1
                    backoff *= 2
                else:
                    control.log(f"Jikan API error for mal_id {mal_id}: {e}")
                    episodes = []
                    break
        else:
            control.log(f"Jikan API failed for mal_id {mal_id} after {max_retries} retries.")
            episodes = []

        jikan_pairs = []
        for ep in (episodes or []):
            for key in ('title', 'title_romanji', 'title_japanese'):
                candidate = str(ep.get(key) or '').strip()
                if candidate:
                    jikan_pairs.append((candidate, ep.get('mal_id'), candidate))
        jikan_hit = _match_episode_title_candidates(cleaned_titles, jikan_pairs, get_fuzzy_match, clean_text)
        if jikan_hit:
            control.log(f"JIKAN EPISODE MATCH FOUND: '{jikan_hit['matched_title']}' -> MAL {mal_id} ep {jikan_hit['episode_number']}")
            return {'mal_id': mal_id, **jikan_hit}

        # 3. AniZip fallback (en / x-jat / ja) when Jikan metadata is sparse or rate-limited
        anizip_pairs = []
        try:
            from resources.lib.indexers import anizip as anizip_idx
            az_info = database.get(anizip_idx.ANIZIPAPI().get_anime_info, 24, mal_id)
            if isinstance(az_info, dict) and isinstance(az_info.get('episodes'), dict):
                for ep_key, ep_obj in az_info['episodes'].items():
                    if not str(ep_key).isdigit() or not isinstance(ep_obj, dict):
                        continue
                    ep_num = int(ep_obj.get('episode') or ep_key)
                    tmap = ep_obj.get('title') if isinstance(ep_obj.get('title'), dict) else {}
                    for tlang in ('en', 'x-jat', 'ja'):
                        cand = str(tmap.get(tlang) or '').strip()
                        if cand:
                            anizip_pairs.append((cand, ep_num, cand))
        except Exception:
            anizip_pairs = []
        anizip_hit = _match_episode_title_candidates(cleaned_titles, anizip_pairs, get_fuzzy_match, clean_text)
        if anizip_hit:
            control.log(f"ANIZIP EPISODE MATCH FOUND: '{anizip_hit['matched_title']}' -> MAL {mal_id} ep {anizip_hit['episode_number']}")
            return {'mal_id': mal_id, **anizip_hit}
        control.log("No fuzzy or direct match for episode titles against TMDB titles.")
    return None  # No match found


@multi_route(*_wildcard_browser_paths('marked_as_watched'))
def MARKED_AS_WATCHED(payload, params):
    from resources.lib.WatchlistIntegration import watchlist_update_episode
    import service

    parts = [p for p in payload.strip('/').split('/') if p]
    if len(parts) >= 2:
        mal_id, episode = parts[0], parts[1]
    elif parts:
        mal_id, episode = parts[0], 1
    else:
        mal_id, episode = "", 1

    any_completed = watchlist_update_episode(mal_id, episode)
    if any_completed:
        if not control.monitor.waitForAbort(3):
            service.sync_watchlist(True)

    # Synchronize Watch History
    if mal_id:
        try:
            ep_int = int(episode) if str(episode).isdigit() else 1
            save_to_watch_history(mal_id, ep_int)
        except Exception as e:
            control.log(f"Error saving to watch history: {e}", "warning")

    # Invalidate cached eps_watched in kodi_meta so UI repaints playcounts
    show = database.get_show(mal_id)
    if show:
        try:
            kodi_meta = database.loads(show['kodi_meta'])
            ep_int = int(episode) if str(episode).isdigit() else 1
            kodi_meta['eps_watched'] = max(int(kodi_meta.get('eps_watched') or 0), ep_int)
            database.update_kodi_meta(mal_id, kodi_meta)
        except Exception as e:
            control.log(f"Error updating kodi_meta: {e}", "warning")

    # Update SQLite episodes table for the marked episode
    try:
        ep_num = int(episode) if str(episode).isdigit() else 1
        ep_row = database.get_episode(mal_id, ep_num)
        if ep_row:
            ep_meta = database.loads(ep_row['kodi_meta'])
            if ep_meta.get('info', {}).get('playcount') != 1:
                ep_meta.setdefault('info', {})['playcount'] = 1
                database.update_episode_column(mal_id, ep_num, 'kodi_meta', database.dumps(ep_meta))
    except Exception as e:
        control.log(f"Error updating episode table playcount: {e}", "warning")

    # Build notification showing updated watchlists
    enabled = control.enabled_watchlists()
    flavor_labels = {'anilist': 'AniList', 'kitsu': 'Kitsu', 'mal': 'MAL', 'simkl': 'Simkl'}
    updated_names = ', '.join([flavor_labels.get(f, f.capitalize()) for f in enabled]) if enabled else 'No Watchlist'

    if len(parts) >= 2:
        control.notify(control.ADDON_NAME, f'Episode #{episode} was Marked as Watched in {updated_names}')
        folder_path = control.getInfoLabel('Container.FolderPath')
        if 'watchlist_to_ep' in folder_path:
            control.execute(f'Container.Update(plugin://{control.ADDON_ID}/watchlist_to_ep/{mal_id}/{episode})')
        else:
            control.execute('Container.Refresh')
    else:
        title = ''
        if show:
            kodi_meta = database.loads(show['kodi_meta'])
            title = kodi_meta.get('title_userPreferred', '')
        control.notify(control.ADDON_NAME, f'{title} was Marked as Watched in {updated_names}')
        control.execute('Container.Refresh')
    control.exit_code()


@multi_route(*_wildcard_browser_paths('marked_as_unwatched'))
def MARKED_AS_UNWATCHED(payload, params):
    from resources.lib.WatchlistIntegration import watchlist_update_episode
    import service

    parts = [p for p in payload.strip('/').split('/') if p]
    if len(parts) >= 2:
        mal_id, ep_str = parts[0], parts[1]
    elif parts:
        mal_id, ep_str = parts[0], '1'
    else:
        return

    try:
        current_ep = int(ep_str)
        target_ep = max(0, current_ep - 1)
    except (ValueError, TypeError):
        current_ep = 1
        target_ep = 0

    any_completed = watchlist_update_episode(mal_id, target_ep)
    if any_completed:
        if not control.monitor.waitForAbort(3):
            service.sync_watchlist(True)

    # Invalidate cached eps_watched in kodi_meta so UI repaints playcounts
    show = database.get_show(mal_id)
    if show:
        try:
            kodi_meta = database.loads(show['kodi_meta'])
            kodi_meta['eps_watched'] = target_ep
            database.update_kodi_meta(mal_id, kodi_meta)
        except Exception as e:
            control.log(f"Error updating kodi_meta: {e}", "warning")

    # Clear SQLite episodes table playcounts for unwatched episodes
    episodes = database.get_episode_list(mal_id)
    if episodes:
        for ep_row in episodes:
            if ep_row['number'] >= current_ep:
                try:
                    ep_meta = database.loads(ep_row['kodi_meta'])
                    if ep_meta.get('info', {}).get('playcount') == 1:
                        ep_meta['info']['playcount'] = 0
                        database.update_episode_column(mal_id, ep_row['number'], 'kodi_meta', database.dumps(ep_meta))
                except Exception:
                    pass

    # If target_ep is 0, remove anime from watch history; otherwise update to target_ep
    if target_ep == 0:
        try:
            if control.pathExists(control.watch_history_json):
                with open(control.watch_history_json, 'r', encoding='utf-8') as f:
                    history_data = json.load(f)
                history_data['history'] = [
                    h for h in history_data.get('history', [])
                    if str(h.get('UniqueIDs', {}).get('mal_id') or h.get('mal_id')) != str(mal_id)
                ]
                control.atomic_write_json(control.watch_history_json, history_data)
        except Exception as e:
            control.log(f"Error updating watch history on unwatch: {e}", "warning")
    else:
        try:
            save_to_watch_history(mal_id, target_ep)
        except Exception as e:
            control.log(f"Error saving to watch history: {e}", "warning")

    enabled = control.enabled_watchlists()
    flavor_labels = {'anilist': 'AniList', 'kitsu': 'Kitsu', 'mal': 'MAL', 'simkl': 'Simkl'}
    updated_names = ', '.join([flavor_labels.get(f, f.capitalize()) for f in enabled]) if enabled else 'Local History'

    if len(parts) >= 2:
        control.notify(control.ADDON_NAME, f'Episode #{current_ep} Marked as Unwatched in {updated_names}')
    else:
        title = ''
        if show:
            try:
                title = database.loads(show['kodi_meta']).get('title_userPreferred', '')
            except Exception:
                title = ''
        control.notify(control.ADDON_NAME, f'{title} Marked as Unwatched in {updated_names}')

    folder_path = control.getInfoLabel('Container.FolderPath')
    if 'watchlist_to_ep' in folder_path:
        control.execute(f'Container.Update(plugin://{control.ADDON_ID}/watchlist_to_ep/{mal_id}/{target_ep})')
    else:
        control.execute('Container.Refresh')
    control.exit_code()


@multi_route(*_wildcard_browser_paths('mark_previous_watched'))
def MARK_PREVIOUS_WATCHED(payload, params):
    from resources.lib.WatchlistIntegration import watchlist_update_episode
    import service

    parts = [p for p in payload.strip('/').split('/') if p]
    if len(parts) >= 2:
        mal_id, ep_str = parts[0], parts[1]
    else:
        return
    try:
        target_ep = int(ep_str)
    except (ValueError, TypeError):
        return

    # User confirmation dialog
    show = database.get_show(mal_id)
    title = ''
    if show:
        try:
            kodi_meta = database.loads(show['kodi_meta'])
            title = kodi_meta.get('title_userPreferred', '')
        except Exception:
            title = ''
    anime_label = f" for '{title}'" if title else ""
    confirmed = control.yesno_dialog(
        "Mark Episodes as Watched",
        f"Mark episodes 1 to {target_ep}{anime_label} as watched in your WatchLists and Watch History?"
    )
    if not confirmed:
        return

    # Update watchlist for target_ep (MAL/AniList/Simkl/Kitsu sets progress to target_ep)
    any_completed = watchlist_update_episode(mal_id, target_ep, up_to=True)
    if any_completed:
        if not control.monitor.waitForAbort(3):
            service.sync_watchlist(True)

    # Save to watch history for target_ep
    try:
        save_to_watch_history(mal_id, target_ep)
    except Exception as e:
        control.log(f"Error saving to watch history: {e}", "warning")

    # Invalidate cached eps_watched in kodi_meta so UI repaints playcounts
    if show:
        try:
            kodi_meta = database.loads(show['kodi_meta'])
            kodi_meta['eps_watched'] = target_ep
            database.update_kodi_meta(mal_id, kodi_meta)
        except Exception as e:
            control.log(f"Error updating kodi_meta: {e}", "warning")

    # Also update cached episodes table in SQLite directly
    episodes = database.get_episode_list(mal_id)
    if episodes:
        for ep_row in episodes:
            if ep_row['number'] <= target_ep:
                try:
                    ep_meta = database.loads(ep_row['kodi_meta'])
                    if ep_meta.get('info', {}).get('playcount') != 1:
                        ep_meta.setdefault('info', {})['playcount'] = 1
                        database.update_episode_column(mal_id, ep_row['number'], 'kodi_meta', database.dumps(ep_meta))
                except Exception:
                    pass

    # Build notification showing updated watchlists
    enabled = control.enabled_watchlists()
    flavor_labels = {'anilist': 'AniList', 'kitsu': 'Kitsu', 'mal': 'MAL', 'simkl': 'Simkl'}
    updated_names = ', '.join([flavor_labels.get(f, f.capitalize()) for f in enabled]) if enabled else 'Local History'
    control.notify(control.ADDON_NAME, f"Episodes 1 to {target_ep} Marked as Watched in {updated_names}")

    folder_path = control.getInfoLabel('Container.FolderPath')
    if 'watchlist_to_ep' in folder_path:
        control.execute(f'Container.Update(plugin://{control.ADDON_ID}/watchlist_to_ep/{mal_id}/{target_ep})')
    else:
        control.execute("Container.Refresh")
    control.exit_code()


@Route('playback_options/*')
def PLAYBACK_OPTIONS(payload, params):
    import xbmcgui
    from urllib.parse import urlencode

    # Parse the payload to get mal_id and episode
    if payload and '/' in payload:
        mal_id, episode = payload.split('/', 1)
    else:
        control.log('Invalid payload format', 'error')
        return control.exit_code()

    # Get show information from database to build params
    show = database.get_show(mal_id)
    if show:
        kodi_meta = database.loads(show['kodi_meta'])

        # Build params similar to what get_video_info would return
        episode_params = {
            'mal_id': mal_id,
            'episode': episode,
            'title': kodi_meta.get('title_userPreferred', ''),
            'mediatype': 'episode',
            'tvshowtitle': kodi_meta.get('title_userPreferred', ''),
            'plot': kodi_meta.get('plot', ''),
            'year': str(kodi_meta.get('year', '')),
            'premiered': kodi_meta.get('premiered', ''),
            'season': str(kodi_meta.get('season', 1)),
            'aired': kodi_meta.get('aired', ''),
            'rating': kodi_meta.get('rating', {}),
            'resume': params.get('resume', ''),
            # Artwork
            'poster': kodi_meta.get('poster', ''),
            'tvshow.poster': kodi_meta.get('poster', ''),
            'icon': kodi_meta.get('poster', ''),
            'thumb': kodi_meta.get('thumb', ''),
            'fanart': kodi_meta.get('fanart', ''),
            'landscape': kodi_meta.get('landscape', ''),
            'banner': kodi_meta.get('banner', ''),
            'clearart': kodi_meta.get('clearart', ''),
            'clearlogo': kodi_meta.get('clearlogo', '')
        }
    else:
        # Fallback params if show not found in database
        episode_params = {
            'mal_id': mal_id,
            'episode': episode,
            'title': '',
            'mediatype': 'episode',
            'tvshowtitle': '',
            'plot': '',
            'year': '',
            'premiered': '',
            'season': '1',
            'aired': '',
            'rating': {},
            'resume': params.get('resume', ''),
            # Artwork
            'poster': '',
            'tvshow.poster': '',
            'icon': '',
            'thumb': '',
            'fanart': '',
            'landscape': '',
            'banner': '',
            'clearart': '',
            'clearlogo': ''
        }

    # Ask the user which playback option they want to use
    # Here the button labels are:
    # Button 0: "Cancel"   | Button 1: "Rescrape" | Button 2: "Source Select"
    yesnocustom = control.yesnocustom_dialog(
        control.ADDON_NAME + " - Playback Options",
        "Please choose a playback option:",
        "Cancel", "Source Select", "Rescrape",
        defaultbutton=xbmcgui.DLG_YESNO_YES_BTN
    )

    if yesnocustom == 0:
        # Redirect to play route with source_select parameter
        query_params = urlencode({'source_select': 'true', **episode_params})
        control.playList.clear()
        control.execute(f'RunPlugin(plugin://{control.ADDON_ID}/play/{mal_id}/{episode}?{query_params})')

    elif yesnocustom == 1:
        # Redirect to play route with rescrape parameter
        query_params = urlencode({'rescrape': 'true', **episode_params})
        control.playList.clear()
        control.execute(f'RunPlugin(plugin://{control.ADDON_ID}/play/{mal_id}/{episode}?{query_params})')

    elif yesnocustom == 2:
        # User cancelled, exit without doing anything
        pass

    control.exit_code()


@Route('step_scene_marker/*')
def STEP_SCENE_MARKER(payload, params):
    """Step to next/previous native chapter or AniSkip/IntroDB scene marker, or open jump picker."""
    from resources.lib.ui import player as player_mod
    action = str(payload or 'menu').strip('/').lower() or 'menu'
    control.log(f"SceneMarkers: STEP_SCENE_MARKER payload={payload!r} action={action!r}", 'info')
    res = player_mod.handle_scene_marker_action(action)
    control.exit_code()
    return res


@Route('scene_markers')
def SCENE_MARKERS(payload, params):
    """Open interactive scene-marker / chapter jump dialog for active playback."""
    from resources.lib.ui import player as player_mod
    res = player_mod.handle_scene_marker_action('menu')
    control.exit_code()
    return res


def _is_stale_deeplink_replay(sig, mal_id='', episode='', window_seconds=10.0):
    """Guard against duplicate Android TV VIEW intent replays and already-playing targets.

    Clamps replay elapsed time to ``0.0 <= (now - last_ts) < window_seconds`` so
    backwards NTP clock jumps cannot falsely block fresh launches. Also checks real
    active playback properties (`otaku.mal_id` and `otaku.active_sub_meta` JSON).
    """
    now = time.time()
    last_sig = str(control.getGlobalProp('otaku.last_deeplink_sig') or '')
    last_ts_raw = str(control.getGlobalProp('otaku.last_deeplink_ts') or '')
    try:
        last_ts = float(last_ts_raw) if last_ts_raw else -1.0
    except (ValueError, TypeError):
        last_ts = -1.0

    if last_sig and last_sig == sig and last_ts > 0.0:
        elapsed = now - last_ts
        if 0.0 <= elapsed < float(window_seconds):
            control.log(f"DeepLink: Ignored stale VIEW replay sig={sig} (elapsed={elapsed:.2f}s)", 'info')
            return True

    if mal_id:
        try:
            import xbmc
            if xbmc.Player().isPlayingVideo():
                active_mal = str(control.getGlobalProp('otaku.mal_id') or '').strip()
                active_ep = ''
                from resources.lib.subtitles import meta as _sub_meta
                active_meta = _sub_meta.get_active_playback_meta()
                if isinstance(active_meta, dict):
                    active_mal = active_mal or str(active_meta.get('mal_id') or '').strip()
                    active_ep = str(active_meta.get('episode') or '').strip()
                if active_mal == str(mal_id) and (not episode or not active_ep or active_ep == str(episode)):
                    control.log(
                        f"DeepLink: Ignored replay because MAL #{mal_id} ep={episode or '1'} is already playing",
                        'info',
                    )
                    return True
        except Exception:
            pass

    control.setGlobalProp('otaku.last_deeplink_sig', str(sig))
    control.setGlobalProp('otaku.last_deeplink_ts', repr(now))
    return False


@Route('deeplink/*')
def DEEPLINK(payload, params):
    """Android TV launcher deep-link router with stale VIEW intent replay guard.

    Supported routes:
      - ``deeplink/next_up``
      - ``deeplink/play/<mal_id>/<episode>[?movie=true&source_select=true]``
    """
    parts = [seg.strip() for seg in str(payload or '').strip('/').split('/') if seg.strip()]
    if not parts:
        control.log("DeepLink: Missing sub-route payload", 'warning')
        return control.exit_code()

    action = parts[0].lower()
    if action == 'next_up':
        sig = 'deeplink:next_up'
        if _is_stale_deeplink_replay(sig):
            return control.exit_code()
        if int(getattr(control, 'HANDLE', -1) or -1) < 0:
            control.execute(f"ActivateWindow(Videos,plugin://{control.ADDON_ID}/next_up,return)")
            return control.exit_code()
        from resources.lib import WatchlistIntegration
        WatchlistIntegration.NEXT_UP('', params or {})
        return control.exit_code()

    if action == 'play':
        mal_id = parts[1] if len(parts) >= 2 else ''
        is_movie = _param_flag_true(params, 'movie')
        episode = parts[2] if len(parts) >= 3 else ('1' if is_movie else '')
        if not mal_id or not mal_id.isdigit() or not episode or not episode.isdigit():
            control.log(f"DeepLink: Rejected malformed play payload={payload!r}", 'warning')
            return control.exit_code()
        sig = f"deeplink:play:{mal_id}:{episode}:{'movie' if is_movie else 'ep'}"
        if _is_stale_deeplink_replay(sig, mal_id=mal_id, episode=episode):
            return control.exit_code()
        fwd_params = dict(params or {})
        if is_movie:
            PLAY_MOVIE(f"{mal_id}/", fwd_params)
        else:
            PLAY(f"{mal_id}/{episode}", fwd_params)
        return control.exit_code()

    control.log(f"DeepLink: Unknown sub-route '{action}' (payload={payload!r})", 'warning')
    return control.exit_code()
