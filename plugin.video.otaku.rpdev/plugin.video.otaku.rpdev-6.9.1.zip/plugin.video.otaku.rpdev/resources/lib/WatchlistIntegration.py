
from resources.lib.ui import control, database
from resources.lib.ui.router import Route
from resources.lib.WatchlistFlavor import WatchlistFlavor
from resources.lib import MetaBrowser

BROWSER = MetaBrowser.BROWSER


def _watchlist_paging_per_page():
    if not control.getBool('interface.watchlist.paging'):
        return 0
    return max(0, control.getInt('interface.perpage.watchlist'))


def get_auth_dialog(flavor):
    from resources.lib.windows import wlf_auth
    dlg = None
    auth = False
    try:
        dlg = wlf_auth.WatchlistFlavorAuth('wlf_auth_%s.xml' % flavor, control.ADDON_PATH, flavor=flavor)
        auth = dlg.doModal()
    finally:
        if dlg is not None:
            try:
                dlg.close()
            except Exception:
                pass
            del dlg
    return WatchlistFlavor.login_request(flavor) if auth else None


@Route('watchlist_login/*')
def WL_LOGIN(payload, params):
    auth_dialog = bool(params.get('auth_dialog'))
    get_auth_dialog(payload) if auth_dialog else WatchlistFlavor.login_request(payload)
    control.exit_code()


@Route('watchlist_logout/*')
def WL_LOGOUT(payload, params):
    flavor = payload.strip('/')
    WatchlistFlavor.logout_request(flavor)
    control.exit_code()


@Route('watchlist/*')
def WATCHLIST(payload, params):
    view_type = 'addons' if control.getBool('interface.content_type') else ''
    control.draw_items(WatchlistFlavor.watchlist_request(payload), view_type)


@Route('next_up')
def NEXT_UP(payload, params):
    control.draw_items(WatchlistFlavor.get_next_up(), 'videos')


@Route('next_up_pages/*')
def NEXT_UP_PAGES(payload, params):
    offset = int(payload)
    page = int(params.get('page', 1))
    items = WatchlistFlavor.get_next_up(offset, page)
    control.draw_items(items, 'videos')


@Route('precache_watchlist_now')
def PRECACHE_WATCHLIST_NOW(payload, params):
    control.notify(control.ADDON_NAME, 'Pre-caching watchlist in progress...')
    try:
        import service
        service.prefetch_watchlist()
        control.notify(control.ADDON_NAME, 'Watchlist pre-cached successfully!')
    except Exception as e:
        control.log(f'Manual watchlist pre-cache error: {e}', 'warning')
        control.notify(control.ADDON_NAME, 'Watchlist pre-cache failed.')
    control.exit_code()


@Route('watchlist_status_type/*')
def WATCHLIST_STATUS_TYPE(payload, params):
    parts = [p for p in payload.strip('/').split('/') if p]
    if len(parts) < 2:
        return control.exit_code()
    flavor, status = parts[0], parts[1]
    next_up = bool(params.get('next_up'))
    content_type = 'videos' if next_up else 'tvshows'
    items = WatchlistFlavor.watchlist_status_request(flavor, status, next_up)
    control.draw_items(items, content_type)


@Route('watchlist_status_type_pages/*')
def WATCHLIST_STATUS_TYPE_PAGES(payload, params):
    parts = [p for p in payload.strip('/').split('/') if p]
    if len(parts) < 3:
        return control.exit_code()
    flavor, status, offset = parts[0], parts[1], parts[2]
    page = int(params.get('page', 1))
    next_up = bool(params.get('next_up'))
    content_type = 'videos' if next_up else 'tvshows'
    items = WatchlistFlavor.watchlist_status_request(flavor, status, next_up, offset, page)
    control.draw_items(items, content_type)


@Route('watchlist_to_ep/*')
def WATCHLIST_TO_EP(payload, params):
    payload_list = [p for p in payload.strip('/').split('/') if p]
    if not payload_list:
        return control.exit_code()
    mal_id = payload_list[0]
    eps_watched = payload_list[1] if len(payload_list) >= 2 else '0'
    show_meta = database.get_show(mal_id)
    if not show_meta:
        BROWSER.get_anime(mal_id)
        show_meta = database.get_show(mal_id)
        if not show_meta:
            return control.exit_code()
    kodi_meta = database.loads(show_meta['kodi_meta'])
    url_ep = int(eps_watched) if str(eps_watched).isdigit() else 0
    db_ep = int(kodi_meta.get('eps_watched') or 0)
    current_ep = max(url_ep, db_ep)
    kodi_meta['eps_watched'] = current_ep
    database.update_kodi_meta(mal_id, kodi_meta)

    anime_general, content_type = MetaBrowser.get_anime_init(mal_id)
    control.draw_items(anime_general, content_type)


@Route('watchlist_manager/*')
def CONTEXT_MENU(payload, params):
    if not control.getBool('watchlist.update.enabled'):
        control.ok_dialog(control.ADDON_NAME, 'No Watchlist Enabled: \n\nPlease enable [B]Update Watchlist[/B] before using the Watchlist Manager')
        return control.exit_code()
    from resources.lib import Main
    mal_id = Main._extract_mal_id(payload)
    if not mal_id:
        return control.exit_code()

    if not (show := database.get_show(mal_id)):
        BROWSER.get_anime(mal_id)
        show = database.get_show(mal_id)
        if not show:
            return control.exit_code()

    # Get all enabled watchlists
    enabled = control.enabled_watchlists()
    if not enabled:
        control.ok_dialog(control.ADDON_NAME, 'No Watchlist Enabled: \n\nPlease Enable a Watchlist before using the Watchlist Manager')
        return control.exit_code()

    kodi_meta = database.loads(show['kodi_meta'])
    title = kodi_meta['title_userPreferred']

    # Build watchlist choices with labels
    flavor_labels = {
        'anilist': 'AniList',
        'kitsu': 'Kitsu',
        'mal': 'MyAnimeList',
        'simkl': 'Simkl'
    }

    if len(enabled) == 1:
        # Only one watchlist enabled, skip the picker
        selected_flavor = enabled[0]
    else:
        # Let user pick which watchlist to manage
        watchlist_options = [flavor_labels.get(f, f.capitalize()) for f in enabled]
        choice = control.select_dialog(f'{title} - Select Watchlist', watchlist_options)
        if choice == -1:
            return control.exit_code()
        selected_flavor = enabled[choice]

    # Get actions for the selected flavor
    actions = WatchlistFlavor.context_statuses_for_flavor(selected_flavor)
    if not actions:
        control.ok_dialog(control.ADDON_NAME, f'Unable to get actions for {flavor_labels.get(selected_flavor, selected_flavor)}')
        return control.exit_code()

    flavor_label = flavor_labels.get(selected_flavor, selected_flavor.capitalize())
    heading = f'{control.ADDON_NAME} - ({flavor_label})'

    context = control.select_dialog(f"{title}  {control.colorstr(f'({flavor_label})', 'blue')}", list(map(lambda x: x[0], actions)))
    if context != -1:
        status = actions[context][1]
        if status == 'DELETE':
            yesno = control.yesno_dialog(heading, f'Are you sure you want to delete [I]{title}[/I] from [B]{flavor_label}[/B]\n\nPress YES to Continue:')
            if yesno:
                delete = WatchlistFlavor.watchlist_delete_anime_for_flavor(selected_flavor, mal_id)
                if delete:
                    control.ok_dialog(heading, f'[I]{title}[/I] was deleted from [B]{flavor_label}[/B]')
                else:
                    control.ok_dialog(heading, 'Unable to delete from Watchlist')
        elif status == 'set_score':
            score_list = [
                "(10) Masterpiece",
                "(9) Great",
                "(8) Very Good",
                "(7) Good",
                "(6) Fine",
                "(5) Average",
                "(4) Bad",
                "(3) Very Bad",
                "(2) Horrible",
                "(1) Appalling",
                "(0) No Score"
            ]
            score = control.select_dialog(f'{title}: ({flavor_label})', score_list)
            if score != -1:
                score = 10 - score
                set_score = WatchlistFlavor.watchlist_set_score_for_flavor(selected_flavor, mal_id, score)
                if set_score:
                    control.ok_dialog(heading, f'[I]{title}[/I]   was set to [B]{score}[/B]')
                else:
                    control.ok_dialog(heading, 'Unable to Set Score')
        else:
            set_status = WatchlistFlavor.watchlist_set_status_for_flavor(selected_flavor, mal_id, status)
            if set_status in ['watching', 'current', 'CURRENT']:
                control.ok_dialog(heading, 'This show is still airing, so we\'re keeping it in your "Watching" list and marked all aired episodes as watched.')
            elif set_status:
                control.ok_dialog(heading, f'[I]{title}[/I]  was added to [B]{status}[/B]')
            else:
                control.ok_dialog(heading, 'Unable to Set Watchlist')
    return control.exit_code()


def add_watchlist(items):
    flavors = WatchlistFlavor.get_enabled_watchlists()
    if flavors:
        for flavor in flavors:
            label = f"{flavor.username}'s {flavor.title}" if flavor.username else f"{flavor.title} Watchlist"
            items.append((label, f"watchlist/{flavor.flavor_name}", flavor.image, {}))
    return items


def watchlist_update_episode(mal_id, episode, up_to=False):
    """Update episode progress on ALL enabled watchlists."""
    return WatchlistFlavor.watchlist_update_all_episodes(mal_id, episode, up_to=up_to)


def set_watchlist_status(mal_id, status):
    """Set status on ALL enabled watchlists using unified status mapping."""
    return WatchlistFlavor.watchlist_set_all_status(mal_id, status)


def set_watchlist_score(mal_id, score):
    """Set score on ALL enabled watchlists."""
    return WatchlistFlavor.watchlist_set_all_score(mal_id, score)


def delete_watchlist_anime(mal_id):
    """Delete anime from ALL enabled watchlists."""
    return WatchlistFlavor.watchlist_delete_all_anime(mal_id)


@Route('watchlist_telemetry')
def WATCHLIST_TELEMETRY(payload, params):
    """Display multi-tracker watchlist sync telemetry and pending 429 retry queue."""
    queue = database.list_scrobble_retry_queue()
    drifts = WatchlistFlavor.compute_watchlist_drift()
    policy_map = {0: 'Highest Progress Wins', 1: 'Primary Tracker Wins', 2: 'Latest Updated Timestamp Wins'}
    policy_name = policy_map.get(control.getInt('watchlist.sync.conflict_policy', default=0), 'Highest Progress Wins')
    enabled = control.enabled_watchlists()

    lines = [
        "=" * 60,
        f"  {control.ADDON_NAME} Multi-Tracker Watchlist Telemetry",
        "=" * 60,
        f"  • Enabled Trackers:  {', '.join(enabled) if enabled else 'None'}",
        f"  • Conflict Policy:   {policy_name}",
        f"  • Pending Retries:   {len(queue)}",
        f"  • Detected Drifts:   {len(drifts)}",
        "",
        "[Pending Scrobble Retry Queue]",
    ]
    if not queue:
        lines.append("  • Queue is empty (0 pending retries).")
    else:
        for q in queue:
            lines.append(
                f"  • [{q.get('service')}] MAL #{q.get('mal_id')} ({q.get('action')} ep={q.get('episode')}) "
                f"attempts={q.get('attempts')} err={q.get('last_error')}"
            )
    control.textviewer_dialog('Watchlist Sync Telemetry & Retry Queue', '\n'.join(lines))
    return control.exit_code()


@Route('watchlist_drift_auditor')
def WATCHLIST_DRIFT_AUDITOR(payload, params):
    """Audit and optionally reconcile episode progress drift across enabled watchlist trackers."""
    drifts = WatchlistFlavor.compute_watchlist_drift()
    if not drifts:
        control.notify(control.ADDON_NAME, 'All enabled watchlists are in sync (0 drifts found)', time=4000)
        return control.exit_code()

    planned_mutations = WatchlistFlavor.count_watchlist_drift_mutations(drifts)
    params = params or {}
    is_dry_run = str(params.get('dry_run', '')).lower() == 'true'
    want_reconcile = str(params.get('reconcile', '')).lower() == 'true'

    lines = [
        "=" * 60,
        f"  Cross-Watchlist Drift Report ({len(drifts)} show(s) out of sync)",
        f"  Dry-Run Planned Mutations: {planned_mutations} tracker update(s)",
        "=" * 60,
        "",
    ]
    for d in drifts:
        t_parts = [f"{svc}: Ep {td.get('episodes_watched', 0)}" for svc, td in sorted(d['trackers'].items())]
        lines.append(f"• {d['title']} (MAL #{d['mal_id']}) -> Target Ep {d['target_episode']}")
        lines.append(f"    Trackers: {' | '.join(t_parts)}")
    control.textviewer_dialog('Cross-Watchlist Drift Auditor', '\n'.join(lines))

    if is_dry_run:
        return control.exit_code()

    interactive_prompt = ('reconcile' not in params)
    if want_reconcile or interactive_prompt:
        skip_confirm = str(params.get('confirm', '')).lower() == 'true'
        confirmed = True if skip_confirm else bool(control.yesno_dialog(
            f"{control.ADDON_NAME}: Cross-Watchlist Drift Auditor",
            f"Dry-Run Summary: {planned_mutations} tracker update(s) across {len(drifts)} show(s).\n\n"
            f"Reconcile local & remote watchlist progress now?"
        ))
        if confirmed:
            count = WatchlistFlavor.reconcile_watchlist_drift(drifts)
            control.notify(control.ADDON_NAME, f'Reconciled {count} tracker drift entry/entries', time=4000)
        elif want_reconcile:
            control.notify(control.ADDON_NAME, 'Drift reconciliation cancelled (dry-run only)', time=3000)
    return control.exit_code()

