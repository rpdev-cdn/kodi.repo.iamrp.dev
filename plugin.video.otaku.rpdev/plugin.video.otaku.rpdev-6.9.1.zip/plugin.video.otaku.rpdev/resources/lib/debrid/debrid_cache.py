"""
Debrid Cache – Local SQLite cache for debrid hash availability.

Stores previously checked torrent hashes and their cached status per debrid service.
Uses external services (Torrentio, AIOStreams, DMM) to check RD/AD cache status
since those services removed their native cache-check APIs.
"""

import random
import re
import time
import threading

from resources.lib.ui import control, client, database


# ═══════════════════════════════════════════════════════════════════════════
#  Debrid Cache DB Operations
# ═══════════════════════════════════════════════════════════════════════════

_CACHE_EXPIRY_HOURS = 24
_IN_FLIGHT_LOCK = threading.Lock()
_IN_FLIGHT_CHECKS = {}  # key: (hash_lower, debrid_lower), value: threading.Event()
_EPISODE_CACHE_RESULTS = {}  # key: (syn_key_lower, debrid_lower), value: list of hashes


def acquire_in_flight(hash_list, debrid):
    """
    Deduplicate concurrent external cache checks across multiple scrapers.
    Returns:
        (ready_to_query_hashes, in_flight_events)
    where:
        ready_to_query_hashes: hashes that this thread must query and subsequently release.
        in_flight_events: list of threading.Event objects to await for hashes currently being queried.
    """
    if not hash_list:
        return [], []
    d_clean = (debrid or '').strip().lower()
    ready = []
    events = []
    with _IN_FLIGHT_LOCK:
        for h in hash_list:
            if not h:
                continue
            key = (str(h).strip().lower(), d_clean)
            if key in _IN_FLIGHT_CHECKS:
                events.append(_IN_FLIGHT_CHECKS[key])
            else:
                ev = threading.Event()
                _IN_FLIGHT_CHECKS[key] = ev
                ready.append(h)
    return ready, events


def release_in_flight(hash_list, debrid):
    """
    Signal waiting threads that external checks have completed and unregister hashes.
    """
    if not hash_list:
        return
    d_clean = (debrid or '').strip().lower()
    with _IN_FLIGHT_LOCK:
        for h in hash_list:
            if not h:
                continue
            key = (str(h).strip().lower(), d_clean)
            ev = _IN_FLIGHT_CHECKS.pop(key, None)
            if ev:
                ev.set()


def _ensure_debrid_cache_table():
    database._ensure_table(
        control.cacheFile, 'debrid_cache',
        'CREATE TABLE IF NOT EXISTS debrid_cache '
        '(hash TEXT, debrid TEXT, cached TEXT, expires INTEGER, '
        'UNIQUE(hash, debrid))'
    )
    database._ensure_table(
        control.cacheFile, 'debrid_cache_ix_expires',
        'CREATE INDEX IF NOT EXISTS ix_debrid_cache_expires ON debrid_cache (expires)'
    )


def prune_expired_hashes():
    """Purge expired cache entries to prevent unbounded table growth."""
    try:
        _ensure_debrid_cache_table()
        now = int(time.time())
        with database.SQL(control.cacheFile) as cur:
            cur.execute('DELETE FROM debrid_cache WHERE expires < ?', (now,))
            cur.connection.commit()
    except Exception as e:
        control.log(f'Error pruning debrid cache: {e}', 'warning')


def get_cached_hashes(hash_list):
    """Get previously cached hash results from local DB."""
    if not hash_list:
        return []
    clean_hashes = [str(h).strip().lower() for h in hash_list if h]
    if not clean_hashes:
        return []
    _ensure_debrid_cache_table()
    now = int(time.time())
    results = []
    with database.SQL(control.cacheFile) as cur:
        for i in range(0, len(clean_hashes), 500):
            chunk = clean_hashes[i:i + 500]
            placeholders = ', '.join('?' for _ in chunk)
            cur.execute(
                f'SELECT hash, debrid, cached FROM debrid_cache '
                f'WHERE hash IN ({placeholders}) AND cached = "True" AND expires > ?',
                chunk + [now]
            )
            rows = cur.fetchall()
            if rows:
                results.extend(rows)
    return results


def set_cached_hashes(hash_status_list, debrid):
    """Store hash cache status results. hash_status_list = [(hash, 'True'/'False'), ...]"""
    if not hash_status_list:
        return
    _ensure_debrid_cache_table()
    try:
        expiry_hours = int(control.getInt('cache.torrents.ttl')) or _CACHE_EXPIRY_HOURS
    except (TypeError, ValueError):
        expiry_hours = _CACHE_EXPIRY_HOURS
    expires = int(time.time() + (expiry_hours * 3600))
    with database.SQL(control.cacheFile) as cur:
        cur.executemany(
            'REPLACE INTO debrid_cache (hash, debrid, cached, expires) VALUES (?, ?, ?, ?)',
            [(str(h).strip().lower(), debrid, status, expires) for h, status in hash_status_list if h]
        )
        cur.connection.commit()
    if random.random() < 0.2:
        prune_expired_hashes()


def clear_debrid_cache():
    """Clear the entire debrid cache table."""
    with _IN_FLIGHT_LOCK:
        _EPISODE_CACHE_RESULTS.clear()
    _ensure_debrid_cache_table()
    with database.SQL(control.cacheFile) as cur:
        cur.execute('DELETE FROM debrid_cache')
        cur.connection.commit()


# ═══════════════════════════════════════════════════════════════════════════
#  External Cache Checking (for RD/AD)
# ═══════════════════════════════════════════════════════════════════════════

def check_rd_cache(hash_list, imdb_id, season, episode):
    """Check Real-Debrid cache status using external services (Torrentio + DMM)."""
    cached_hashes = []
    threads = [
        threading.Thread(target=_tio_check_cache, args=(imdb_id, season, episode, cached_hashes), daemon=True),
        threading.Thread(target=_dmm_check_cache, args=(hash_list, imdb_id, cached_hashes), daemon=True),
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=8)
    return list(set(cached_hashes))


def check_ad_cache(imdb_id, season, episode):
    """Check AllDebrid cache status using external services (AIOStreams)."""
    cached_hashes = []
    threads = [
        threading.Thread(target=_aio_check_cache, args=(imdb_id, season, episode, cached_hashes), daemon=True),
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=8)
    return list(set(cached_hashes))


def _tio_check_cache(imdb_id, season, episode, collector):
    """Check Torrentio for Real-Debrid cached torrents."""
    if not imdb_id:
        return
    syn_key = f"tio:{imdb_id}:{season}:{episode}"
    ready, waiting_events = acquire_in_flight([syn_key], 'rd')
    if waiting_events:
        for ev in waiting_events:
            ev.wait(timeout=7.5)
        with _IN_FLIGHT_LOCK:
            cached_ep = _EPISODE_CACHE_RESULTS.get((syn_key.lower(), 'rd'))
        if cached_ep is not None:
            collector.extend(cached_ep)
            return
    try:
        if str(season).isdigit() and int(season) > 0:
            url_path = f'series/{imdb_id}:{season}:{episode}.json'
        else:
            url_path = f'movie/{imdb_id}.json'
        params = 'realdebrid=T2iZoymNCCD1T5c2sX5u8tIZVcgcFWlCsCJ72rCmrU2mDdmvgieM'
        url = f'https://torrentio.strem.fun/debridoptions=nodownloadlinks,nocatalog|{params}/stream/{url_path}'
        pattern = re.compile(r'\b\w{40}\b')
        response = client.get(url, timeout=7)
        found = []
        if response and response.ok:
            files = response.json().get('streams', [])
            for f in files:
                if '+' in f.get('name', '') and 'url' in f:
                    matches = pattern.findall(f['url'])
                    if matches:
                        h = matches[-1].lower()
                        found.append(h)
                        collector.append(h)
        with _IN_FLIGHT_LOCK:
            _EPISODE_CACHE_RESULTS[(syn_key.lower(), 'rd')] = found
    except Exception as e:
        control.log(f'Torrentio cache check error: {e}', 'warning')
    finally:
        if ready:
            release_in_flight(ready, 'rd')


def _aio_check_cache(imdb_id, season, episode, collector):
    """Check AIOStreams for AllDebrid cached torrents."""
    if not imdb_id:
        return
    syn_key = f"aio:ad:{imdb_id}:{season}:{episode}"
    ready, waiting_events = acquire_in_flight([syn_key], 'ad')
    if waiting_events:
        for ev in waiting_events:
            ev.wait(timeout=7.5)
        with _IN_FLIGHT_LOCK:
            cached_ep = _EPISODE_CACHE_RESULTS.get((syn_key.lower(), 'ad'))
        if cached_ep is not None:
            collector.extend(cached_ep)
            return
    try:
        if str(season).isdigit() and int(season) > 0:
            params = {'type': 'series', 'id': f'{imdb_id}:{season}:{episode}'}
        else:
            params = {'type': 'movie', 'id': str(imdb_id)}

        headers = {
            'x-aiostreams-user-data': (
                'ewogICJzZXJ2aWNlcyI6IFsKICAgIHsKICAgICAgImlkIjogImFsbGRlYnJpZCIsCiAgICAgICJlbmFi'
                'bGVkIjogdHJ1ZSwKICAgICAgImNyZWRlbnRpYWxzIjogeyJhcGlLZXkiOiAic3RhdGljRGVtb0FwaWtl'
                'eVByZW0ifQogICAgfQogIF0sCiAgInByZXNldHMiOiBbCiAgICB7CiAgICAgICJ0eXBlIjogIm1lZGlh'
                'ZnVzaW9uIiwKICAgICAgImluc3RhbmNlSWQiOiAiNWI4IiwKICAgICAgImVuYWJsZWQiOiB0cnVlLAog'
                'ICAgICAib3B0aW9ucyI6IHsKICAgICAgICAibmFtZSI6ICJNZWRpYUZ1c2lvbiIsCiAgICAgICAgInRp'
                'bWVvdXQiOiA2NTAwLAogICAgICAgICJyZXNvdXJjZXMiOiBbInN0cmVhbSJdLAogICAgICAgICJ1c2VD'
                'YWNoZWRSZXN1bHRzT25seSI6IHRydWUsCiAgICAgICAgImVuYWJsZVdhdGNobGlzdENhdGFsb2dzIjog'
                'ZmFsc2UsCiAgICAgICAgImRvd25sb2FkVmlhQnJvd3NlciI6IGZhbHNlLAogICAgICAgICJjb250cmli'
                'dXRvclN0cmVhbXMiOiBmYWxzZSwKICAgICAgICAiY2VydGlmaWNhdGlvbkxldmVsc0ZpbHRlciI6IFtd'
                'LAogICAgICAgICJudWRpdHlGaWx0ZXIiOiBbXSwKICAgICAgICAibWVkaWFUeXBlcyI6IFtdCiAgICAg'
                'IH0KICAgIH0sCiAgICB7CiAgICAgICJ0eXBlIjogInN0cmVtdGhydVRvcnoiLAogICAgICAiaW5zdGFu'
                'Y2VJZCI6ICI1NDgiLAogICAgICAiZW5hYmxlZCI6IHRydWUsCiAgICAgICJvcHRpb25zIjogewogICAg'
                'ICAgICJuYW1lIjogIlN0cmVtVGhydSBUb3J6IiwKICAgICAgICAidGltZW91dCI6IDY1MDAsCiAgICAg'
                'ICAgInJlc291cmNlcyI6IFsic3RyZWFtIl0sCiAgICAgICAgIm1lZGlhVHlwZXMiOiBbXSwKICAgICAg'
                'ICAiaW5jbHVkZVAyUCI6IGZhbHNlLAogICAgICAgICJ1c2VNdWx0aXBsZUluc3RhbmNlcyI6IGZhbHNl'
                'CiAgICAgIH0KICAgIH0KICBdLAogICJmb3JtYXR0ZXIiOiB7CiAgICAiaWQiOiAidG9ycmVudGlvIiwK'
                'ICAgICJkZWZpbml0aW9uIjogewogICAgICAibmFtZSI6ICIiLAogICAgICAiZGVzY3JpcHRpb24iOiAi'
                'IgogICAgfQogIH0sCiAgInNvcnRDcml0ZXJpYSI6IHsKICAgICJnbG9iYWwiOiBbXQogIH0sCiAgImRl'
                'ZHVwbGljYXRvciI6IHsKICAgICJlbmFibGVkIjogZmFsc2UsCiAgICAia2V5cyI6IFsiaW5mb0hhc2gi'
                'XSwKICAgICJtdWx0aUdyb3VwQmVoYXZpb3VyIjogImFnZ3Jlc3NpdmUiLAogICAgImNhY2hlZCI6ICJz'
                'aW5nbGVfcmVzdWx0IiwKICAgICJ1bmNhY2hlZCI6ICJwZXJfc2VydmljZSIsCiAgICAicDJwIjogInNp'
                'bmdsZV9yZXN1bHQiLAogICAgImV4Y2x1ZGVBZGRvbnMiOiBbXQogIH0sCiAgImV4Y2x1ZGVVbmNhY2hl'
                'ZCI6IHRydWUKfQ=='
            )
        }
        url = 'https://aiostreams.fortheweak.cloud/api/v1/search'
        response = client.get(url, params=params, headers=headers, timeout=7)
        found = []
        if response and response.ok:
            files = response.json().get('data', {}).get('results', [])
            for f in files:
                info_hash = f.get('infoHash')
                if info_hash:
                    h = info_hash.lower()
                    found.append(h)
                    collector.append(h)
        with _IN_FLIGHT_LOCK:
            _EPISODE_CACHE_RESULTS[(syn_key.lower(), 'ad')] = found
    except Exception as e:
        control.log(f'AIOStreams cache check error: {e}', 'warning')
    finally:
        if ready:
            release_in_flight(ready, 'ad')


def _dmm_check_cache(hash_list, imdb_id, collector):
    """Check DMM (Debrid Media Manager) for cached torrent hashes."""
    if not imdb_id or not hash_list:
        return
    try:
        # DMM only handles 40-char hashes and max 100 per request
        clean_hashes = [h.lower() for h in hash_list if h and len(h) == 40]
        if not clean_hashes:
            return

        # Batch in chunks of 100 up to 300 total hashes so candidate hashes are verified without random drop
        chunk_size = 100
        hashes_to_check = clean_hashes[:300]
        url = 'https://debridmediamanager.com/api/availability/check'
        for i in range(0, len(hashes_to_check), chunk_size):
            chunk = hashes_to_check[i:i + chunk_size]
            dmm_key, solution = _get_dmm_secret()
            data = {
                'dmmProblemKey': dmm_key,
                'solution': solution,
                'imdbId': imdb_id,
                'hashes': chunk
            }
            response = client.post(url, json_data=data, timeout=5)
            if response and response.ok:
                available = response.json().get('available', [])
                for f in available:
                    if 'hash' in f and f['hash']:
                        collector.append(f['hash'].lower())
    except Exception as e:
        control.log(f'DMM cache check error: {e}', 'warning')


# ═══════════════════════════════════════════════════════════════════════════
#  DMM Secret Generation (ported from POV)
# ═══════════════════════════════════════════════════════════════════════════

def _to_int32(v):
    """Truncate to signed 32-bit integer (replaces ctypes.c_long for Xbox compat)."""
    v = v & 0xFFFFFFFF
    return v - 0x100000000 if v >= 0x80000000 else v


def _get_dmm_secret():
    def _calc_value_alg(t, n, const):
        temp = t ^ n
        t = _to_int32(temp * const)
        t4 = _to_int32(t << 5)
        t5 = _to_int32((t & 0xFFFFFFFF) >> 27)
        return t4 | t5

    def _slice_hash(s, n):
        half = int(len(s) // 2)
        left_s, right_s = s[:half], s[half:]
        left_n, right_n = n[:half], n[half:]
        i = ''.join(ls + ln for ls, ln in zip(left_s, left_n))
        return i + right_n[::-1] + right_s[::-1]

    def _generate_hash(e):
        t = _to_int32(0xDEADBEEF ^ len(e))
        a = 1103547991 ^ len(e)
        for ch in e:
            n = ord(ch)
            t = _calc_value_alg(t, n, 2654435761)
            a = _calc_value_alg(a, n, 1597334677)
        t = _to_int32(t + _to_int32(a * 1566083941))
        a = _to_int32(a + _to_int32(t * 2024237689))
        return _to_int32(t ^ a) & 0xFFFFFFFF

    ran = random.randrange(10 ** 80)
    hex_str = f"{ran:064x}"[:8]
    timestamp = int(time.time())
    dmm_key = f"{hex_str}-{timestamp}"

    s = _generate_hash(dmm_key)
    s = f"{s:x}"

    n = _generate_hash("debridmediamanager.com%%fe7#td00rA3vHz%VmI-" + hex_str)
    n = f"{n:x}"

    solution = _slice_hash(s, n)
    return dmm_key, solution


# Backward compatibility alias
clean_database = prune_expired_hashes

