from resources.lib.ui import source_utils
"""
database.py - Otaku Database & Caching Layer
=============================================
Clean, organized caching and metadata storage.

Architecture
------------
SQL          - Lock-free SQLite context manager (WAL mode concurrent access)
Memory Cache - Window-property RAM cache with expiry
General Cache- 3-tier caching: RAM → SQLite → fresh API call
Shows        - Anime show / meta / episode CRUD
Mappings     - Cross-service ID lookups
Watchlist    - Per-service watchlist cache with activity invalidation
Enrichment   - AniList supplementary metadata cache
History      - Per-category search history
Maintenance  - Cache clearing helpers
"""

import ast
import atexit
import builtins
import hashlib
import io
import json
import os
import pickle
import random
import re
import threading
import time

import xbmcgui
import xbmcvfs

from sqlite3 import OperationalError, dbapi2
from resources.lib.ui import control


# ═══════════════════════════════════════════════════════════════════════════
#  Safe Serialization (JSON Primary + Restricted Unpickler Legacy Fallback)
# ═══════════════════════════════════════════════════════════════════════════

_SAFE_PICKLE_BUILTINS = frozenset({
    'set', 'frozenset', 'slice', 'complex', 'bytearray', 'bytes',
    'dict', 'list', 'tuple', 'str', 'int', 'float', 'bool',
})


class _SafeUnpickler(pickle.Unpickler):
    """Restricted unpickler for legacy SQLite blobs that blocks arbitrary code execution."""

    def find_class(self, module, name):
        if module in ('builtins', '__builtin__') and name in _SAFE_PICKLE_BUILTINS:
            return getattr(builtins, name)
        raise pickle.UnpicklingError(f"Blocked unsafe pickle global: {module}.{name}")


def _json_default(obj):
    if isinstance(obj, (set, frozenset)):
        return list(obj)
    if isinstance(obj, (bytes, bytearray)):
        return obj.decode('utf-8', errors='replace')
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def dumps(obj):
    """Serialize *obj* to UTF-8 JSON bytes for SQLite storage."""
    if isinstance(obj, (bytes, bytearray)):
        return bytes(obj)
    try:
        return json.dumps(obj, ensure_ascii=False, default=_json_default).encode('utf-8')
    except (TypeError, ValueError):
        return pickle.dumps(obj)


_JSON_PARSE_MISS = object()


def loads(blob):
    """Safely deserialize a SQLite blob (UTF-8 JSON or legacy restricted pickle)."""
    if blob is None or blob == b'' or blob == '':
        return {}
    if isinstance(blob, (dict, list)):
        return blob
    if isinstance(blob, (bytes, bytearray)):
        # Pickle protocols 2..5 start with 0x80
        if blob[:1] == b'\x80':
            return _SafeUnpickler(io.BytesIO(blob)).load()
        try:
            decoded = blob.decode('utf-8')
        except UnicodeDecodeError:
            return _SafeUnpickler(io.BytesIO(blob)).load()
        parsed = control.loads_json(decoded, default=_JSON_PARSE_MISS)
        if parsed is not _JSON_PARSE_MISS:
            return parsed
        return _SafeUnpickler(io.BytesIO(blob)).load()
    if isinstance(blob, str):
        parsed = control.loads_json(blob, default=_JSON_PARSE_MISS)
        if parsed is not _JSON_PARSE_MISS:
            return parsed
        return _SafeUnpickler(io.BytesIO(blob.encode('latin-1'))).load()
    return {}


# ═══════════════════════════════════════════════════════════════════════════
#  SQL - Thread-Local Pooled SQLite Context Manager (WAL-mode concurrent)
# ═══════════════════════════════════════════════════════════════════════════

_thread_local = threading.local()
_conns_lock = threading.RLock()
_all_thread_conns = {}


def _dict_factory(cursor, row):
    """Row factory that returns dicts keyed by column name."""
    return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}


def _get_thread_conns():
    tid = threading.get_ident()
    conns = getattr(_thread_local, 'conns', None)
    if conns is None:
        conns = {}
        _thread_local.conns = conns
    with _conns_lock:
        _all_thread_conns[tid] = conns
    return conns


def prune_dead_thread_connections():
    """Close and remove SQLite connections belonging to worker threads that have exited."""
    alive_tids = {t.ident for t in threading.enumerate() if t.ident is not None}
    with _conns_lock:
        dead_tids = [tid for tid in list(_all_thread_conns.keys()) if tid not in alive_tids]
        dead_dicts = [_all_thread_conns.pop(tid, {}) for tid in dead_tids]
    for conns in dead_dicts:
        for _, (conn, _) in list(conns.items()):
            try:
                conn.close()
            except (dbapi2.Error, OSError) as e:
                control.log(f"dead thread db close error: {e}", 'debug')
        conns.clear()


def close_thread_connections(path=None):
    """Close cached SQLite connections for the current thread and prune dead worker threads."""
    tid = threading.get_ident()
    conns = getattr(_thread_local, 'conns', None)
    if conns:
        if path is not None:
            target = os.path.abspath(path)
            for key in ((target, True), (target, False), (target, 'ro'), (target, 'rw'), target, f"{target}:ro"):
                entry = conns.pop(key, None)
                if entry:
                    try:
                        entry[0].close()
                    except (dbapi2.Error, OSError) as e:
                        control.log(f"database close error: {e}", 'debug')
            if not conns:
                with _conns_lock:
                    _all_thread_conns.pop(tid, None)
        else:
            for _, (conn, _) in list(conns.items()):
                try:
                    conn.close()
                except (dbapi2.Error, OSError) as e:
                    control.log(f"database pool close error: {e}", 'debug')
            conns.clear()
            with _conns_lock:
                _all_thread_conns.pop(tid, None)
    prune_dead_thread_connections()


def close_all_connections(path=None):
    """Close cached SQLite connections across all threads in this interpreter."""
    with _conns_lock:
        all_items = list(_all_thread_conns.items())
        if path is None:
            _all_thread_conns.clear()
    target = os.path.abspath(path) if path is not None else None
    for tid, conns in all_items:
        if target is not None:
            for key in ((target, True), (target, False), (target, 'ro'), (target, 'rw'), target, f"{target}:ro"):
                entry = conns.pop(key, None)
                if entry:
                    try:
                        entry[0].close()
                    except (dbapi2.Error, OSError) as e:
                        control.log(f"database close error: {e}", 'debug')
            if not conns:
                with _conns_lock:
                    _all_thread_conns.pop(tid, None)
        else:
            for _, (conn, _) in list(conns.items()):
                try:
                    conn.close()
                except (dbapi2.Error, OSError) as e:
                    control.log(f"database pool close error: {e}", 'debug')
            conns.clear()
    # Ensure current thread local dict is also closed if not yet registered
    cur_conns = getattr(_thread_local, 'conns', None)
    if cur_conns:
        if target is not None:
            for key in ((target, True), (target, False), (target, 'ro'), (target, 'rw'), target, f"{target}:ro"):
                entry = cur_conns.pop(key, None)
                if entry:
                    try:
                        entry[0].close()
                    except (dbapi2.Error, OSError):
                        pass
        else:
            for _, (conn, _) in list(cur_conns.items()):
                try:
                    conn.close()
                except (dbapi2.Error, OSError):
                    pass
            cur_conns.clear()


atexit.register(close_all_connections)


def _is_db_corruption_error(exc):
    if not exc:
        return False
    msg = str(exc).lower()
    return any(p in msg for p in ('malformed', 'not a database', 'disk image is malformed', 'file is encrypted'))


def _quarantine_and_recover_db(path):
    if not path:
        return
    abs_path = os.path.abspath(path)
    close_thread_connections(abs_path)
    ts = int(time.time())
    control.log(f"CRITICAL: SQLite database corruption detected on {abs_path}. Quarantining database.", level='error')
    for ext in ('', '-wal', '-shm', '-journal'):
        f = abs_path + ext
        if os.path.exists(f):
            try:
                os.rename(f, f"{f}.corrupt.{ts}")
            except OSError as oe:
                control.log(f"Failed to quarantine {f}: {oe}", level='warning')

    cache_path = os.path.abspath(control.cacheFile) if getattr(control, 'cacheFile', None) else ''
    search_path = os.path.abspath(control.searchHistoryDB) if getattr(control, 'searchHistoryDB', None) else ''
    malsync_path = os.path.abspath(control.malSyncDB) if getattr(control, 'malSyncDB', None) else ''
    mapping_path = os.path.abspath(control.mappingDB) if getattr(control, 'mappingDB', None) else ''

    try:
        stale_prefixes = (f"{path}:", f"{abs_path}:")
        for ready_tag in list(_tables_ready):
            if ready_tag.startswith(stale_prefixes):
                _tables_ready.discard(ready_tag)
        if abs_path == cache_path:
            _tables_ready.discard(f"{control.cacheFile}:cache")
            _init_cache_table()
            control.log("Auto-recovery: Re-initialized cache.db schema", level='info')
        elif abs_path == search_path:
            _tables_ready.discard(f"{control.searchHistoryDB}:search_tables")
            _ensure_search_tables()
            control.log("Auto-recovery: Re-initialized search.db schema", level='info')
        elif abs_path == malsync_path:
            from resources.lib.ui.database_sync import SyncDatabase
            SyncDatabase()
            control.log("Auto-recovery: Re-initialized malSync.db schema", level='info')
        elif abs_path == mapping_path:
            control.log("Auto-recovery: mappings.db quarantined; will be restored on next service sync", level='info')
    except Exception as re:
        control.log(f"Auto-recovery schema recreation error for {abs_path}: {re}", level='error')


def execute_write_with_retry(cur, sql, params=(), max_retries=3):
    """Execute a write statement with exponential backoff and jitter on database lock."""
    for attempt in range(max_retries):
        try:
            return cur.execute(sql, params)
        except (dbapi2.OperationalError, OperationalError) as e:
            if 'locked' in str(e).lower() or 'busy' in str(e).lower():
                if attempt == max_retries - 1:
                    raise
                jitter = random.uniform(0.01, 0.04)
                backoff = (0.05 * (2 ** attempt)) + jitter
                time.sleep(backoff)
            else:
                raise


def _resolve_mmap_size_bytes():
    """Return SQLite mmap_size in bytes; disabled (0) on low-memory / 32-bit hardware (C-37)."""
    if control.is_low_memory():
        return 0
    mmap_setting_mb = control.getInt('db.sqlite.mmap_size_mb') or 32
    return max(0, int(mmap_setting_mb)) * 1048576


class SQL:
    """Thread-local pooled SQLite context manager with optimized PRAGMAs.

    WAL journal mode allows concurrent readers without locking.
    isolation_level=None enables autocommit for faster writes.

    Usage::

        with SQL(db_path) as cursor:
            cursor.execute('SELECT ...')
            cursor.connection.commit()   # needed for writes
    """

    def __init__(self, path, timeout=30, is_readonly=None):
        self.path = path
        self.timeout = timeout
        self._conn = None
        self._cursor = None
        abs_path = os.path.abspath(self.path) if self.path else ''
        info_path = os.path.abspath(control.infoDB) if getattr(control, 'infoDB', None) else ''
        mapping_path = os.path.abspath(control.mappingDB) if getattr(control, 'mappingDB', None) else ''
        self.is_readonly = (abs_path in (info_path, mapping_path)) if is_readonly is None else bool(is_readonly)

    def __enter__(self):
        abs_path = os.path.abspath(self.path)
        info_path = os.path.abspath(control.infoDB) if getattr(control, 'infoDB', None) else ''
        mapping_path = os.path.abspath(control.mappingDB) if getattr(control, 'mappingDB', None) else ''
        if not self.is_readonly and abs_path in (info_path, mapping_path):
            self.is_readonly = True
        is_readonly = self.is_readonly

        if not is_readonly and not xbmcvfs.exists(control.dataPath):
            xbmcvfs.mkdirs(control.dataPath)

        cache_key = (abs_path, is_readonly)

        for attempt in range(2):
            conns = _get_thread_conns()
            st_ino = None
            if os.path.exists(abs_path):
                try:
                    st_ino = os.stat(abs_path).st_ino
                except OSError:
                    st_ino = None

            if cache_key in conns:
                cached_conn, cached_ino = conns[cache_key]
                if st_ino is None or (cached_ino is not None and st_ino != cached_ino):
                    try:
                        cached_conn.close()
                    except (dbapi2.Error, OSError) as e:
                        control.log(f"cached db close error: {e}", 'debug')
                    conns.pop(cache_key, None)

            try:
                if cache_key not in conns:
                    if self.is_readonly and os.path.exists(self.path):
                        import urllib.parse
                        safe_chars = '/:\\'
                        ro_uri = f"file:{urllib.parse.quote(abs_path, safe=safe_chars)}?mode=ro"
                        try:
                            conn = dbapi2.connect(
                                ro_uri,
                                uri=True,
                                timeout=float(self.timeout),
                                isolation_level=None,
                                check_same_thread=False
                            )
                        except Exception as ro_exc:
                            control.log(f"SQL read-only URI fallback for {abs_path}: {ro_exc}", 'warning')
                            conn = dbapi2.connect(
                                f"file:{abs_path}?mode=ro",
                                uri=True,
                                timeout=float(self.timeout),
                                isolation_level=None,
                                check_same_thread=False
                            )
                    else:
                        conn = dbapi2.connect(
                            self.path,
                            timeout=float(self.timeout),
                            isolation_level=None,
                            check_same_thread=False
                        )
                    conn.row_factory = _dict_factory
                    if not is_readonly:
                        conn.execute("PRAGMA foreign_keys = ON")
                        # Synchronous setting (0=OFF, 1=NORMAL, 2=FULL)
                        sync_val = control.getSetting('db.sqlite.synchronous')
                        sync_modes = {'0': 'OFF', '1': 'NORMAL', '2': 'FULL'}
                        sync_mode = sync_modes.get(str(sync_val), 'NORMAL')
                        conn.execute(f"PRAGMA synchronous = {sync_mode}")
                        try:
                            conn.execute("PRAGMA journal_mode = WAL")
                        except dbapi2.DatabaseError:
                            pass
                        # Cache size setting (negative value in KiB)
                        cache_mb = control.getInt('db.sqlite.cache_size_mb') or (16 if control.is_low_memory() else 32)
                        if cache_mb > 0:
                            conn.execute(f"PRAGMA cache_size = -{cache_mb * 1024}")
                        # Memory map size setting (disable mmap on 32-bit / low-RAM to avoid std::bad_alloc fragmentation)
                        conn.execute(f"PRAGMA mmap_size = {_resolve_mmap_size_bytes()}")
                        # Temp store in RAM
                        if control.getBool('db.sqlite.temp_store_ram', default=True):
                            conn.execute("PRAGMA temp_store = MEMORY")
                    elif control.is_low_memory():
                        # Disable virtual-memory mmap on read-only pools (info.db/mappings.db) on 32-bit / low-RAM devices
                        try:
                            conn.execute("PRAGMA mmap_size = 0")
                        except dbapi2.DatabaseError:
                            pass
                    if os.path.exists(abs_path):
                        try:
                            st_ino = os.stat(abs_path).st_ino
                        except OSError:
                            st_ino = None
                    conns[cache_key] = (conn, st_ino)

                self._conn = conns[cache_key][0]
                self._cursor = self._conn.cursor()
                return self._cursor
            except Exception as exc:
                close_thread_connections(self.path)
                self._conn = None
                if attempt == 0 and _is_db_corruption_error(exc):
                    _quarantine_and_recover_db(self.path)
                    continue
                raise

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            if self._cursor is not None:
                self._cursor.close()
        except dbapi2.Error as e:
            control.log(f"cursor close error: {e}", 'debug')

        if exc_type:
            try:
                if self._conn is not None and getattr(self._conn, 'in_transaction', False):
                    self._conn.rollback()
            except dbapi2.Error as e:
                control.log(f"db rollback error: {e}", 'debug')
            close_thread_connections(self.path)

            if _is_db_corruption_error(exc_val):
                _quarantine_and_recover_db(self.path)

            if exc_type is OperationalError:
                import traceback
                control.log('database OperationalError', level='error')
                control.log(''.join(traceback.format_exception(
                    exc_type, exc_val, exc_tb)), level='error')
                return False
            import traceback
            control.log('database error', level='error')
            control.log(''.join(traceback.format_exception(
                exc_type, exc_val, exc_tb)), level='error')
        return False


# ═══════════════════════════════════════════════════════════════════════════
#  Memory Cache - Kodi Window Properties with Expiry & Generation Counter
# ═══════════════════════════════════════════════════════════════════════════

_window = control.homeWindow
_MEM_GEN_PROP = f'{control.ADDON_ID}_cache_gen'
_MEM_KEYS_PROP = f'{control.ADDON_ID}_cache_keys'
_MAX_MEM_CACHE_BYTES = 65536  # 64 KB ceiling to prevent Kodi GUI memory bloat


def _get_mem_prefix():
    gen = _window.getProperty(_MEM_GEN_PROP) or '0'
    return f'{control.ADDON_ID}_c{gen}_'


def _register_mem_key(full_key):
    """Keep track of active window property keys for generational garbage collection."""
    try:
        existing = _window.getProperty(_MEM_KEYS_PROP) or ''
        keys = set(existing.split(',')) if existing else set()
        if full_key not in keys:
            keys.add(full_key)
            if len(keys) > 500:
                keys = set(list(keys)[-250:])
            _window.setProperty(_MEM_KEYS_PROP, ','.join(keys))
    except Exception:
        pass


def _bump_mem_generation():
    """Increment generation counter and purge window properties from previous generation."""
    try:
        registered = _window.getProperty(_MEM_KEYS_PROP) or ''
        if registered:
            for k in registered.split(','):
                if k:
                    _window.clearProperty(k)
            _window.clearProperty(_MEM_KEYS_PROP)
    except Exception:
        pass

    try:
        gen = int(_window.getProperty(_MEM_GEN_PROP) or '0') + 1
    except ValueError:
        gen = int(time.time())
    _window.setProperty(_MEM_GEN_PROP, str(gen))


def _mem_get(key):
    """Return parsed data or *None* if missing / expired."""
    prefix = _get_mem_prefix()
    raw = _window.getProperty(prefix + key)
    if not raw:
        return None
    try:
        sep = raw.index('|')
        if int(raw[:sep]) > int(time.time()):
            return ast.literal_eval(raw[sep + 1:])
    except (ValueError, SyntaxError) as e:
        control.log(f"_mem_get parse error for {key}: {e}", 'debug')
    _window.clearProperty(prefix + key)
    return None


def _mem_set(key, value_repr, hours):
    """Store *value_repr* (a ``repr()`` string) with an expiry of *hours*. Payloads >64KB bypass RAM window cache."""
    if not value_repr or len(value_repr) > _MAX_MEM_CACHE_BYTES:
        return
    expires = int(time.time() + hours * 3600)
    full_key = _get_mem_prefix() + key
    _window.setProperty(full_key, f"{expires}|{value_repr}")
    _register_mem_key(full_key)


def _mem_del(key):
    """Remove a single key from the RAM cache."""
    _window.clearProperty(_get_mem_prefix() + key)


# ═══════════════════════════════════════════════════════════════════════════
#  Lazy Table Initialization (once per session)
# ═══════════════════════════════════════════════════════════════════════════

_tables_ready = set()
_tables_ready_lock = threading.RLock()


def _ensure_table(db_path, name, ddl):
    """Run *ddl* only the first time (*db_path*, *name*) is seen."""
    tag = f"{db_path}:{name}"
    if tag in _tables_ready:
        return
    with _tables_ready_lock:
        if tag in _tables_ready:
            return
        with SQL(db_path) as cur:
            cur.execute(ddl)
            cur.connection.commit()
        _tables_ready.add(tag)


def _init_cache_table():
    _ensure_table(
        control.cacheFile, 'cache',
        'CREATE TABLE IF NOT EXISTS cache '
        '(key TEXT UNIQUE, value TEXT, date INTEGER)'
    )
    # Index once at init; avoid running DDL on every cache write (hot path).
    _ensure_table(
        control.cacheFile, 'cache_ix_key',
        'CREATE UNIQUE INDEX IF NOT EXISTS ix_cache ON cache (key)'
    )
    _ensure_table(
        control.cacheFile, 'cache_ix_date',
        'CREATE INDEX IF NOT EXISTS ix_cache_date ON cache (date)'
    )


# ═══════════════════════════════════════════════════════════════════════════
#  General Cache - 3-Tier: RAM → SQLite → Fresh API Call
# ═══════════════════════════════════════════════════════════════════════════

def _is_empty_result(val):
    """Detect empty results that should not poison the cache.
    Includes None, empty sequences, empty dicts, or torrent dicts with empty buckets."""
    if not val:
        return True
    if isinstance(val, dict):
        if not any(val.values()):
            return True
        if all(isinstance(v, (list, tuple, set, dict)) and not v for v in val.values()):
            return True
    return False



# ═══════════════════════════════════════════════════════════════════════════

def get(function, duration, *args, **kwargs):
    """Cached function call with 3-tier lookup.

    :param function:  Callable to execute on cache miss.
    :param duration:  Cache validity in **hours**.
    :param args/kwargs:  Forwarded to *function* on miss.
        Special kwarg ``key`` is popped and appended to the cache key.
    """
    if duration == 24:
        configured_ttl = control.getInt('cache.metadata.ttl')
        if configured_ttl:
            duration = configured_ttl
    elif duration == 8:
        configured_ttl = control.getInt('cache.scrapers.ttl')
        if configured_ttl:
            duration = configured_ttl

    key = _hash_function(function, args, kwargs)
    if 'key' in kwargs:
        key += kwargs.pop('key')

    # --- Tier 1: RAM (instant) ---
    mem = _mem_get(key)
    if mem is not None and not _is_empty_result(mem):
        return mem

    # --- Tier 2: SQLite ---
    _init_cache_table()
    row = None
    with SQL(control.cacheFile) as cur:
        cur.execute('SELECT value, date FROM cache WHERE key=?', (key,))
        row = cur.fetchone()

    if row and is_cache_valid(row['date'], duration):
        try:
            data = ast.literal_eval(row['value'])
            if data is not None and not _is_empty_result(data):
                _mem_set(key, row['value'], duration)
                return data
        except Exception:
            control.log(
                f"Cache corrupt for key {key}, fetching fresh data",
                level='warning')

    # --- Tier 3: Fresh call ---
    result = function(*args, **kwargs)
    if result is None or _is_empty_result(result):
        return result
    result_repr = repr(result)
    _cache_write(key, result_repr)
    _mem_set(key, result_repr, duration)
    return result


_coalesce_locks = {}
_coalesce_meta_lock = threading.Lock()
_legacy_build_cleaned = False


def get_coalesced(function, duration, *args, **kwargs):
    """Share overlapping progress / metadata calls across concurrent Kodi threads.

    Uses an in-process per-key threading.Lock() guarded by _coalesce_meta_lock,
    double-checking RAM and SQLite caches before executing function(*args, **kwargs).
    """
    global _legacy_build_cleaned
    if duration == 24:
        configured_ttl = control.getInt('cache.metadata.ttl')
        if configured_ttl:
            duration = configured_ttl
    elif duration == 8:
        configured_ttl = control.getInt('cache.scrapers.ttl')
        if configured_ttl:
            duration = configured_ttl

    key = _hash_function(function, args, kwargs)
    if 'key' in kwargs:
        key += kwargs.get('key')

    # Tier 1: RAM cache check (instant)
    mem = _mem_get(key)
    if mem is not None and not _is_empty_result(mem):
        return mem

    # Clean up any legacy .build-* SQLite files if present
    if not _legacy_build_cleaned and getattr(control, 'dataPath', None) and os.path.isdir(control.dataPath):
        _legacy_build_cleaned = True
        try:
            for fname in os.listdir(control.dataPath):
                if '.build-' in fname:
                    try:
                        os.remove(os.path.join(control.dataPath, fname))
                    except OSError:
                        pass
        except OSError:
            pass

    with _coalesce_meta_lock:
        if len(_coalesce_locks) > 256:
            # Prune uncontended coalesce locks to keep long-lived service memory bounded
            idle_keys = [k for k, lk in list(_coalesce_locks.items()) if k != key and not lk.locked()]
            for k in idle_keys[:len(_coalesce_locks) - 128]:
                _coalesce_locks.pop(k, None)
        key_lock = _coalesce_locks.get(key)
        if key_lock is None:
            key_lock = threading.Lock()
            _coalesce_locks[key] = key_lock

    with key_lock:
        # Double-check Tier 1: RAM
        mem = _mem_get(key)
        if mem is not None and not _is_empty_result(mem):
            return mem

        # Double-check Tier 2: SQLite and Tier 3: Fresh call via get()
        return get(function, duration, *args, **kwargs)


def remove(function, *args, **kwargs):
    """Remove the cached value for a function call."""
    try:
        key = _hash_function(function, args, kwargs)
        _cache_delete(key)
        _mem_del(key)
        return True
    except Exception:
        return False


def peek(function, duration=24, *args, **kwargs):
    """Non-blocking check of RAM window cache and SQLite cache.db.

    Returns deserialized cached value on hit, None on miss without calling function.
    """
    if not isinstance(duration, (int, float)):
        args = (duration,) + args
        duration = 24

    if duration == 24:
        configured_ttl = control.getInt('cache.metadata.ttl')
        if configured_ttl:
            duration = configured_ttl
    elif duration == 8:
        configured_ttl = control.getInt('cache.scrapers.ttl')
        if configured_ttl:
            duration = configured_ttl

    if isinstance(function, str):
        key = function
    else:
        kwargs_copy = dict(kwargs)
        extra_key = kwargs_copy.pop('key', '')
        key = _hash_function(function, args, kwargs_copy) + extra_key

    # --- Tier 1: RAM (instant) ---
    mem = _mem_get(key)
    if mem is not None and not _is_empty_result(mem):
        return mem

    # --- Tier 2: SQLite ---
    _init_cache_table()
    row = None
    try:
        with SQL(control.cacheFile) as cur:
            cur.execute('SELECT value, date FROM cache WHERE key=?', (key,))
            row = cur.fetchone()
    except Exception as e:
        control.log(f"peek SQL error: {e}", level='debug')
        return None

    if row and is_cache_valid(row['date'], duration):
        try:
            data = ast.literal_eval(row['value'])
        except Exception:
            try:
                data = control.loads_json(row['value'], None)
            except Exception:
                data = None

        if data is not None and not _is_empty_result(data):
            _mem_set(key, row['value'], duration)
            return data

    return None


# — helpers ------------------------------------------------------------------

def _hash_function(func, args, kwargs):
    name = re.sub(
        r'.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', repr(func))
    return name + generate_md5((args, kwargs))


def generate_md5(*args):
    """MD5 hex-digest of the string representation of *args*."""
    md5 = hashlib.md5()
    for arg in args:
        md5.update(str(arg).encode())
    return md5.hexdigest()


def is_cache_valid(cached_time, hours):
    """True when *cached_time* (epoch) is younger than *hours*."""
    return (int(time.time()) - cached_time) < (hours * 3600)


def _cache_write(key, value_repr):
    _init_cache_table()
    with SQL(control.cacheFile) as cur:
        execute_write_with_retry(
            cur,
            'REPLACE INTO cache (key, value, date) VALUES (?, ?, ?)',
            (key, value_repr, int(time.time())))
        cur.connection.commit()


def _cache_delete(key):
    with SQL(control.cacheFile) as cur:
        execute_write_with_retry(
            cur,
            'DELETE FROM cache WHERE key=?',
            (key,))
        cur.connection.commit()


# — backward-compat aliases (kept for any external callers) -----------------

def hash_function(function_instance, *args):
    function_name = re.sub(
        r'.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '',
        repr(function_instance))
    return function_name + generate_md5(args)


def cache_get(key):
    _init_cache_table()
    with SQL(control.cacheFile) as cur:
        cur.execute('SELECT * FROM cache WHERE key=?', (key,))
        return cur.fetchone()


def cache_insert(key, value):
    _cache_write(key, value)


def cache_remove(key):
    _cache_delete(key)


def cache_clear():
    """Wipe general cache, debrid cache, watchlist cache, activity, and enrichment data."""
    _bump_mem_generation()
    with SQL(control.cacheFile) as cur:
        cur.execute("DROP TABLE IF EXISTS cache")
        cur.execute("VACUUM")
        cur.connection.commit()
    _tables_ready.discard(f"{control.cacheFile}:cache")
    _tables_ready.discard(f"{control.cacheFile}:cache_ix_key")
    _tables_ready.discard(f"{control.cacheFile}:cache_ix_date")

    # Clear debrid cache as well
    try:
        from resources.lib.debrid import debrid_cache
        debrid_cache.clear_debrid_cache()
    except Exception as e:
        control.log(f"Error clearing debrid cache: {e}", 'debug')

    # Reset circuit breaker
    try:
        from resources.lib.pages import circuit_breaker
        circuit_breaker.reset()
    except Exception:
        pass

    control.setSetting('last_played_source', str(None))

    clear_watchlist_cache()
    clear_watchlist_activity()
    clear_anilist_enrichment()

    control.notify(
        f'{control.ADDON_NAME}: {control.lang(30086)}',
        control.lang(30087), time=5000, sound=False)


def cache_clear_providers():
    """Purge provider and scraper cache (torrents, embeds, season packs, debrid hash cache).

    Guarantees a clean, fresh scrape on next playback without touching
    user watchlist, show/episode metadata, or account databases.
    """
    _bump_mem_generation()
    _init_cache_table()
    with SQL(control.cacheFile) as cur:
        # 1. Purge season pack torrent listings and last played sources
        cur.execute("DELETE FROM cache WHERE key LIKE 'season_pack_%'")
        cur.execute("DELETE FROM cache WHERE key LIKE 'episode_sources_%'")
        cur.execute("DELETE FROM cache WHERE key LIKE 'last_played_%'")

        # 2. Purge cached scraper results for all providers (torrents, embeds, hosters)
        provider_tokens = [
            'nyaa', 'animetosho', 'nekobt', 'torrentio', 'bitsearch', 'piratebay', 'easynews',
            'animepahe', 'animix', 'aniwave', 'hianime', 'animekai',
            'anikoto', 'watchnixtoons2', 'gogoanime', 'kaido', 'kissanime',
            'tokyotosho'
        ]
        for token in provider_tokens:
            cur.execute("DELETE FROM cache WHERE key LIKE ?", (f'%{token}%',))

        # 3. Purge generic get_sources function hashes
        cur.execute("DELETE FROM cache WHERE key LIKE '%get_sources%'")
        cur.connection.commit()

    # 4. Clear debrid hash availability cache (so hashes are re-checked fresh)
    try:
        from resources.lib.debrid import debrid_cache
        debrid_cache.clear_debrid_cache()
    except Exception as e:
        control.log(f"Error clearing debrid hash cache: {e}", 'warning')

    # 5. Reset scraper circuit breaker so any temporarily tripped scrapers can retry
    try:
        from resources.lib.pages import circuit_breaker
        circuit_breaker.reset()
    except Exception as e:
        control.log(f"Error resetting scraper circuit breaker: {e}", 'debug')

    # 6. Reset last played source setting
    control.setSetting('last_played_source', str(None))

    control.notify(
        f'{control.ADDON_NAME}: Provider Cache',
        'Torrents, embeds & debrid cache cleared for clean rescan.',
        time=4000, sound=False
    )


# Alias for compatibility with settings.xml action
cache_clear_scrapers = cache_clear_providers


def cache_clear_metadata():
    """Purge metadata provider caches (AniList, MAL, Kitsu, Simkl, MDBList, TVDB, AniSkip)."""
    _bump_mem_generation()
    _init_cache_table()
    with SQL(control.cacheFile) as cur:
        metadata_tokens = [
            'anilist', 'myanimelist', 'mal', 'kitsu', 'simkl', 'mdblist',
            'tvdb', 'aniskip', 'animeskip', 'introdb', 'jikan', 'anidb', 'anizip', 'fanart',
            'get_base_res', 'get_anime_init', 'get_reviews', 'get_media'
        ]
        for token in metadata_tokens:
            cur.execute("DELETE FROM cache WHERE key LIKE ?", (f'%{token}%',))
        cur.connection.commit()

    control.notify(
        f'{control.ADDON_NAME}: Metadata Cache',
        'Metadata cache successfully cleared.',
        time=4000, sound=False
    )


def prune_expired_cache(max_age_days=30):
    """Purge stale cache.db entries older than max_age_days to bound disk growth."""
    _init_cache_table()
    cutoff = int(time.time()) - (max_age_days * 86400)
    deleted = 0
    with SQL(control.cacheFile) as cur:
        cur.execute('DELETE FROM cache WHERE date < ?', (cutoff,))
        deleted = cur.rowcount
        cur.connection.commit()
    if deleted > 0:
        control.log(f"Database: Pruned {deleted} stale cache entries older than {max_age_days} days", level='info')
    return deleted


def checkpoint_databases(truncate=True):
    """Run PRAGMA wal_checkpoint(TRUNCATE|PASSIVE) across all databases.

    Flushes the SQLite write-ahead log to disk and (when truncate=True) truncates
    the .db-wal file to 0 bytes and runs PRAGMA optimize. When truncate=False
    (shutdown or periodic passive checkpoint), skips PRAGMA optimize and caps
    busy_timeout to 250ms so service.py teardown never exceeds CPythonInvoker's 5s limit.
    """
    db_paths = [
        getattr(control, 'cacheFile', None),
        getattr(control, 'malSyncDB', None),
        getattr(control, 'searchHistoryDB', None),
    ]
    mode = "TRUNCATE" if truncate else "PASSIVE"
    for path in db_paths:
        if path and os.path.exists(path):
            try:
                with SQL(path) as cur:
                    if not truncate:
                        cur.execute("PRAGMA busy_timeout = 250")
                    cur.execute(f"PRAGMA wal_checkpoint({mode})")
                    if truncate:
                        cur.execute("PRAGMA optimize")
            except Exception as e:
                control.log(f"Failed to checkpoint {path}: {e}", 'warning')


# ═══════════════════════════════════════════════════════════════════════════
#  Show Operations
# ═══════════════════════════════════════════════════════════════════════════

_SYNC_TABLE_DDLS = {
    'shows': (
        'CREATE TABLE IF NOT EXISTS shows ('
        'mal_id INTEGER PRIMARY KEY, '
        'anilist_id INTEGER, '
        'simkl_id INTEGER, '
        'kitsu_id INTEGER, '
        'kodi_meta BLOB NOT NULL, '
        'anime_schedule_route TEXT NOT NULL, '
        'UNIQUE(mal_id))'
    ),
    'shows_meta': (
        'CREATE TABLE IF NOT EXISTS shows_meta ('
        'mal_id INTEGER PRIMARY KEY, '
        'meta_ids BLOB, '
        'art BLOB, '
        'UNIQUE(mal_id))'
    ),
    'episodes': (
        'CREATE TABLE IF NOT EXISTS episodes ('
        'mal_id INTEGER NOT NULL, '
        'season INTEGER NOT NULL, '
        'kodi_meta BLOB NOT NULL, '
        'last_updated TEXT NOT NULL, '
        'number INTEGER NOT NULL, '
        'filler TEXT, '
        'anidb_ep_id INTEGER, '
        'FOREIGN KEY(mal_id) REFERENCES shows(mal_id) '
        'ON DELETE CASCADE)'
    ),
    'show_data': (
        'CREATE TABLE IF NOT EXISTS show_data ('
        'mal_id INTEGER PRIMARY KEY, '
        'data BLOB NOT NULL, '
        'last_updated TEXT NOT NULL, '
        'UNIQUE(mal_id))'
    ),
    'watchlist_cache': (
        'CREATE TABLE IF NOT EXISTS watchlist_cache ('
        'id INTEGER PRIMARY KEY AUTOINCREMENT, '
        'service TEXT NOT NULL, '
        'status TEXT NOT NULL, '
        'mal_id INTEGER, '
        'item_order INTEGER NOT NULL, '
        'data BLOB NOT NULL, '
        'last_updated INTEGER NOT NULL, '
        'UNIQUE(service, status, item_order))'
    ),
    'watchlist_activity': (
        'CREATE TABLE IF NOT EXISTS watchlist_activity ('
        'service TEXT PRIMARY KEY, '
        'activity_timestamp TEXT NOT NULL, '
        'last_checked INTEGER NOT NULL)'
    ),
    'anilist_enrichment': (
        'CREATE TABLE IF NOT EXISTS anilist_enrichment ('
        'mal_id INTEGER PRIMARY KEY, '
        'data BLOB NOT NULL, '
        'last_updated INTEGER NOT NULL)'
    ),
}


def _ensure_sync_table(table_name):
    ddl = _SYNC_TABLE_DDLS.get(table_name)
    if ddl and getattr(control, 'malSyncDB', None):
        _ensure_table(control.malSyncDB, table_name, ddl)


def get_show(mal_id):
    _ensure_sync_table('shows')
    with SQL(control.malSyncDB) as cur:
        cur.execute('SELECT * FROM shows WHERE mal_id=?', (mal_id,))
        return cur.fetchone()


def update_show(mal_id, kodi_meta, anime_schedule_route=''):
    _ensure_sync_table('shows')
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            'INSERT INTO shows (mal_id, kodi_meta, anime_schedule_route) VALUES (?, ?, ?) '
            'ON CONFLICT(mal_id) DO UPDATE SET kodi_meta=excluded.kodi_meta, anime_schedule_route=excluded.anime_schedule_route',
            (mal_id, kodi_meta, anime_schedule_route))
        cur.connection.commit()


def get_show_meta(mal_id):
    _ensure_sync_table('shows_meta')
    with SQL(control.malSyncDB) as cur:
        cur.execute('SELECT * FROM shows_meta WHERE mal_id=?', (mal_id,))
        return cur.fetchone()


_VALID_SYNC_TABLES = frozenset({'shows', 'episodes', 'shows_meta', 'show_data'})
_IDENTIFIER_RE = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')


def _validate_identifier(name):
    if not isinstance(name, str) or not _IDENTIFIER_RE.match(name):
        raise ValueError(f"Invalid SQL identifier: {name!r}")
    return name


def update_show_meta(mal_id, meta_ids, art):
    _ensure_sync_table('shows_meta')
    with SQL(control.malSyncDB) as cur:
        cur.execute('PRAGMA foreign_keys=OFF')
        cur.execute(
            'REPLACE INTO shows_meta (mal_id, meta_ids, art) VALUES (?, ?, ?)',
            (mal_id, dumps(meta_ids), dumps(art)))
        cur.execute('PRAGMA foreign_keys=ON')
        cur.connection.commit()


def update_kodi_meta(mal_id, kodi_meta):
    _ensure_sync_table('shows')
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            'UPDATE shows SET kodi_meta=? WHERE mal_id=?',
            (dumps(kodi_meta), mal_id))
        cur.connection.commit()


def add_mapping_id(mal_id, column, value):
    _validate_identifier(column)
    _ensure_sync_table('shows')
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            f'UPDATE shows SET {column}=? WHERE mal_id=?', (value, mal_id))
        cur.connection.commit()


def get_show_data(mal_id):
    _ensure_sync_table('show_data')
    with SQL(control.malSyncDB) as cur:
        cur.execute('SELECT * FROM show_data WHERE mal_id=?', (mal_id,))
        return cur.fetchone()


def update_show_data(mal_id, data, last_updated=''):
    _ensure_sync_table('show_data')
    with SQL(control.malSyncDB) as cur:
        cur.execute('PRAGMA foreign_keys=OFF')
        cur.execute(
            'REPLACE INTO show_data '
            '(mal_id, data, last_updated) VALUES (?, ?, ?)',
            (mal_id, dumps(data), last_updated))
        cur.execute('PRAGMA foreign_keys=ON')
        cur.connection.commit()


# ═══════════════════════════════════════════════════════════════════════════
#  Episode Operations
# ═══════════════════════════════════════════════════════════════════════════

def get_episode(mal_id, episode=None):
    _ensure_sync_table('episodes')
    with SQL(control.malSyncDB) as cur:
        if episode:
            cur.execute(
                'SELECT * FROM episodes WHERE mal_id=? AND number=?',
                (mal_id, episode))
        else:
            cur.execute(
                'SELECT * FROM episodes WHERE mal_id=?', (mal_id,))
        return cur.fetchone()


def get_episode_list(mal_id):
    _ensure_sync_table('episodes')
    with SQL(control.malSyncDB) as cur:
        cur.execute('SELECT * FROM episodes WHERE mal_id=?', (mal_id,))
        return cur.fetchall()


def update_episode(mal_id, season, number, update_time, kodi_meta,
                   filler='', anidb_ep_id=''):
    _ensure_sync_table('episodes')
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            'REPLACE INTO episodes '
            '(mal_id, season, kodi_meta, last_updated, number, filler, anidb_ep_id) '
            'VALUES (?, ?, ?, ?, ?, ?, ?)',
            (mal_id, season, kodi_meta, update_time, number, filler, anidb_ep_id))
        cur.connection.commit()


def update_show_season(mal_id, season):
    _ensure_sync_table('episodes')
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            'UPDATE OR REPLACE episodes SET season=? WHERE mal_id=? AND season!=?',
            (season, mal_id, season))
        cur.connection.commit()


def update_episode_column(mal_id, episode, column, value):
    _validate_identifier(column)
    _ensure_sync_table('episodes')
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            f'UPDATE episodes SET {column}=? WHERE mal_id=? AND number=?',
            (value, mal_id, episode))
        cur.connection.commit()


def update_episode_batch(episode_batch):
    """Batch insert/replace episodes in a single transaction using executemany."""
    if not episode_batch:
        return
    _ensure_sync_table('episodes')
    with SQL(control.malSyncDB) as cur:
        cur.executemany(
            'REPLACE INTO episodes '
            '(mal_id, season, kodi_meta, last_updated, number, filler, anidb_ep_id) '
            'VALUES (?, ?, ?, ?, ?, ?, ?)',
            episode_batch)
        cur.connection.commit()


# ═══════════════════════════════════════════════════════════════════════════
#  Mapping & Info Lookups
# ═══════════════════════════════════════════════════════════════════════════

def get_mappings(anime_id, send_id):
    if not anime_id or not send_id:
        return {}
    try:
        _validate_identifier(send_id)
    except Exception:
        return {}
    if getattr(control, 'mappingDB', None) and os.path.exists(control.mappingDB):
        try:
            with SQL(control.mappingDB, is_readonly=True) as cur:
                cur.execute(f'SELECT * FROM anime WHERE {send_id}=?', (anime_id,))
                rows = cur.fetchall()
                if rows:
                    return rows[0]
        except Exception:
            pass
    meta_path = getattr(control, 'metadataDB', None)
    if meta_path and os.path.exists(meta_path):
        try:
            with SQL(meta_path, is_readonly=True) as mcur:
                tables = _mapping_tables(mcur)
                if 'external_ids' in tables:
                    ecols = {
                        r.get('name')
                        for r in (mcur.execute("PRAGMA table_info(external_ids)").fetchall() or [])
                        if r.get('name')
                    }
                    if send_id in ecols:
                        erow = mcur.execute(f'SELECT * FROM external_ids WHERE {send_id}=?', (anime_id,)).fetchone()
                        if erow:
                            out = dict(erow)
                            if 'anime_metadata' in tables and out.get('mal_id'):
                                mrow = mcur.execute(
                                    'SELECT * FROM anime_metadata WHERE mal_id=?', (out['mal_id'],)
                                ).fetchone()
                                if mrow:
                                    for k, v in mrow.items():
                                        if k not in out and v is not None:
                                            out[k] = v
                            out.setdefault('_mapping_source', 'anime_metadata.db')
                            return out
        except Exception:
            pass
    return {}


def get_unique_ids(anime_id, send_id):
    if not anime_id or not send_id:
        return {}
    if not getattr(control, 'mappingDB', None) or not os.path.exists(control.mappingDB):
        return {}
    try:
        _validate_identifier(send_id)
        with SQL(control.mappingDB, is_readonly=True) as cur:
            acols = _mapping_anime_columns(cur)
            slug_col = ', trakt_slug' if 'trakt_slug' in acols else ''
            cur.execute(
                f'SELECT mal_id, mal_dub_id, anilist_id, kitsu_id, anidb_id, '
                f'simkl_id, thetvdb_id, themoviedb_id, imdb_id, trakt_id{slug_col} '
                f'FROM anime WHERE {send_id}=?', (anime_id,))
            row = cur.fetchone()
            if not row:
                return {}
            raw_uids = {
                'mal_id':     row.get('mal_id'),
                'mal':        row.get('mal_id'),
                'mal_dub_id': row.get('mal_dub_id'),
                'anilist_id': row.get('anilist_id'),
                'kitsu_id':   row.get('kitsu_id'),
                'anidb':      row.get('anidb_id'),
                'simkl':      row.get('simkl_id'),
                'tvdb':       row.get('thetvdb_id'),
                'tmdb':       row.get('themoviedb_id'),
                'imdb':       row.get('imdb_id'),
                'trakt':      row.get('trakt_id'),
                'trakt_slug': row.get('trakt_slug'),
            }
            if 'schedule_ids' in _mapping_tables(cur) and row.get('mal_id'):
                srow = cur.execute('SELECT * FROM schedule_ids WHERE mal_id=?', (row['mal_id'],)).fetchone()
                if srow:
                    for sk, uk in (
                        ('livechart_id', 'livechart'),
                        ('anisearch_id', 'anisearch'),
                        ('anime_planet_id', 'anime_planet'),
                        ('animenewsnetwork_id', 'ann'),
                    ):
                        if srow.get(sk) is not None:
                            raw_uids[uk] = srow[sk]
            return {
                k: v for k, v in raw_uids.items()
                if v is not None and str(v).strip() not in ('', 'None', 'null')
            }
    except Exception:
        pass
    return {}


def get_mal_ids(anime_id, send_id):
    if not anime_id or not send_id:
        return []
    if not getattr(control, 'mappingDB', None) or not os.path.exists(control.mappingDB):
        return []
    try:
        _validate_identifier(send_id)
        with SQL(control.mappingDB, is_readonly=True) as cur:
            cur.execute(
                f'SELECT * FROM anime WHERE {send_id}=?', (anime_id,))
            return cur.fetchall() or []
    except Exception:
        pass
    return []


def get_tvdb_rules(mal_id):
    """Fetch optional split-cour / absolute episode rules from mappings.db tvdb_rules table."""
    if not mal_id:
        return []
    if not getattr(control, 'mappingDB', None) or not os.path.exists(control.mappingDB):
        return []
    rows = []
    try:
        with SQL(control.mappingDB, is_readonly=True) as cur:
            has_tbl = cur.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='tvdb_rules'"
            ).fetchone()
            if not has_tbl:
                return []
            cur.execute(
                'SELECT * FROM tvdb_rules WHERE mal_id=? ORDER BY season, range_start',
                (int(mal_id),),
            )
            rows = cur.fetchall() or []
    except Exception:
        return []
    return rows


def get_mappings_metadata():
    """Return row count, tvdb_rules, aliases, franchise links, schedule IDs, and build_meta."""
    info = {
        'row_count': 0,
        'rule_count': 0,
        'alias_count': 0,
        'franchise_link_count': 0,
        'schedule_id_count': 0,
        'filler_range_count': 0,
        'last_updated': 0,
        'schema_version': '',
        'built_at_utc': '',
    }
    if not getattr(control, 'mappingDB', None) or not os.path.exists(control.mappingDB):
        return info
    try:
        with SQL(control.mappingDB, is_readonly=True) as cur:
            tables = {
                r.get('name')
                for r in (cur.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall() or [])
                if r.get('name')
            }
            for tbl, out_key in (
                ('anime', 'row_count'),
                ('tvdb_rules', 'rule_count'),
                ('anime_aliases', 'alias_count'),
                ('franchise_links', 'franchise_link_count'),
                ('schedule_ids', 'schedule_id_count'),
                ('filler_ranges', 'filler_range_count'),
            ):
                if tbl in tables:
                    row = cur.execute(f'SELECT COUNT(*) AS cnt FROM {tbl}').fetchone()
                    if row:
                        info[out_key] = int(row.get('cnt') or 0)
            if 'activities' in tables:
                act = cur.execute('SELECT last_updated FROM activities WHERE sync_id=1').fetchone()
                if act and str(act.get('last_updated') or '').isdigit():
                    info['last_updated'] = int(act['last_updated'])
            if 'build_meta' in tables:
                for mrow in cur.execute('SELECT key, value FROM build_meta').fetchall() or []:
                    k = mrow.get('key')
                    if k in ('schema_version', 'built_at_utc'):
                        info[k] = str(mrow.get('value') or '')
    except Exception:
        pass
    return info


def get_metadata_db_info():
    """Return row_count, alias_count, external_id_count, synopsis_count, and build_meta for anime_metadata.db."""
    info = {
        'row_count': 0,
        'alias_count': 0,
        'external_id_count': 0,
        'synopsis_count': 0,
        'schema_version': '',
        'built_at_utc': '',
    }
    meta_path = getattr(control, 'metadataDB', None)
    if not meta_path or not os.path.exists(meta_path):
        return info
    try:
        with SQL(meta_path, is_readonly=True) as cur:
            tables = _mapping_tables(cur)
            for tbl, out_key in (
                ('anime_metadata', 'row_count'),
                ('anime_aliases', 'alias_count'),
                ('external_ids', 'external_id_count'),
            ):
                if tbl in tables:
                    row = cur.execute(f'SELECT COUNT(*) AS cnt FROM {tbl}').fetchone()
                    if row:
                        info[out_key] = int(row.get('cnt') or 0)
            if 'build_meta' in tables:
                for mrow in cur.execute('SELECT key, value FROM build_meta').fetchall() or []:
                    k = mrow.get('key')
                    if k == 'synopsis_count':
                        info['synopsis_count'] = int(mrow.get('value') or 0)
                    elif k in ('schema_version', 'built_at_utc'):
                        info[k] = str(mrow.get('value') or '')
    except Exception:
        pass
    return info


def get_offline_anime_metadata(mal_id):
    """Fetch rich correlated metadata + external IDs for *mal_id* from anime_metadata.db (with mappings.db fallback)."""
    mid = _coerce_pos_int(mal_id)
    if not mid:
        return {}
    meta_path = getattr(control, 'metadataDB', None)
    if meta_path and os.path.exists(meta_path):
        try:
            with SQL(meta_path, is_readonly=True) as cur:
                tables = _mapping_tables(cur)
                if 'anime_metadata' in tables:
                    row = cur.execute('SELECT * FROM anime_metadata WHERE mal_id=?', (mid,)).fetchone()
                    if row:
                        out = dict(row)
                        if 'external_ids' in tables:
                            erow = cur.execute('SELECT * FROM external_ids WHERE mal_id=?', (mid,)).fetchone()
                            if erow:
                                for k, v in erow.items():
                                    if k not in out and v is not None:
                                        out[k] = v
                        return out
        except Exception:
            pass
    return get_mappings(mid, 'mal_id') or {}


def enrich_rows_from_metadata_db(rows):
    """Batch-enrich mappings.db anime rows with synopsis, age_rating, banner, trailer, native title, dub_status."""
    if not rows:
        return rows
    meta_path = getattr(control, 'metadataDB', None)
    if not meta_path or not os.path.exists(meta_path):
        return rows
    mids = sorted({_coerce_pos_int(r.get('mal_id')) for r in rows if _coerce_pos_int(r.get('mal_id'))})
    if not mids:
        return rows
    try:
        with SQL(meta_path, is_readonly=True) as cur:
            tables = _mapping_tables(cur)
            if 'anime_metadata' not in tables:
                return rows
            acols = {
                r.get('name')
                for r in (cur.execute("PRAGMA table_info(anime_metadata)").fetchall() or [])
                if r.get('name')
            }
            want_cols = [
                c for c in (
                    'title_native', 'end_date', 'synopsis', 'age_rating',
                    'banner_image', 'trailer_yt_id', 'country_of_origin', 'dub_status',
                )
                if c in acols
            ]
            if not want_cols:
                return rows
            sel_sql = ', '.join(want_cols)
            by_mid = {}
            for i in range(0, len(mids), 200):
                chunk = mids[i:i + 200]
                ph = ','.join('?' for _ in chunk)
                for mrow in cur.execute(
                    f'SELECT mal_id, {sel_sql} FROM anime_metadata WHERE mal_id IN ({ph})',
                    tuple(chunk),
                ).fetchall() or []:
                    by_mid[int(mrow['mal_id'])] = mrow
            for r in rows:
                mid = _coerce_pos_int(r.get('mal_id'))
                extra = by_mid.get(mid)
                if extra:
                    for c in want_cols:
                        if extra.get(c) is not None and not r.get(c):
                            r[c] = extra[c]
    except Exception:
        pass
    return rows


def _mapping_tables(cur):
    return {
        r.get('name')
        for r in (cur.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall() or [])
        if r.get('name')
    }


def _mapping_anime_columns(cur):
    return {
        r.get('name')
        for r in (cur.execute("PRAGMA table_info(anime)").fetchall() or [])
        if r.get('name')
    }


def get_mapping_aliases(mal_id, limit=12):
    """Return deduplicated alternate titles for *mal_id* from metadataDB / mappings.db."""
    mid = _coerce_pos_int(mal_id)
    has_map = bool(getattr(control, 'mappingDB', None) and os.path.exists(control.mappingDB))
    has_meta = bool(getattr(control, 'metadataDB', None) and os.path.exists(control.metadataDB))
    if not mid or (not has_map and not has_meta):
        return []
    aliases = []
    seen = set()

    def _add(val):
        s = str(val or '').strip()
        if s and s.lower() not in seen:
            seen.add(s.lower())
            aliases.append(s)

    try:
        meta_path = getattr(control, 'metadataDB', None)
        if meta_path and os.path.exists(meta_path):
            with SQL(meta_path, is_readonly=True) as mcur:
                mtables = {
                    r.get('name')
                    for r in (mcur.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall() or [])
                    if r.get('name')
                }
                if 'anime_metadata' in mtables:
                    mrow = mcur.execute('SELECT mal_title, title_english FROM anime_metadata WHERE mal_id=?', (mid,)).fetchone()
                    if mrow:
                        _add(mrow.get('title_english'))
                        _add(mrow.get('mal_title'))
                if 'anime_aliases' in mtables:
                    mrows = mcur.execute(
                        'SELECT alias FROM anime_aliases WHERE mal_id=? ORDER BY LENGTH(alias), alias LIMIT ?',
                        (mid, int(limit)),
                    ).fetchall() or []
                    for r in mrows:
                        _add(r.get('alias'))
        if len(aliases) >= limit or not has_map:
            return aliases[:limit]
        with SQL(control.mappingDB, is_readonly=True) as cur:
            tables = _mapping_tables(cur)
            if 'anime' in tables:
                acols = _mapping_anime_columns(cur)
                if 'title_english' in acols:
                    row = cur.execute('SELECT mal_title, title_english FROM anime WHERE mal_id=?', (mid,)).fetchone()
                    if row:
                        _add(row.get('title_english'))
                        _add(row.get('mal_title'))
                else:
                    row = cur.execute('SELECT mal_title FROM anime WHERE mal_id=?', (mid,)).fetchone()
                    if row:
                        _add(row.get('mal_title'))
            if 'anime_aliases' in tables:
                rows = cur.execute(
                    'SELECT title FROM anime_aliases WHERE mal_id=? ORDER BY LENGTH(title), title LIMIT ?',
                    (mid, int(limit)),
                ).fetchall() or []
                for r in rows:
                    _add(r.get('title'))
    except Exception:
        pass
    return aliases[:limit]


_MAPPING_FMT_MAP = {
    'tv': 'TV', 'TV': 'TV', 'TV_SHOW': 'TV',
    'movie': 'MOVIE', 'MOVIE': 'MOVIE',
    'ova': 'OVA', 'OVA': 'OVA',
    'ona': 'ONA', 'ONA': 'ONA',
    'special': 'SPECIAL', 'SPECIAL': 'SPECIAL', 'tv_special': 'SPECIAL', 'TV_SHORT': 'TV',
    'music': 'SPECIAL', 'MUSIC': 'SPECIAL',
}
_MAPPING_SEASON_ORDER = ('WINTER', 'SPRING', 'SUMMER', 'FALL')


def _normalize_mapping_format(media_format):
    return _MAPPING_FMT_MAP.get(str(media_format or '').strip(), '')


def _mapping_select_columns(cur):
    acols = _mapping_anime_columns(cur)
    extra_cols = [
        f'a.{c}'
        for c in ('year', 'anime_season', 'title_english', 'genres', 'studios', 'start_date', 'trakt_slug')
        if c in acols
    ]
    cols = (
        'a.mal_id, a.mal_dub_id, a.anilist_id, a.mal_title, a.mal_picture, '
        'a.score, a.status, a.anime_media_type, a.anime_media_episodes, '
        'a.duration, a.thetvdb_id, a.themoviedb_id'
        + (', ' + ', '.join(extra_cols) if extra_cols else '')
    )
    return cols, acols


def get_mapping_years(limit=75):
    """Return [{'year': int, 'count': int}, ...] descending from offline mappings.db."""
    if not getattr(control, 'mappingDB', None) or not os.path.exists(control.mappingDB):
        return []
    import datetime
    max_year = datetime.date.today().year + 1
    try:
        with SQL(control.mappingDB, is_readonly=True) as cur:
            if 'anime' not in _mapping_tables(cur):
                return []
            if 'year' not in _mapping_anime_columns(cur):
                return []
            rows = cur.execute(
                'SELECT year, COUNT(*) AS cnt FROM anime '
                'WHERE year IS NOT NULL AND year BETWEEN 1950 AND ? '
                'GROUP BY year ORDER BY year DESC LIMIT ?',
                (int(max_year), int(limit)),
            ).fetchall() or []
            return [{'year': int(r['year']), 'count': int(r['cnt'] or 0)} for r in rows if r.get('year')]
    except Exception:
        return []


_MAPPING_FMT_LABELS = (
    ('tv', 'TV Shows', ('TV', 'TV_SHORT')),
    ('movie', 'Movies', ('MOVIE',)),
    ('ova', 'OVAs', ('OVA',)),
    ('ona', 'ONAs', ('ONA',)),
    ('special', 'Specials', ('SPECIAL',)),
)


def get_mapping_season_counts(year, media_format=''):
    """Return {'total': int, 'all_total': int, 'seasons': [...], 'formats': [...]} for *year*."""
    yr = _coerce_pos_int(year)
    empty = {'total': 0, 'all_total': 0, 'seasons': [], 'formats': []}
    if not yr or not getattr(control, 'mappingDB', None) or not os.path.exists(control.mappingDB):
        return empty
    target_fmt = _normalize_mapping_format(media_format)
    try:
        with SQL(control.mappingDB, is_readonly=True) as cur:
            if 'anime' not in _mapping_tables(cur):
                return empty
            acols = _mapping_anime_columns(cur)
            if 'year' not in acols:
                return empty
            all_row = cur.execute('SELECT COUNT(*) AS cnt FROM anime WHERE year=?', (yr,)).fetchone()
            all_total = int((all_row or {}).get('cnt') or 0)
            frows = cur.execute(
                'SELECT UPPER(COALESCE(anime_media_type, "")) AS fmt, COUNT(*) AS cnt '
                'FROM anime WHERE year=? GROUP BY UPPER(COALESCE(anime_media_type, ""))',
                (yr,),
            ).fetchall() or []
            fmt_counts = {str(r.get('fmt') or ''): int(r.get('cnt') or 0) for r in frows}
            formats = []
            for fkey, flabel, db_types in _MAPPING_FMT_LABELS:
                fcnt = sum(fmt_counts.get(dt, 0) for dt in db_types)
                if fcnt > 0:
                    formats.append((fkey, flabel, fcnt))

            if target_fmt:
                tot_row = cur.execute(
                    'SELECT COUNT(*) AS cnt FROM anime WHERE year=? AND anime_media_type=?',
                    (yr, target_fmt),
                ).fetchone()
                total = int((tot_row or {}).get('cnt') or 0)
            else:
                total = all_total

            seasons = []
            if 'anime_season' in acols:
                if target_fmt:
                    srows = cur.execute(
                        'SELECT UPPER(anime_season) AS s, COUNT(*) AS cnt FROM anime '
                        'WHERE year=? AND anime_media_type=? AND anime_season IS NOT NULL '
                        'GROUP BY UPPER(anime_season)',
                        (yr, target_fmt),
                    ).fetchall() or []
                else:
                    srows = cur.execute(
                        'SELECT UPPER(anime_season) AS s, COUNT(*) AS cnt FROM anime '
                        'WHERE year=? AND anime_season IS NOT NULL GROUP BY UPPER(anime_season)',
                        (yr,),
                    ).fetchall() or []
                by_s = {str(r.get('s') or ''): int(r.get('cnt') or 0) for r in srows}
                seasons = [(s, by_s[s]) for s in _MAPPING_SEASON_ORDER if by_s.get(s, 0) > 0]
            return {'total': total, 'all_total': all_total, 'seasons': seasons, 'formats': formats}
    except Exception:
        return empty


def browse_mappings_by_year_season(year, anime_season='', media_format='', page=1, per_page=40):
    """Return (rows, has_next) for *year* + optional *anime_season* / *media_format* from mappings.db."""
    yr = _coerce_pos_int(year)
    if not yr or not getattr(control, 'mappingDB', None) or not os.path.exists(control.mappingDB):
        return [], False
    target_fmt = _normalize_mapping_format(media_format)
    seas_u = str(anime_season or '').strip().upper()
    if seas_u not in _MAPPING_SEASON_ORDER:
        seas_u = ''
    page_num = max(1, int(page or 1))
    limit_n = max(1, int(per_page or 40))
    offset_n = (page_num - 1) * limit_n

    try:
        with SQL(control.mappingDB, is_readonly=True) as cur:
            if 'anime' not in _mapping_tables(cur):
                return [], False
            cols, acols = _mapping_select_columns(cur)
            if 'year' not in acols:
                return [], False
            clauses = ['a.year = ?']
            params = [yr]
            if seas_u and 'anime_season' in acols:
                clauses.append('UPPER(a.anime_season) = ?')
                params.append(seas_u)
            if target_fmt:
                clauses.append('a.anime_media_type = ?')
                params.append(target_fmt)
            where_sql = ' AND '.join(clauses)
            params.extend([limit_n + 1, offset_n])
            rows = cur.execute(
                f'SELECT {cols} FROM anime a WHERE {where_sql} '
                f'ORDER BY COALESCE(a.score, 0) DESC, a.mal_id DESC LIMIT ? OFFSET ?',
                tuple(params),
            ).fetchall() or []
            out = [dict(r) for r in rows]
            has_next = len(out) > limit_n
            return enrich_rows_from_metadata_db(out[:limit_n]), has_next
    except Exception:
        return [], False


def search_mappings_by_title(query, limit=25, media_format=''):
    """Offline title + alias search across mappings.db using FTS5 (v2.6+) with LIKE fallback."""
    q = ' '.join(str(query or '').strip().split())
    if len(q) < 2 or not getattr(control, 'mappingDB', None) or not os.path.exists(control.mappingDB):
        return []
    target_fmt = _normalize_mapping_format(media_format)
    esc = q.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')
    prefix_pat = f"{esc}%"
    sub_pat = f"%{esc}%"
    q_low = q.lower()
    seen_ids = set()
    candidates = []

    try:
        with SQL(control.mappingDB, is_readonly=True) as cur:
            tables = _mapping_tables(cur)
            if 'anime' not in tables:
                return []
            cols, acols = _mapping_select_columns(cur)
            fmt_sql = " AND a.anime_media_type = ?" if target_fmt else ""

            def _run_fetch(sql, params):
                for row in (cur.execute(sql, params).fetchall() or []):
                    mid = row.get('mal_id')
                    if mid and mid not in seen_ids:
                        seen_ids.add(mid)
                        candidates.append(dict(row))

            if 'anime_fts' in tables:
                fts_tokens = [tok.replace('"', '') for tok in re.findall(r'[\w]+', q) if tok]
                if fts_tokens:
                    fts_expr = ' '.join(f'"{tok}"*' for tok in fts_tokens[:8])
                    p_fts = (fts_expr, target_fmt, int(limit)) if target_fmt else (fts_expr, int(limit))
                    try:
                        _run_fetch(
                            f"SELECT {cols} FROM anime_fts "
                            f"JOIN anime a ON a.mal_id = anime_fts.mal_id "
                            f"WHERE anime_fts MATCH ?{fmt_sql} "
                            f"ORDER BY COALESCE(a.score, 0) DESC LIMIT ?",
                            p_fts,
                        )
                    except Exception:
                        pass

            if len(candidates) < limit:
                p_pfx = (prefix_pat, target_fmt, int(limit)) if target_fmt else (prefix_pat, int(limit))
                _run_fetch(
                    f"SELECT {cols} FROM anime a WHERE a.mal_title LIKE ? ESCAPE '\\'{fmt_sql} "
                    f"ORDER BY COALESCE(a.score, 0) DESC LIMIT ?",
                    p_pfx,
                )
                if 'title_english' in acols and len(candidates) < limit:
                    _run_fetch(
                        f"SELECT {cols} FROM anime a WHERE a.title_english LIKE ? ESCAPE '\\'{fmt_sql} "
                        f"ORDER BY COALESCE(a.score, 0) DESC LIMIT ?",
                        p_pfx,
                    )
                if 'anime_aliases' in tables and len(candidates) < limit:
                    _run_fetch(
                        f"SELECT {cols} FROM anime_aliases al JOIN anime a ON a.mal_id = al.mal_id "
                        f"WHERE al.title LIKE ? ESCAPE '\\'{fmt_sql} "
                        f"ORDER BY COALESCE(a.score, 0) DESC LIMIT ?",
                        p_pfx,
                    )
            if len(candidates) < limit:
                p_sub = (sub_pat, target_fmt, int(limit)) if target_fmt else (sub_pat, int(limit))
                _run_fetch(
                    f"SELECT {cols} FROM anime a WHERE a.mal_title LIKE ? ESCAPE '\\'{fmt_sql} "
                    f"ORDER BY COALESCE(a.score, 0) DESC LIMIT ?",
                    p_sub,
                )
                if 'title_english' in acols and len(candidates) < limit:
                    _run_fetch(
                        f"SELECT {cols} FROM anime a WHERE a.title_english LIKE ? ESCAPE '\\'{fmt_sql} "
                        f"ORDER BY COALESCE(a.score, 0) DESC LIMIT ?",
                        p_sub,
                    )
                if 'anime_aliases' in tables and len(candidates) < limit:
                    _run_fetch(
                        f"SELECT {cols} FROM anime_aliases al JOIN anime a ON a.mal_id = al.mal_id "
                        f"WHERE al.title LIKE ? ESCAPE '\\'{fmt_sql} "
                        f"ORDER BY COALESCE(a.score, 0) DESC LIMIT ?",
                        p_sub,
                    )
    except Exception:
        return []

    if len(candidates) < limit:
        meta_path = getattr(control, 'metadataDB', None)
        if meta_path and os.path.exists(meta_path):
            try:
                fts_tokens = [tok.replace('"', '') for tok in re.findall(r'[\w]+', q) if tok]
                if fts_tokens:
                    fts_expr = ' '.join(f'"{tok}"*' for tok in fts_tokens[:8])
                    with SQL(meta_path, is_readonly=True) as mcur:
                        mtables = _mapping_tables(mcur)
                        if 'metadata_fts' in mtables and 'anime_metadata' in mtables:
                            m_fmt_sql = " AND a.anime_media_type = ?" if target_fmt else ""
                            m_params = (fts_expr, target_fmt, int(limit)) if target_fmt else (fts_expr, int(limit))
                            for row in (mcur.execute(
                                f"SELECT a.* FROM metadata_fts "
                                f"JOIN anime_metadata a ON a.mal_id = metadata_fts.rowid "
                                f"WHERE metadata_fts MATCH ?{m_fmt_sql} "
                                f"ORDER BY COALESCE(a.score, 0) DESC LIMIT ?",
                                m_params,
                            ).fetchall() or []):
                                mid = row.get('mal_id')
                                if mid and mid not in seen_ids:
                                    seen_ids.add(mid)
                                    candidates.append(dict(row))
            except Exception:
                pass

    def _rank(r):
        title_l = str(r.get('mal_title') or '').lower()
        eng_l = str(r.get('title_english') or '').lower()
        if title_l == q_low or (eng_l and eng_l == q_low):
            exact = 0
        elif title_l.startswith(q_low) or (eng_l and eng_l.startswith(q_low)):
            exact = 1
        else:
            exact = 2
        return (exact, -(float(r.get('score') or 0.0)), int(r.get('mal_id') or 0))

    candidates.sort(key=_rank)
    return enrich_rows_from_metadata_db(candidates[:limit])


_FRANCHISE_ORDER = {
    'PREQUEL': 0,
    'PARENT': 1,
    'SEQUEL': 2,
    'SIDE_STORY': 3,
    'SPIN_OFF': 4,
    'ALTERNATIVE': 5,
    'SUMMARY': 6,
    'RELATED': 7,
}


def get_franchise_entries(mal_id):
    """Return ordered related anime entries from franchise_links (with thetvdb_id sibling fallback)."""
    mid = _coerce_pos_int(mal_id)
    if not mid or not getattr(control, 'mappingDB', None) or not os.path.exists(control.mappingDB):
        return []
    entries = []
    try:
        with SQL(control.mappingDB, is_readonly=True) as cur:
            tables = _mapping_tables(cur)
            if 'anime' not in tables:
                return []
            acols = _mapping_anime_columns(cur)
            extra_a = ''.join(f', a.{c}' for c in ('year', 'anime_season') if c in acols)
            extra_bare = ''.join(f', {c}' for c in ('year', 'anime_season') if c in acols)
            if 'franchise_links' in tables:
                rows = cur.execute(
                    'SELECT fl.related_mal_id AS mal_id, fl.relation_type, fl.source, '
                    'a.mal_title, a.mal_picture, a.score, a.status, a.anime_media_type, '
                    'a.anime_media_episodes, a.duration, a.thetvdb_id, a.thetvdb_season, a.thetvdb_part'
                    f'{extra_a} '
                    'FROM franchise_links fl JOIN anime a ON a.mal_id = fl.related_mal_id '
                    'WHERE fl.mal_id=?',
                    (mid,),
                ).fetchall() or []
                entries = [dict(r) for r in rows]

            if not entries:
                self_row = cur.execute('SELECT thetvdb_id FROM anime WHERE mal_id=?', (mid,)).fetchone()
                tvdb_id = (self_row or {}).get('thetvdb_id')
                if tvdb_id:
                    sibs = cur.execute(
                        'SELECT mal_id, "RELATED" AS relation_type, "tvdb_sibling" AS source, '
                        'mal_title, mal_picture, score, status, anime_media_type, '
                        'anime_media_episodes, duration, thetvdb_id, thetvdb_season, thetvdb_part'
                        f'{extra_bare} '
                        'FROM anime WHERE thetvdb_id=? AND mal_id != ? '
                        'ORDER BY CASE WHEN typeof(thetvdb_season)="integer" THEN thetvdb_season ELSE 999 END, '
                        'COALESCE(thetvdb_part, 1), mal_id',
                        (tvdb_id, mid),
                    ).fetchall() or []
                    entries = [dict(r) for r in sibs]
    except Exception:
        return []

    entries.sort(
        key=lambda r: (
            _FRANCHISE_ORDER.get(str(r.get('relation_type') or 'RELATED').upper(), 9),
            int(r.get('mal_id') or 0),
        )
    )
    return enrich_rows_from_metadata_db(entries)


def get_franchise_watch_order(mal_id, max_hops=12):
    """Walk multi-hop PREQUEL/SEQUEL links offline to return chronological watch order including *mal_id*."""
    mid = _coerce_pos_int(mal_id)
    if not mid or not getattr(control, 'mappingDB', None) or not os.path.exists(control.mappingDB):
        return []
    try:
        with SQL(control.mappingDB, is_readonly=True) as cur:
            tables = _mapping_tables(cur)
            if 'anime' not in tables or 'franchise_links' not in tables:
                return []
            cols, _acols = _mapping_select_columns(cur)
            cur_id = mid
            seen_back = {cur_id}
            for _ in range(int(max_hops)):
                pre = cur.execute(
                    "SELECT related_mal_id FROM franchise_links "
                    "WHERE mal_id=? AND UPPER(relation_type)='PREQUEL' ORDER BY related_mal_id LIMIT 1",
                    (cur_id,),
                ).fetchone()
                nxt_pre = _coerce_pos_int((pre or {}).get('related_mal_id'))
                if not nxt_pre or nxt_pre in seen_back:
                    break
                seen_back.add(nxt_pre)
                cur_id = nxt_pre

            chain = []
            seen_fwd = set()
            while cur_id and cur_id not in seen_fwd and len(chain) < int(max_hops) * 2:
                seen_fwd.add(cur_id)
                row = cur.execute(f"SELECT {cols} FROM anime a WHERE a.mal_id=?", (cur_id,)).fetchone()
                if row:
                    chain.append(dict(row))
                seq = cur.execute(
                    "SELECT fl.related_mal_id FROM franchise_links fl "
                    "JOIN anime a ON a.mal_id = fl.related_mal_id "
                    "WHERE fl.mal_id=? AND UPPER(fl.relation_type)='SEQUEL' "
                    "ORDER BY CASE WHEN UPPER(COALESCE(a.anime_media_type,''))='TV' THEN 0 ELSE 1 END, fl.related_mal_id LIMIT 1",
                    (cur_id,),
                ).fetchone()
                cur_id = _coerce_pos_int((seq or {}).get('related_mal_id'))
            return chain
    except Exception:
        return []


def get_sequel_mal_id(mal_id):
    """Return direct released sequel entry dict for *mal_id* if known in mappings.db, else {}."""
    mid = _coerce_pos_int(mal_id)
    if not mid or not getattr(control, 'mappingDB', None) or not os.path.exists(control.mappingDB):
        return {}
    try:
        entries = get_franchise_entries(mid)
        tv_pref = {'TV': 0, 'ONA': 1, 'MOVIE': 2, 'OVA': 3, 'SPECIAL': 4}
        sequels = [
            e for e in entries
            if str(e.get('relation_type') or '').upper() == 'SEQUEL'
            and str(e.get('status') or '').upper() != 'UPCOMING'
            and _coerce_pos_int(e.get('mal_id')) not in (None, mid)
        ]
        if sequels:
            sequels.sort(
                key=lambda e: (
                    tv_pref.get(str(e.get('anime_media_type') or '').upper(), 5),
                    int(e.get('mal_id') or 0),
                )
            )
            return sequels[0]

        # Sibling fallback: next cour/season sharing thetvdb_id
        cur_row = get_mappings(mid, 'mal_id')
        tvdb_id = cur_row.get('thetvdb_id') if cur_row else None
        if tvdb_id and entries:
            c_season = cur_row.get('thetvdb_season')
            c_part = cur_row.get('thetvdb_part') or 1
            if isinstance(c_season, int) and c_season >= 1:
                next_cour = [
                    e for e in entries
                    if e.get('thetvdb_season') == c_season and (e.get('thetvdb_part') or 1) == c_part + 1
                    and str(e.get('status') or '').upper() != 'UPCOMING'
                ]
                if next_cour:
                    return next_cour[0]
                next_season = [
                    e for e in entries
                    if e.get('thetvdb_season') == c_season + 1
                    and str(e.get('status') or '').upper() != 'UPCOMING'
                ]
                if next_season:
                    return next_season[0]
    except Exception:
        pass
    return {}


def get_schedule_ids(mal_id):
    """Return schedule & external encyclopedia IDs from mappings.db schedule_ids or metadataDB."""
    mid = _coerce_pos_int(mal_id)
    if not mid:
        return {}
    if getattr(control, 'mappingDB', None) and os.path.exists(control.mappingDB):
        try:
            with SQL(control.mappingDB, is_readonly=True) as cur:
                if 'schedule_ids' in _mapping_tables(cur):
                    row = cur.execute('SELECT * FROM schedule_ids WHERE mal_id=?', (mid,)).fetchone()
                    if row:
                        return {k: v for k, v in row.items() if k != 'mal_id' and v is not None}
        except Exception:
            pass
    meta_path = getattr(control, 'metadataDB', None)
    if meta_path and os.path.exists(meta_path):
        try:
            with SQL(meta_path, is_readonly=True) as mcur:
                if 'external_ids' in _mapping_tables(mcur):
                    erow = mcur.execute('SELECT * FROM external_ids WHERE mal_id=?', (mid,)).fetchone()
                    if erow:
                        keys = (
                            'syobocal_tid', 'annict_id', 'livechart_id',
                            'anisearch_id', 'anime_planet_id', 'animenewsnetwork_id', 'animecountdown_id',
                        )
                        return {k: erow[k] for k in keys if k in erow and erow[k] is not None}
        except Exception:
            pass
    return {}


def get_mapping_filler_map(mal_id):
    """Return {ep_num: filler_type} for *mal_id* from mappings.db or metadataDB filler_ranges."""
    mid = _coerce_pos_int(mal_id)
    if not mid:
        return {}
    rows = []
    for db_path in (getattr(control, 'mappingDB', None), getattr(control, 'metadataDB', None)):
        if not db_path or not os.path.exists(db_path):
            continue
        try:
            with SQL(db_path, is_readonly=True) as cur:
                if 'filler_ranges' in _mapping_tables(cur):
                    rows = cur.execute(
                        'SELECT ep_start, ep_end, filler_type FROM filler_ranges WHERE mal_id=?',
                        (mid,),
                    ).fetchall() or []
                    if rows:
                        break
        except Exception:
            continue
    if not rows:
        return {}
    out = {}
    for row in rows:
        try:
            ep_s = int(row.get('ep_start') or 0)
            ep_e = int(row.get('ep_end') or 0)
        except (TypeError, ValueError):
            continue
        ftype = str(row.get('filler_type') or '').strip()
        if ep_s >= 1 and ep_e >= ep_s and ftype and (ep_e - ep_s) <= 5000:
            for ep in range(ep_s, ep_e + 1):
                out[ep] = ftype
    return out


def get_episode_offset_from_mappings(mal_id, episode=1):
    """Compute local split-cour / global episode offset using tvdb_rules and global_media_episodes."""
    mid = _coerce_pos_int(mal_id)
    if not mid:
        return 0
    try:
        ep_num = int(episode) if str(episode or '').isdigit() else 1
    except (ValueError, TypeError):
        ep_num = 1

    # 1. Explicit tvdb_rules offset (range_start - ep_start, with absolute_start fallback)
    for rl in get_tvdb_rules(mid):
        r_start = rl.get('range_start')
        r_end = rl.get('range_end')
        ep_start = rl.get('ep_start') or 1
        abs_start = rl.get('absolute_start')
        if r_start is None and abs_start is None:
            continue
        ep_start_i = int(ep_start)
        if r_start is not None:
            r_start_i = int(r_start)
            local_end = None if r_end is None else ep_start_i + max(0, int(r_end) - r_start_i)
            if ep_num >= ep_start_i and (local_end is None or ep_num <= local_end):
                off = r_start_i - ep_start_i
                if off != 0:
                    return off
        if abs_start is not None:
            abs_start_i = int(abs_start)
            if ep_num >= ep_start_i and abs_start_i > ep_start_i:
                return abs_start_i - ep_start_i

    # 2. Fallback: anime_media_episodes vs global_media_episodes span start diff
    mapping = get_mappings(mid, 'mal_id')
    if mapping:
        a_rng = str(mapping.get('anime_media_episodes') or '')
        g_rng = str(mapping.get('global_media_episodes') or '')
        a_start = int(a_rng.split('-', 1)[0].strip()) if '-' in a_rng and a_rng.split('-', 1)[0].strip().isdigit() else None
        g_start = int(g_rng.split('-', 1)[0].strip()) if '-' in g_rng and g_rng.split('-', 1)[0].strip().isdigit() else None
        if a_start is not None and g_start is not None and g_start > a_start:
            return g_start - a_start
    return 0


def _coerce_pos_int(val):
    if val is None or isinstance(val, bool):
        return None
    if isinstance(val, int):
        return val if val > 0 else None
    s = str(val).strip()
    return int(s) if s.isdigit() and int(s) > 0 else None


def resolve_mappings_with_fallback(
    mal_id,
    required_keys=('anidb_id', 'thetvdb_id', 'themoviedb_id'),
    require_all=True,
    fetch_remote=True,
):
    """Return mappings row for *mal_id*, healing missing IDs via metadataDB -> cache.db -> AniZip -> Simkl."""
    mid = _coerce_pos_int(mal_id)
    if not mid:
        return {}
    base = dict(get_mappings(mid, 'mal_id') or {})
    meta_extra = get_offline_anime_metadata(mid) if getattr(control, 'metadataDB', None) and os.path.exists(control.metadataDB) else {}
    if meta_extra:
        for mk, mv in meta_extra.items():
            if mv not in (None, '', 0) and base.get(mk) in (None, '', 0):
                base[mk] = mv
    if required_keys:
        satisfied = (
            all(base.get(k) not in (None, '', 0) for k in required_keys)
            if require_all
            else any(base.get(k) not in (None, '', 0) for k in required_keys)
        )
        if satisfied:
            base.setdefault('_mapping_source', 'mappings.db')
            return base

    cache_key = f"runtime_map:{mid}"
    cached_row = None
    try:
        cached_row = cache_get(cache_key)
    except Exception:
        cached_row = None

    overlay = None
    if cached_row:
        try:
            payload = control.loads_json(cached_row['value'], None)
            if isinstance(payload, dict) and 'data' in payload:
                ttl_hours = 168 if payload.get('hit') else 6
                if is_cache_valid(cached_row['date'], ttl_hours):
                    overlay = payload.get('data') or {}
        except Exception:
            overlay = None

    if overlay is None and fetch_remote:
        overlay = {}
        try:
            from resources.lib.ui import client
            resp = client.get('https://api.ani.zip/mappings', params={'mal_id': mid}, timeout=5)
            if resp and (getattr(resp, 'status_code', None) == 200 or getattr(resp, 'ok', False) is True):
                az = control.safe_json(resp, default={})
                m = az.get('mappings') or {}
                for src_k, dest_k in (
                    ('anilist_id', 'anilist_id'),
                    ('kitsu_id', 'kitsu_id'),
                    ('anidb_id', 'anidb_id'),
                    ('thetvdb_id', 'thetvdb_id'),
                    ('themoviedb_id', 'themoviedb_id'),
                ):
                    v = _coerce_pos_int(m.get(src_k))
                    if v:
                        overlay[dest_k] = v
                if m.get('imdb_id'):
                    overlay['imdb_id'] = str(m['imdb_id']).strip()
                if m.get('type'):
                    overlay['anime_media_type'] = str(m['type']).strip()
                ep1 = (az.get('episodes') or {}).get('1')
                if isinstance(ep1, dict) and ep1.get('seasonNumber') is not None:
                    s_val = _coerce_pos_int(ep1.get('seasonNumber'))
                    if s_val is not None:
                        overlay['thetvdb_season'] = s_val
        except Exception:
            pass

        if not overlay.get('anidb_id') or not overlay.get('thetvdb_id'):
            try:
                from resources.lib.indexers.simkl import SIMKLAPI
                sids = SIMKLAPI().get_mapping_ids_from_simkl(mid, 'mal') or {}
                for src_k, dest_k in (
                    ('simkl', 'simkl_id'),
                    ('simkl_id', 'simkl_id'),
                    ('anidb', 'anidb_id'),
                    ('anidb_id', 'anidb_id'),
                    ('tvdb', 'thetvdb_id'),
                    ('thetvdb_id', 'thetvdb_id'),
                    ('tmdb', 'themoviedb_id'),
                    ('themoviedb_id', 'themoviedb_id'),
                    ('imdb', 'imdb_id'),
                    ('imdb_id', 'imdb_id'),
                ):
                    if sids.get(src_k) and not overlay.get(dest_k):
                        overlay[dest_k] = _coerce_pos_int(sids[src_k]) if dest_k != 'imdb_id' else sids[src_k]
            except Exception:
                pass

        try:
            _cache_write(cache_key, json.dumps({'hit': bool(overlay), 'data': overlay}))
        except Exception:
            pass

    if overlay:
        merged = dict(base)
        merged['mal_id'] = mid
        added_any = False
        for k, v in overlay.items():
            if v not in (None, '', 0) and merged.get(k) in (None, '', 0):
                merged[k] = v
                added_any = True
        if added_any:
            merged['_mapping_source'] = 'mappings.db + live overlay' if base else 'live overlay (AniZip/Simkl)'
            return merged

    if base:
        base.setdefault('_mapping_source', 'mappings.db')
    return base


_BUILTIN_API_INFO = {
    'Simkl': {'api_name': 'Simkl', 'api_key': '', 'client_id': '59dfdc579d244e1edf6f89874d521d37a69a95a1abd349910cb056a1872ba2c8', 'client_secret': '', 'description': 'Simkl API'},
    'MyAnimeList': {'api_name': 'MyAnimeList', 'api_key': '', 'client_id': 'a8d85a4106b259b8c9470011ce2f76bc', 'client_secret': '', 'description': 'MyAnimeList API'},
    'Real-Debrid': {'api_name': 'Real-Debrid', 'api_key': '', 'client_id': 'X245A4XAIBGVM', 'client_secret': '', 'description': 'Real-Debrid API'},
    'Premiumize': {'api_name': 'Premiumize', 'api_key': '', 'client_id': '807831898', 'client_secret': '', 'description': 'Premiumize API'},
    'Debrid-Link': {'api_name': 'Debrid-Link', 'api_key': '', 'client_id': 'sdpBuYFQo6L53s3B4apluw', 'client_secret': '', 'description': 'Debrid-Link API'},
    'Fanart-TV': {'api_name': 'Fanart-TV', 'api_key': 'dfe6380e34f49f9b2b9518184922b49c', 'client_id': '', 'client_secret': '', 'description': 'Fanart-TV API'},
    'Anime-Skip': {'api_name': 'Anime-Skip', 'api_key': '', 'client_id': 'buT57NJMu4G65vxGJWdj4UXgnq65Agfi', 'client_secret': '', 'description': 'Anime-Skip API'},
    'AniDB': {'api_name': 'AniDB', 'api_key': '', 'client_id': 'otakukodi', 'client_secret': '', 'description': 'AniDB API'},
    'TMDB': {'api_name': 'TMDB', 'api_key': '6974ec27debf5cce1218136e2a36f64b', 'client_id': '', 'client_secret': '', 'description': 'The Movie Database API'},
    'Teamup': {'api_name': 'Teamup', 'api_key': '7d05c918d14d9a89347492f8916e3a76457de61dd3303e9a31aecb971d6c8149', 'client_id': '', 'client_secret': '', 'description': 'Teamup API'},
    'AnimeSchedule': {'api_name': 'AnimeSchedule', 'api_key': '', 'client_id': '2zuyXQUF6qxMqaEXZ6nP', 'client_secret': 'mSFcWD3lXURQXPAoKHKI5qpV42x6oq', 'description': 'AnimeSchedule API'},
    'MDBList': {'api_name': 'MDBList', 'api_key': '7zya5tee3ruf73cubnb85dsyr', 'client_id': '', 'client_secret': '', 'description': 'MDBList API'},
    'TVDB': {'api_name': 'TVDB', 'api_key': 'edae60dc-1b44-4bac-8db7-65c0aaf5258b', 'client_id': '', 'client_secret': '', 'description': 'TheTVDB API'},
    'Trakt': {'api_name': 'Trakt', 'api_key': '', 'client_id': 'e6a379effbda0b40f5ae06d39336b3c716c7fb86562327a0125f29959b5d5c79', 'client_secret': '0bf24cdc6a51673f23ce065738f9cd35d87196f129ea8836f6372a53fa5d5b76', 'description': 'Trakt API'}
}


def get_info(api_name):
    row = None
    try:
        if getattr(control, 'infoDB', None) and os.path.exists(control.infoDB):
            with SQL(control.infoDB, is_readonly=True) as cur:
                cur.execute('SELECT * FROM info WHERE api_name=?', (api_name,))
                row = cur.fetchone()
    except (dbapi2.DatabaseError, dbapi2.OperationalError) as e:
        control.log(f"get_info error for {api_name}: {e}", 'debug')
    if row and (row.get('client_id') or row.get('api_key')):
        return row
    fallback = _BUILTIN_API_INFO.get(api_name)
    if fallback:
        return dict(fallback)
    return row or {'api_name': api_name, 'client_id': '', 'client_secret': '', 'api_key': ''}


def remove_from_database(table, mal_id):
    if table not in _VALID_SYNC_TABLES:
        raise ValueError(f"Invalid sync table: {table!r}")
    _ensure_sync_table(table)
    with SQL(control.malSyncDB) as cur:
        cur.execute(f'DELETE FROM {table} WHERE mal_id=?', (mal_id,))
        cur.connection.commit()


# ═══════════════════════════════════════════════════════════════════════════
#  Watchlist Cache
# ═══════════════════════════════════════════════════════════════════════════

_WATCHLIST_SORT_COLUMNS = {
    'title': 'title_en COLLATE NOCASE',
    'title_en': 'title_en COLLATE NOCASE',
    'name': 'title_en COLLATE NOCASE',
    'title_romaji': 'title_romaji COLLATE NOCASE',
    'score': 'score',
    'episodes': 'total_episodes',
    'total_episodes': 'total_episodes',
    'watched': 'episodes_watched',
    'progress': 'episodes_watched',
    'episodes_watched': 'episodes_watched',
    'remaining': 'episodes_remaining',
    'episodes_remaining': 'episodes_remaining',
    'date': 'release_date',
    'release_date': 'release_date',
    'updated': 'updated_at',
    'updated_at': 'updated_at',
    'order': 'item_order',
    'item_order': 'item_order',
    'default': 'item_order'
}


def get_watchlist_cache(service, status, limit=None, offset=0, sort_by=None, order='asc'):
    """Cached watchlist items, optionally sorted and paginated."""
    order_clause = 'DESC' if str(order).upper() == 'DESC' else 'ASC'
    col = _WATCHLIST_SORT_COLUMNS.get(sort_by, 'item_order') if sort_by else 'item_order'

    query = (
        f'SELECT * FROM v_watchlist_items '
        f'WHERE service=? AND status=? '
        f'ORDER BY {col} {order_clause}, id ASC'
    )
    params = [service, status]
    if limit is not None and int(limit) > 0:
        query += ' LIMIT ? OFFSET ?'
        params.extend([int(limit), int(offset)])

    def _exec():
        _ensure_sync_table('watchlist_cache')
        with SQL(control.malSyncDB) as cur:
            cur.execute(query, tuple(params))
            return cur.fetchall()

    res = None
    try:
        res = _exec()
    except Exception:
        pass

    if res is None:
        # View might not exist yet on legacy DBs; build it and retry once
        try:
            from resources.lib.ui.database_sync import SyncDatabase
            SyncDatabase._build_watchlist_view()
            res = _exec()
        except Exception:
            res = None

    if res is None:
        fallback_query = 'SELECT * FROM watchlist_cache WHERE service=? AND status=? ORDER BY item_order ASC, id ASC'
        fparams = [service, status]
        if limit is not None and int(limit) > 0:
            fallback_query += ' LIMIT ? OFFSET ?'
            fparams.extend([int(limit), int(offset)])
        with SQL(control.malSyncDB) as cur:
            cur.execute(fallback_query, tuple(fparams))
            fres = cur.fetchall()
            return fres if fres is not None else []

    return res


def get_watchlist_cache_count(service, status):
    """Count of cached items for a service / status pair."""
    _ensure_sync_table('watchlist_cache')
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            'SELECT COUNT(*) as count FROM watchlist_cache '
            'WHERE service=? AND status=?', (service, status))
        row = cur.fetchone()
        return row['count'] if row else 0


def get_watchlist_cache_last_updated(service, status):
    """Oldest update timestamp for a service / status pair."""
    _ensure_sync_table('watchlist_cache')
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            'SELECT MIN(last_updated) as last_updated FROM watchlist_cache '
            'WHERE service=? AND status=?', (service, status))
        row = cur.fetchone()
        return row['last_updated'] if row else None


def save_watchlist_cache(service, status, items):
    """Replace all cache entries for a service / status pair."""
    from resources.lib.ui.database_sync import SyncDatabase
    SyncDatabase._build_watchlist_cache()
    now = int(time.time())
    rows = [
        (service, status, _extract_mal_id(service, item), idx, dumps(item), now)
        for idx, item in enumerate(items)
    ]
    with SQL(control.malSyncDB) as cur:
        cur.execute('BEGIN IMMEDIATE')
        cur.execute(
            'DELETE FROM watchlist_cache WHERE service=? AND status=?',
            (service, status))
        if rows:
            cur.executemany(
                'INSERT INTO watchlist_cache '
                '(service, status, mal_id, item_order, data, last_updated) '
                'VALUES (?, ?, ?, ?, ?, ?)',
                rows)
        cur.execute('COMMIT')


def _extract_mal_id(service, item):
    """Pull MAL ID from a watchlist item based on service structure."""
    extractors = {
        'simkl':   lambda i: i.get('show', {}).get('ids', {}).get('mal'),
        'kitsu':   lambda i: i.get('mal_id'),
        'mal':     lambda i: i.get('node', {}).get('id'),
        'anilist': lambda i: i.get('media', {}).get('idMal'),
    }
    fn = extractors.get(service)
    return fn(item) if fn else None


def clear_watchlist_cache(service=None, status=None):
    """Clear cache, optionally filtered by service and/or status."""
    _ensure_sync_table('watchlist_cache')
    with SQL(control.malSyncDB) as cur:
        if service and status:
            cur.execute(
                'DELETE FROM watchlist_cache WHERE service=? AND status=?',
                (service, status))
        elif service:
            cur.execute(
                'DELETE FROM watchlist_cache WHERE service=?', (service,))
        else:
            cur.execute('DELETE FROM watchlist_cache')
        cur.connection.commit()


def is_watchlist_cache_valid(service, status, cache_hours=24):
    """Safety-net fallback (primary invalidation is activity-based)."""
    last = get_watchlist_cache_last_updated(service, status)
    return is_cache_valid(last, cache_hours) if last else False


# ═══════════════════════════════════════════════════════════════════════════
#  Watchlist Activity  (activity-based cache invalidation)
# ═══════════════════════════════════════════════════════════════════════════

def get_watchlist_activity(service):
    """Stored activity record for a watchlist service."""
    _ensure_sync_table('watchlist_activity')
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            'SELECT * FROM watchlist_activity WHERE service=?', (service,))
        return cur.fetchone()


def save_watchlist_activity(service, activity_timestamp):
    """Save the last known activity timestamp for a service."""
    _ensure_sync_table('watchlist_activity')
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            'REPLACE INTO watchlist_activity '
            '(service, activity_timestamp, last_checked) VALUES (?, ?, ?)',
            (service, str(activity_timestamp), int(time.time())))
        cur.connection.commit()


def clear_watchlist_activity(service=None):
    """Clear stored activity timestamps."""
    _ensure_sync_table('watchlist_activity')
    try:
        with SQL(control.malSyncDB) as cur:
            if service:
                cur.execute(
                    'DELETE FROM watchlist_activity WHERE service=?',
                    (service,))
            else:
                cur.execute('DELETE FROM watchlist_activity')
            cur.connection.commit()
    except (dbapi2.DatabaseError, dbapi2.OperationalError):
        pass  # table may not exist on first run


# ═══════════════════════════════════════════════════════════════════════════
#  AniList Enrichment Cache
# ═══════════════════════════════════════════════════════════════════════════

def get_all_watchlist_mal_ids():
    """All unique MAL IDs across every cached watchlist entry."""
    _ensure_sync_table('watchlist_cache')
    rows = []
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            'SELECT DISTINCT mal_id FROM watchlist_cache '
            'WHERE mal_id IS NOT NULL')
        rows = cur.fetchall() or []
    result = []
    for row in rows:
        try:
            result.append(int(row['mal_id']))
        except (ValueError, TypeError):
            pass
    return result


def save_anilist_enrichment_batch(data_list):
    """Save AniList media objects keyed by ``idMal``."""
    if not data_list:
        return
    _ensure_sync_table('anilist_enrichment')
    now = int(time.time())
    rows = [
        (int(item['idMal']), dumps(item), now)
        for item in data_list if item.get('idMal')
    ]
    if not rows:
        return
    with SQL(control.malSyncDB) as cur:
        cur.execute('BEGIN IMMEDIATE')
        cur.executemany(
            'REPLACE INTO anilist_enrichment '
            '(mal_id, data, last_updated) VALUES (?, ?, ?)',
            rows)
        cur.execute('COMMIT')


def get_anilist_enrichment_batch(mal_ids, max_age_hours=168):
    """Cached AniList enrichment for given MAL IDs (default 7 days max)."""
    if not mal_ids:
        return {}
    _ensure_sync_table('anilist_enrichment')
    cutoff = int(time.time()) - (max_age_hours * 3600)
    result = {}
    with SQL(control.malSyncDB) as cur:
        ph = ','.join('?' for _ in mal_ids)
        cur.execute(
            f'SELECT * FROM anilist_enrichment '
            f'WHERE mal_id IN ({ph}) AND last_updated > ?',
            [int(m) for m in mal_ids] + [cutoff])
        for row in cur.fetchall():
            try:
                result[row['mal_id']] = loads(row['data'])
            except (pickle.UnpicklingError, EOFError, AttributeError, ValueError) as e:
                control.log(f"get_show_data unpickle error: {e}", 'debug')
    return result


def clear_anilist_enrichment():
    """Clear all AniList enrichment data."""
    _ensure_sync_table('anilist_enrichment')
    with SQL(control.malSyncDB) as cur:
        cur.execute('DELETE FROM anilist_enrichment')
        cur.connection.commit()


# ═══════════════════════════════════════════════════════════════════════════
#  Search History
# ═══════════════════════════════════════════════════════════════════════════

_SEARCH_TYPES = (
    'anime', 'movie', 'tv_show', 'tv_short',
    'special', 'ova', 'ona', 'music',
)


def _validate_search_type(media_type):
    if media_type not in _SEARCH_TYPES:
        raise ValueError(f"Invalid search history table: {media_type!r}")
    return media_type


def _ensure_search_tables(cur):
    tag = f"{control.searchHistoryDB}:search_tables"
    if tag in _tables_ready:
        return
    for t in _SEARCH_TYPES:
        cur.execute(f'CREATE TABLE IF NOT EXISTS {t} (value TEXT UNIQUE)')
    _tables_ready.add(tag)


def getSearchHistory(media_type):
    _validate_search_type(media_type)
    with SQL(control.searchHistoryDB) as cur:
        _ensure_search_tables(cur)
        cur.execute(f'SELECT value FROM {media_type} ORDER BY rowid DESC LIMIT 50')
        rows = cur.fetchall()
    return [row['value'] for row in rows]


def addSearchHistory(search_string, media_type):
    _validate_search_type(media_type)
    with SQL(control.searchHistoryDB) as cur:
        _ensure_search_tables(cur)
        cur.execute(
            f'REPLACE INTO {media_type} VALUES (?)', (search_string,))
        cur.connection.commit()


def clearSearchHistory():
    if not control.yesno_dialog(
            control.ADDON_NAME, "Clear all search history?"):
        return
    with SQL(control.searchHistoryDB) as cur:
        for t in _SEARCH_TYPES:
            cur.execute(f'DROP TABLE IF EXISTS {t}')
        cur.execute("VACUUM")
        cur.connection.commit()
    _tables_ready.discard(f"{control.searchHistoryDB}:search_tables")
    control.refresh()
    control.notify(
        control.ADDON_NAME, "Search History has been cleared", time=5000)


def clearSearchCatagory(media_type):
    _validate_search_type(media_type)
    if not control.yesno_dialog(
            control.ADDON_NAME, "Clear search history?"):
        return
    with SQL(control.searchHistoryDB) as cur:
        cur.execute(f'DROP TABLE IF EXISTS {media_type}')
        cur.execute(
            f'CREATE TABLE IF NOT EXISTS {media_type} (value TEXT UNIQUE)')
        cur.connection.commit()
    control.refresh()
    control.notify(
        control.ADDON_NAME, "Search History has been cleared", time=5000)


def remove_search(table, value):
    _validate_search_type(table)
    norm = value.strip()
    deleted = 0
    try:
        with SQL(control.searchHistoryDB) as cur:
            _ensure_search_tables(cur)
            cur.execute(f'DELETE FROM {table} WHERE value=?', (norm,))
            deleted = cur.rowcount
            cur.connection.commit()
    except Exception:
        deleted = 0
    control.refresh()
    if deleted == 0:
        control.notify(
            control.ADDON_NAME,
            f"Search item not found: '{norm}'", time=3000)

# ═══════════════════════════════════════════════════════════════════════════
#  Season Pack & Playback Continuity Caching
# ═══════════════════════════════════════════════════════════════════════════

def set_season_pack(mal_id, season, source):
    """Cache the selected season pack source for subsequent episode playback."""
    if not source or not mal_id:
        return
    key = f"season_pack_{mal_id}_{season or 1}"
    source_copy = dict(source)
    source_repr = repr(source_copy)
    duration = 720  # 30 days
    _cache_write(key, source_repr)
    _mem_set(key, source_repr, duration)


def get_season_pack(mal_id, season=1):
    """Retrieve the cached season pack source for this show and season."""
    if not mal_id:
        return None
    key = f"season_pack_{mal_id}_{season or 1}"
    mem = _mem_get(key)
    if mem is not None:
        return mem
    _init_cache_table()
    row = None
    with SQL(control.cacheFile) as cur:
        cur.execute('SELECT value, date FROM cache WHERE key=?', (key,))
        row = cur.fetchone()
    if row and is_cache_valid(row['date'], 720):
        try:
            data = ast.literal_eval(row['value'])
            if data:
                _mem_set(key, row['value'], 720)
                return data
        except (ValueError, SyntaxError) as e:
            control.log(f"cache_get parse error for {key}: {e}", 'debug')
    return None


def clear_season_pack(mal_id=None, season=None):
    """Purge cached season packs from SQLite and memory cache."""
    _init_cache_table()
    with SQL(control.cacheFile) as cur:
        if mal_id and season:
            key = f"season_pack_{mal_id}_{season}"
            cur.execute('DELETE FROM cache WHERE key=?', (key,))
            _mem_del(key)
        elif mal_id:
            cur.execute("DELETE FROM cache WHERE key LIKE ?", (f"season_pack_{mal_id}_%",))
            for s in range(1, 10):
                _mem_del(f"season_pack_{mal_id}_{s}")
        else:
            cur.execute("DELETE FROM cache WHERE key LIKE 'season_pack_%'")
            _bump_mem_generation()
        cur.connection.commit()


def _has_cache_id(value):
    """Return True if a cache identifier (mal_id or episode) is non-empty, preserving integer 0."""
    return value is not None and not isinstance(value, bool) and str(value).strip() != ''


def set_episode_sources(mal_id, episode, sources):
    """Cache the scraped/sorted sources list for an episode (e.g. from background pre-scraping)."""
    if not sources or not _has_cache_id(mal_id) or not _has_cache_id(episode):
        return
    key = f"episode_sources_{str(mal_id).strip()}_{str(episode).strip()}"
    sources_repr = repr(sources)
    duration = 4  # 4 hours cache for pre-scraped sources
    _cache_write(key, sources_repr)
    _mem_set(key, sources_repr, duration)


def get_episode_sources(mal_id, episode):
    """Retrieve pre-scraped sources for an episode if valid."""
    if not _has_cache_id(mal_id) or not _has_cache_id(episode):
        return None
    key = f"episode_sources_{str(mal_id).strip()}_{str(episode).strip()}"
    mem = _mem_get(key)
    if mem is not None:
        return mem
    _init_cache_table()
    row = None
    with SQL(control.cacheFile) as cur:
        cur.execute('SELECT value, date FROM cache WHERE key=?', (key,))
        row = cur.fetchone()
    if row and is_cache_valid(row['date'], 4):
        try:
            data = ast.literal_eval(row['value'])
            if data:
                _mem_set(key, row['value'], 4)
                return data
        except (ValueError, SyntaxError) as e:
            control.log(f"cache_get parse error for {key}: {e}", 'debug')
    return None


def clear_episode_sources(mal_id=None, episode=None):
    """Purge cached episode sources from SQLite and memory cache."""
    has_mal = _has_cache_id(mal_id)
    has_ep = _has_cache_id(episode)
    if not (
        (has_mal and has_ep)
        or (has_mal and episode is None)
        or (mal_id is None and episode is None)
    ):
        return
    _init_cache_table()
    with SQL(control.cacheFile) as cur:
        if has_mal and has_ep:
            key = f"episode_sources_{str(mal_id).strip()}_{str(episode).strip()}"
            cur.execute('DELETE FROM cache WHERE key=?', (key,))
            _mem_del(key)
        elif has_mal:
            clean_mal = str(mal_id).strip()
            cur.execute("DELETE FROM cache WHERE key LIKE ?", (f"episode_sources_{clean_mal}_%",))
            _bump_mem_generation()
        else:
            cur.execute("DELETE FROM cache WHERE key LIKE 'episode_sources_%'")
            _bump_mem_generation()
        cur.connection.commit()


def save_last_played_source(mal_id, source):
    """Save structured metadata of the last played source for smart scoring."""
    if not source or not mal_id:
        return
    key = f"last_played_{mal_id}"
    payload = {
        'release_title': source.get('release_title') or source.get('name') or '',
        'release_group': source_utils.extract_release_group(source.get('release_title') or source.get('name') or ''),
        'quality': source.get('quality', 0),
        'provider': source.get('provider', ''),
        'debrid_provider': source.get('debrid_provider', ''),
        'channel': source.get('channel', ''),
        'lang': source.get('lang', 0),
        'sub': source.get('sub', ''),
        'type': source.get('type', ''),
        'package': source_utils.is_season_pack(source),
        'hash': source.get('hash', '')
    }
    _cache_write(key, repr(payload))
    _mem_set(key, repr(payload), 720)


def get_last_played_source(mal_id):
    """Retrieve the last successfully played source profile for a show."""
    if not mal_id:
        return None
    key = f"last_played_{mal_id}"
    mem = _mem_get(key)
    if mem is not None:
        return mem
    _init_cache_table()
    row = None
    with SQL(control.cacheFile) as cur:
        cur.execute('SELECT value, date FROM cache WHERE key=?', (key,))
        row = cur.fetchone()
    if row and is_cache_valid(row['date'], 720):
        try:
            data = ast.literal_eval(row['value'])
            if data:
                _mem_set(key, row['value'], 720)
                return data
        except (ValueError, SyntaxError) as e:
            control.log(f"cache_get parse error for {key}: {e}", 'debug')
    return None


# ═══════════════════════════════════════════════════════════════════════════
#  Database & Scraper Maintenance & Telemetry
# ═══════════════════════════════════════════════════════════════════════════

def _format_db_bytes(bytes_count):
    """Format byte count into human-readable string (B, KB, MB, GB)."""
    try:
        b = float(bytes_count or 0)
    except (ValueError, TypeError):
        return "0 B"
    for unit in ['B', 'KB', 'MB', 'GB']:
        if b < 1024.0:
            return f"{b:.2f} {unit}"
        b /= 1024.0
    return f"{b:.2f} TB"


def get_database_stats():
    """
    Generate structured telemetry report on all Otaku SQLite databases,
    table row counts, page allocations, and storage footprint.
    """
    db_paths = [
        ('Cache Database', getattr(control, 'cacheFile', None)),
        ('Watchlist & Metadata Sync', getattr(control, 'malSyncDB', None)),
        ('Search History', getattr(control, 'searchHistoryDB', None)),
        ('Anime ID Mappings', getattr(control, 'mappingDB', None)),
    ]

    lines = []
    lines.append("═══════════════════════════════════════════════════════════════════")
    lines.append("       OTAKU DATABASE & STORAGE TELEMETRY REPORT")
    lines.append("═══════════════════════════════════════════════════════════════════")
    lines.append("")

    total_storage = 0

    for db_label, db_path in db_paths:
        lines.append(f"▶ {db_label}")
        if not db_path:
            lines.append("   Path: [Not Configured]")
            lines.append("")
            continue
        lines.append(f"   Path: {db_path}")
        if not os.path.exists(db_path):
            lines.append("   Status: File does not exist yet (created on first write)")
            lines.append("")
            continue

        try:
            main_size = os.path.getsize(db_path)
            wal_path = f"{db_path}-wal"
            shm_path = f"{db_path}-shm"
            wal_size = os.path.getsize(wal_path) if os.path.exists(wal_path) else 0
            shm_size = os.path.getsize(shm_path) if os.path.exists(shm_path) else 0
            db_total = main_size + wal_size + shm_size
            total_storage += db_total

            lines.append(f"   Storage: {_format_db_bytes(main_size)} (Main) | {_format_db_bytes(wal_size)} (WAL) | {_format_db_bytes(shm_size)} (SHM)")
            lines.append(f"   Total Footprint: {_format_db_bytes(db_total)}")

            with SQL(db_path, is_readonly=True) as cur:
                cur.execute("PRAGMA journal_mode")
                j_mode = (cur.fetchone() or {}).get('journal_mode', 'unknown')
                cur.execute("PRAGMA page_count")
                p_count = (cur.fetchone() or {}).get('page_count', 0)
                cur.execute("PRAGMA page_size")
                p_size = (cur.fetchone() or {}).get('page_size', 0)
                cur.execute("PRAGMA freelist_count")
                f_count = (cur.fetchone() or {}).get('freelist_count', 0)

                lines.append(f"   Engine: Journal={str(j_mode).upper()} | PageSize={p_size} B | Pages={p_count:,} (Free: {f_count:,})")

                # Table row counts
                cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
                tables = [r['name'] for r in cur.fetchall()]
                if tables:
                    table_summaries = []
                    for tbl in tables:
                        try:
                            cur.execute(f"SELECT COUNT(*) as c FROM \"{tbl}\"")
                            cnt = (cur.fetchone() or {}).get('c', 0)
                            table_summaries.append(f"{tbl}: {cnt:,} rows")
                        except Exception:
                            table_summaries.append(f"{tbl}: ?")
                    lines.append(f"   Tables ({len(tables)}): " + " | ".join(table_summaries))
                else:
                    lines.append("   Tables: None")
        except Exception as e:
            lines.append(f"   Error reading telemetry: {e}")
        lines.append("")

    lines.append("───────────────────────────────────────────────────────────────────")
    lines.append(f"Total Otaku Database Footprint: {_format_db_bytes(total_storage)}")
    lines.append("═══════════════════════════════════════════════════════════════════")
    return "\n".join(lines)


_SCRAPER_LATENCY_CACHE_KEY = 'scraper_latency_samples_v1'
_SCRAPER_LATENCY_MAX_SAMPLES = 20
_SCRAPER_LATENCY_LOCK = threading.Lock() if 'threading' in globals() else __import__('threading').Lock()


def record_provider_latency(provider: str, elapsed_s: float):
    """Record a bounded (<= 20 samples) per-provider scrape latency ring buffer sample in cache.db."""
    if not provider or elapsed_s is None:
        return
    try:
        val = max(0.0, float(elapsed_s))
    except (TypeError, ValueError):
        return
    with _SCRAPER_LATENCY_LOCK:
        try:
            raw = cache_get(_SCRAPER_LATENCY_CACHE_KEY)
            if raw and isinstance(raw.get('value'), str):
                data = control.loads_json(raw['value'], default={})
            elif raw and isinstance(raw.get('value'), dict):
                data = dict(raw['value'])
            else:
                data = {}
            if not isinstance(data, dict):
                data = {}
            samples = list(data.get(provider) or [])
            samples.append(round(val, 4))
            if len(samples) > _SCRAPER_LATENCY_MAX_SAMPLES:
                samples = samples[-_SCRAPER_LATENCY_MAX_SAMPLES:]
            data[provider] = samples
            cache_insert(_SCRAPER_LATENCY_CACHE_KEY, json.dumps(data, separators=(',', ':')))
        except Exception:
            pass


def get_provider_p90_latencies(min_samples: int = 3) -> dict:
    """Return rolling p90 latency (seconds) per provider from bounded <=20-sample ring buffer."""
    with _SCRAPER_LATENCY_LOCK:
        try:
            raw = cache_get(_SCRAPER_LATENCY_CACHE_KEY)
            if not raw:
                return {}
            raw_val = raw.get('value')
            data = control.loads_json(raw_val, default={}) if isinstance(raw_val, str) else raw_val
            if not isinstance(data, dict):
                return {}
        except Exception:
            return {}

    p90_map = {}
    for prov, samples in data.items():
        if not isinstance(samples, list) or len(samples) < int(min_samples):
            continue
        clean = sorted(float(s) for s in samples if isinstance(s, (int, float)) and s >= 0)
        if len(clean) < int(min_samples):
            continue
        # Nearest-rank 90th percentile
        idx = max(0, min(len(clean) - 1, int((0.90 * len(clean)) + 0.999999) - 1))
        p90_map[str(prov)] = round(clean[idx], 3)
    return p90_map


def get_scraper_metrics_report():
    """
    Generate telemetry dashboard report for scrapers, circuit breakers,
    and provider cache health.
    """
    lines = []
    lines.append("═══════════════════════════════════════════════════════════════════")
    lines.append("       OTAKU SCRAPER HEALTH & LATENCY DASHBOARD")
    lines.append("═══════════════════════════════════════════════════════════════════")
    lines.append("")

    # 1. Scraper Circuit Breaker Status
    try:
        from resources.lib.pages import circuit_breaker
        with circuit_breaker._lock:
            failures = dict(circuit_breaker._failures)
            cooldowns = dict(circuit_breaker._cooldown_until)

        lines.append("▶ Scraper Circuit Breaker Status")
        now = time.time()
        active_cooldowns = {p: int(cd - now) for p, cd in cooldowns.items() if cd > now}

        if active_cooldowns:
            lines.append("   ⚠️ Tripped Scrapers (Cooling Down):")
            for provider, rem_sec in sorted(active_cooldowns.items()):
                fail_cnt = failures.get(provider, 0)
                lines.append(f"      • {provider}: {rem_sec}s remaining ({fail_cnt} consecutive errors)")
        else:
            lines.append("   ✓ All Scraper Circuits Healthy (No Active Tripped Breakers)")

        if failures:
            lines.append("   Current Failure Counters:")
            for p, cnt in sorted(failures.items()):
                lines.append(f"      • {p}: {cnt} error(s)")
        else:
            lines.append("   Failure Counters: All zero")
    except Exception as e:
        lines.append(f"   Circuit Breaker Telemetry Error: {e}")
    lines.append("")

    # 2. Dynamic Domain Mirrors Status
    lines.append("▶ Dynamic Domain Mirrors")
    try:
        from resources.lib.ui import domains
        active_domains = domains.get_all_domains()
        if active_domains:
            for scraper_name, d_url in sorted(active_domains.items()):
                lines.append(f"   • {scraper_name}: {d_url}")
        else:
            lines.append("   Using default hardcoded scraper domains")
    except Exception as e:
        lines.append(f"   Domain Mirror Error: {e}")
    lines.append("")

    # 3. Provider Latency & Cache Statistics
    p90_latencies = get_provider_p90_latencies(min_samples=1)
    if p90_latencies:
        lines.append("▶ Rolling Per-Provider p90 Latencies (<=20 samples)")
        for prov, p90_s in sorted(p90_latencies.items()):
            lines.append(f"   • {prov:<16}: {p90_s:.2f}s (p90)")
        lines.append("")

    lines.append("▶ Scraper & Provider Cache Health")
    try:
        if control.cacheFile and os.path.exists(control.cacheFile):
            with SQL(control.cacheFile) as cur:
                cur.execute("SELECT COUNT(*) as c FROM cache")
                total_cache = (cur.fetchone() or {}).get('c', 0)

                cur.execute("SELECT COUNT(*) as c FROM cache WHERE key LIKE 'show_sources_%' OR key LIKE 'show_scrapers_%' OR key LIKE 'last_played_%'")
                provider_entries = (cur.fetchone() or {}).get('c', 0)

                cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='debrid_cache'")
                has_debrid = cur.fetchone()
                debrid_entries = 0
                if has_debrid:
                    cur.execute("SELECT COUNT(*) as c FROM debrid_cache")
                    debrid_entries = (cur.fetchone() or {}).get('c', 0)

                lines.append(f"   • Total Cache Rows: {total_cache:,}")
                lines.append(f"   • Provider Source Cache Rows: {provider_entries:,}")
                lines.append(f"   • Debrid Hash Availability Cache Rows: {debrid_entries:,}")
        else:
            lines.append("   • Cache database not yet created")
    except Exception as e:
        lines.append(f"   Provider Cache Error: {e}")

    lines.append("")
    lines.append("───────────────────────────────────────────────────────────────────")
    lines.append("Tip: Use 'Clear Scraper Telemetry' in Settings to reset all circuit")
    lines.append("breakers and clear stale scraper result caches.")
    lines.append("═══════════════════════════════════════════════════════════════════")
    return "\n".join(lines)


def clear_scraper_metrics():
    """Reset scraper circuit breakers, rolling latency ring buffers, and clear scraper cache entries."""
    try:
        from resources.lib.pages import circuit_breaker
        circuit_breaker.reset()
        control.log("ScraperCircuitBreaker: All circuits and counters reset", 'info')
    except Exception as e:
        control.log(f"Error resetting scraper circuit breaker: {e}", 'warning')

    with _SCRAPER_LATENCY_LOCK:
        try:
            cache_insert(_SCRAPER_LATENCY_CACHE_KEY, '{}')
        except Exception:
            pass

    cache_clear_providers()


def vacuum_all_databases():
    """
    Run SQLite VACUUM and WAL checkpoints across all Otaku databases,
    reclaiming fragmented space and returning the total bytes reclaimed.
    """
    db_paths = [
        getattr(control, 'cacheFile', None),
        getattr(control, 'malSyncDB', None),
        getattr(control, 'searchHistoryDB', None),
    ]

    total_reclaimed = 0

    for path in db_paths:
        if path and os.path.exists(path):
            try:
                wal_path = f"{path}-wal"
                size_before = os.path.getsize(path) + (os.path.getsize(wal_path) if os.path.exists(wal_path) else 0)

                with SQL(path) as cur:
                    cur.execute("VACUUM")
                    cur.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                    cur.execute("PRAGMA optimize")

                size_after = os.path.getsize(path) + (os.path.getsize(wal_path) if os.path.exists(wal_path) else 0)
                reclaimed = max(0, size_before - size_after)
                total_reclaimed += reclaimed
                control.log(f"Vacuumed {os.path.basename(path)}: reclaimed {_format_db_bytes(reclaimed)}", 'info')
            except Exception as e:
                control.log(f"Failed to vacuum {path}: {e}", 'warning')

    return total_reclaimed


def check_database_integrity():
    """
    Run PRAGMA quick_check / integrity_check across all databases.
    Returns (all_ok: bool, results: dict of {db_name: status_str}).
    """
    db_paths = [
        ('Cache Database', getattr(control, 'cacheFile', None)),
        ('Watchlist & Metadata Sync', getattr(control, 'malSyncDB', None)),
        ('Search History', getattr(control, 'searchHistoryDB', None)),
        ('Anime ID Mappings', getattr(control, 'mappingDB', None)),
    ]

    results = {}
    all_ok = True

    for name, path in db_paths:
        if not path or not os.path.exists(path):
            results[name] = "Not initialized"
            continue
        try:
            with SQL(path, is_readonly=True) as cur:
                cur.execute("PRAGMA integrity_check")
                row = cur.fetchone()
                status = row.get('integrity_check', 'ok') if row else 'ok'
                results[name] = status
                if str(status).lower() != 'ok':
                    all_ok = False
        except Exception as e:
            results[name] = f"Error: {e}"
            all_ok = False

    return all_ok, results


# ═══════════════════════════════════════════════════════════════════════════
#  Multipage Pre-Caching Job Queue (multipage_jobs table in cache.db)
# ═══════════════════════════════════════════════════════════════════════════

def _init_multipage_jobs_table():
    _ensure_table(
        control.cacheFile, 'multipage_jobs',
        'CREATE TABLE IF NOT EXISTS multipage_jobs ('
        'id INTEGER PRIMARY KEY AUTOINCREMENT, '
        'job_key TEXT UNIQUE, '
        'provider TEXT, '
        'browser_method TEXT, '
        'url_path TEXT, '
        'route TEXT, '
        'params TEXT, '
        'current_page INTEGER, '
        'target_page INTEGER, '
        'status TEXT, '
        'priority INTEGER DEFAULT 0, '
        'error_count INTEGER DEFAULT 0, '
        'last_error TEXT, '
        'created_at INTEGER, '
        'updated_at INTEGER)'
    )
    _ensure_table(
        control.cacheFile, 'multipage_jobs_ix_status',
        'CREATE INDEX IF NOT EXISTS ix_multipage_jobs_status '
        'ON multipage_jobs (status, priority DESC, created_at ASC)'
    )
    _ensure_table(
        control.cacheFile, 'multipage_jobs_ix_updated',
        'CREATE INDEX IF NOT EXISTS ix_multipage_jobs_updated '
        'ON multipage_jobs (updated_at)'
    )


def enqueue_multipage_job(provider, browser_method, url_path, request_params, target_page=20, priority=0, current_page=2):
    """Idempotently enqueue a multipage pre-cache job into multipage_jobs table.

    Returns job_id (str) or None on failure.
    """
    _init_multipage_jobs_table()
    now = int(time.time())

    if isinstance(request_params, (dict, list)):
        params_str = json.dumps(request_params, sort_keys=True)
    else:
        params_str = str(request_params or '')

    route = str(url_path or browser_method or '')
    job_key = f"{provider}:{browser_method}:{url_path}:{generate_md5(params_str)}"

    try:
        with SQL(control.cacheFile) as cur:
            cur.execute(
                "SELECT id, status, current_page, target_page FROM multipage_jobs WHERE job_key=?",
                (job_key,)
            )
            existing = cur.fetchone()
            if existing:
                job_id = existing['id']
                existing_target = existing['target_page'] or 0
                existing_status = existing['status']

                if existing_status in ('pending', 'running'):
                    if target_page > existing_target:
                        cur.execute(
                            "UPDATE multipage_jobs SET target_page=?, updated_at=? WHERE id=?",
                            (int(target_page), now, job_id)
                        )
                        cur.connection.commit()
                    return str(job_id)
                elif existing_status in ('completed', 'failed'):
                    cur_page = existing['current_page'] or 1
                    if target_page > cur_page or existing_status == 'failed':
                        cur.execute(
                            "UPDATE multipage_jobs SET status='pending', target_page=?, error_count=0, last_error=NULL, updated_at=? WHERE id=?",
                            (int(target_page), now, job_id)
                        )
                        cur.connection.commit()
                    return str(job_id)
                return str(job_id)

            cur.execute(
                "INSERT INTO multipage_jobs "
                "(job_key, provider, browser_method, url_path, route, params, current_page, target_page, status, priority, error_count, last_error, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, 0, NULL, ?, ?)",
                (job_key, str(provider), str(browser_method), str(url_path), route, params_str, int(current_page), int(target_page), int(priority), now, now)
            )
            cur.connection.commit()
            return str(cur.lastrowid)
    except Exception as e:
        control.log(f"enqueue_multipage_job error: {e}", level='error')
        return None


def dequeue_multipage_job(provider=None):
    """Atomically transitions highest priority pending job to 'running' with timestamp.

    Returns job dict or None.
    """
    _init_multipage_jobs_table()
    now = int(time.time())
    try:
        with SQL(control.cacheFile) as cur:
            if provider:
                cur.execute(
                    "SELECT * FROM multipage_jobs WHERE status='pending' AND provider=? ORDER BY priority DESC, created_at ASC LIMIT 1",
                    (provider,)
                )
            else:
                cur.execute(
                    "SELECT * FROM multipage_jobs WHERE status='pending' ORDER BY priority DESC, created_at ASC LIMIT 1"
                )
            job = cur.fetchone()
            if not job:
                return None

            job_id = job['id']
            cur.execute(
                "UPDATE multipage_jobs SET status='running', updated_at=? WHERE id=? AND status='pending'",
                (now, job_id)
            )
            if cur.rowcount > 0:
                cur.connection.commit()
                job_dict = dict(job)
                job_dict['status'] = 'running'
                job_dict['updated_at'] = now
                if 'job_id' not in job_dict and 'id' in job_dict:
                    job_dict['job_id'] = job_dict['id']
                if 'request_params' not in job_dict and 'params' in job_dict:
                    job_dict['request_params'] = job_dict['params']
                return job_dict
            cur.connection.commit()
    except Exception as e:
        control.log(f"dequeue_multipage_job error: {e}", level='error')
    return None


def update_multipage_job_progress(job_id, current_page):
    """Update current_page and updated_at heartbeat for job."""
    _init_multipage_jobs_table()
    now = int(time.time())
    try:
        with SQL(control.cacheFile) as cur:
            cur.execute(
                "UPDATE multipage_jobs SET current_page=?, updated_at=? WHERE id=?",
                (int(current_page), now, int(job_id))
            )
            cur.connection.commit()
            return cur.rowcount > 0
    except Exception as e:
        control.log(f"update_multipage_job_progress error: {e}", level='error')
        return False


def mark_multipage_job_done(job_id):
    """Mark job status as 'completed'."""
    _init_multipage_jobs_table()
    now = int(time.time())
    try:
        with SQL(control.cacheFile) as cur:
            cur.execute(
                "UPDATE multipage_jobs SET status='completed', updated_at=? WHERE id=?",
                (now, int(job_id))
            )
            cur.connection.commit()
            return cur.rowcount > 0
    except Exception as e:
        control.log(f"mark_multipage_job_done error: {e}", level='error')
        return False


def mark_multipage_job_failed(job_id, error=None, max_retries=3):
    """Increment error count. If error_count >= max_retries, mark 'failed', else reset to 'pending'."""
    _init_multipage_jobs_table()
    now = int(time.time())
    try:
        with SQL(control.cacheFile) as cur:
            cur.execute("SELECT error_count FROM multipage_jobs WHERE id=?", (int(job_id),))
            row = cur.fetchone()
            if not row:
                return False
            error_count = (row['error_count'] or 0) + 1
            new_status = 'failed' if error_count >= max_retries else 'pending'
            err_str = str(error) if error is not None else None
            cur.execute(
                "UPDATE multipage_jobs SET status=?, error_count=?, last_error=?, updated_at=? WHERE id=?",
                (new_status, error_count, err_str, now, int(job_id))
            )
            cur.connection.commit()
            return cur.rowcount > 0
    except Exception as e:
        control.log(f"mark_multipage_job_failed error: {e}", level='error')
        return False


def prune_stale_multipage_jobs(max_age_seconds=86400, running_timeout=300):
    """Reset stale running jobs (>running_timeout) to 'pending' and delete completed/failed jobs older than max_age_seconds.

    Returns total affected rows count.
    """
    _init_multipage_jobs_table()
    now = int(time.time())
    stale_running_cutoff = now - int(running_timeout)
    stale_purge_cutoff = now - int(max_age_seconds)
    total_affected = 0
    try:
        with SQL(control.cacheFile) as cur:
            cur.execute(
                "UPDATE multipage_jobs SET status='pending', updated_at=? WHERE status='running' AND updated_at < ?",
                (now, stale_running_cutoff)
            )
            total_affected += cur.rowcount

            cur.execute(
                "DELETE FROM multipage_jobs WHERE status IN ('completed', 'failed') AND updated_at < ?",
                (stale_purge_cutoff,)
            )
            total_affected += cur.rowcount
            cur.connection.commit()
    except Exception as e:
        control.log(f"prune_stale_multipage_jobs error: {e}", level='error')
    return total_affected


# ═══════════════════════════════════════════════════════════════════════════
#  Per-Series Playback & Scraper Override Profiles (NF-06)
# ═══════════════════════════════════════════════════════════════════════════

def _ensure_series_overrides_table():
    cache_key = f"{control.malSyncDB}:series_overrides"
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            'CREATE TABLE IF NOT EXISTS series_overrides ('
            'mal_id INTEGER PRIMARY KEY, '
            'audio_lang TEXT, '
            'sub_lang TEXT, '
            'sub_mode TEXT, '
            'preferred_provider TEXT, '
            'preferred_group TEXT DEFAULT "", '
            'excluded_groups TEXT DEFAULT "", '
            'intro_offset_s INTEGER DEFAULT 0, '
            'outro_offset_s INTEGER DEFAULT 0, '
            'episode_offset INTEGER DEFAULT 0, '
            'sub_offset_ms INTEGER DEFAULT 0, '
            'skip_filler_mode TEXT DEFAULT "default", '
            'updated_at INTEGER NOT NULL)'
        )
        cur.execute("PRAGMA table_info(series_overrides)")
        cols = {col['name'] for col in cur.fetchall()}
        if 'episode_offset' not in cols:
            try:
                cur.execute("ALTER TABLE series_overrides ADD COLUMN episode_offset INTEGER DEFAULT 0")
            except Exception:
                pass
        if 'sub_offset_ms' not in cols:
            try:
                cur.execute("ALTER TABLE series_overrides ADD COLUMN sub_offset_ms INTEGER DEFAULT 0")
            except Exception:
                pass
        if 'preferred_group' not in cols:
            try:
                cur.execute('ALTER TABLE series_overrides ADD COLUMN preferred_group TEXT DEFAULT ""')
            except Exception:
                pass
        if 'excluded_groups' not in cols:
            try:
                cur.execute('ALTER TABLE series_overrides ADD COLUMN excluded_groups TEXT DEFAULT ""')
            except Exception:
                pass
        cur.connection.commit()
    _tables_ready.add(cache_key)


def get_series_override(mal_id):
    """Retrieve per-series playback/scraper overrides for a MAL ID."""
    if not mal_id or not str(mal_id).isdigit():
        return None
    _ensure_series_overrides_table()
    try:
        with SQL(control.malSyncDB) as cur:
            cur.execute('SELECT * FROM series_overrides WHERE mal_id=?', (int(mal_id),))
            row = cur.fetchone()
            if isinstance(row, dict):
                if 'sub_offset_ms' not in row:
                    row['sub_offset_ms'] = 0
                if 'preferred_group' not in row or row['preferred_group'] is None:
                    row['preferred_group'] = ''
                if 'excluded_groups' not in row or row['excluded_groups'] is None:
                    row['excluded_groups'] = ''
            return row
    except Exception as e:
        control.log(f"get_series_override error for {mal_id}: {e}", level='warning')
        return None


def set_series_override(
    mal_id,
    audio_lang=None,
    sub_lang=None,
    sub_mode=None,
    preferred_provider=None,
    intro_offset_s=0,
    outro_offset_s=0,
    skip_filler_mode='default',
    episode_offset=0,
    sub_offset_ms=None,
    preferred_group=None,
    excluded_groups=None,
):
    """Create or update per-series playback/scraper overrides for a MAL ID."""
    if not mal_id or not str(mal_id).isdigit():
        return False
    _ensure_series_overrides_table()
    existing = None
    if sub_offset_ms is None or preferred_group is None or excluded_groups is None:
        existing = get_series_override(mal_id)
    if sub_offset_ms is None:
        sub_offset_ms = int(existing.get('sub_offset_ms') or 0) if isinstance(existing, dict) else 0
    if preferred_group is None:
        preferred_group = str(existing.get('preferred_group') or '').strip() if isinstance(existing, dict) else ''
    else:
        preferred_group = str(preferred_group or '').strip()
    if excluded_groups is None:
        excluded_groups = str(existing.get('excluded_groups') or '').strip() if isinstance(existing, dict) else ''
    else:
        excluded_groups = str(excluded_groups or '').strip()
    now = int(time.time())
    try:
        with SQL(control.malSyncDB) as cur:
            execute_write_with_retry(
                cur,
                'INSERT OR REPLACE INTO series_overrides '
                '(mal_id, audio_lang, sub_lang, sub_mode, preferred_provider, '
                'preferred_group, excluded_groups, '
                'intro_offset_s, outro_offset_s, episode_offset, sub_offset_ms, skip_filler_mode, updated_at) '
                'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                (
                    int(mal_id),
                    str(audio_lang or '').strip() or None,
                    str(sub_lang or '').strip() or None,
                    str(sub_mode or '').strip() or None,
                    str(preferred_provider or '').strip() or None,
                    preferred_group,
                    excluded_groups,
                    int(intro_offset_s or 0),
                    int(outro_offset_s or 0),
                    int(episode_offset or 0),
                    int(sub_offset_ms or 0),
                    str(skip_filler_mode or 'default').strip(),
                    now,
                ),
            )
            cur.connection.commit()
            return True
    except Exception as e:
        control.log(f"set_series_override error for {mal_id}: {e}", level='error')
        return False


def pin_series_release_group(mal_id, group_name):
    """Pin a preferred release group for *mal_id*, preserving all other overrides and clearing from exclusions."""
    if not mal_id or not str(mal_id).isdigit():
        return False
    clean_group = str(group_name or '').strip()
    if not clean_group:
        return unpin_series_release_group(mal_id)
    norm_target = source_utils.normalize_release_group(clean_group)
    existing = get_series_override(mal_id) or {}
    excl_raw = str(existing.get('excluded_groups') or '')
    kept_excl = [
        g.strip() for g in excl_raw.replace(';', ',').split(',')
        if g.strip() and source_utils.normalize_release_group(g) != norm_target
    ]
    return set_series_override(
        mal_id,
        audio_lang=existing.get('audio_lang'),
        sub_lang=existing.get('sub_lang'),
        sub_mode=existing.get('sub_mode'),
        preferred_provider=existing.get('preferred_provider'),
        intro_offset_s=int(existing.get('intro_offset_s') or 0),
        outro_offset_s=int(existing.get('outro_offset_s') or 0),
        skip_filler_mode=existing.get('skip_filler_mode') or 'default',
        episode_offset=int(existing.get('episode_offset') or 0),
        sub_offset_ms=int(existing.get('sub_offset_ms') or 0),
        preferred_group=clean_group,
        excluded_groups=', '.join(kept_excl),
    )


def unpin_series_release_group(mal_id):
    """Clear preferred release group for *mal_id*, preserving all other overrides."""
    if not mal_id or not str(mal_id).isdigit():
        return False
    existing = get_series_override(mal_id)
    if not isinstance(existing, dict):
        return True
    return set_series_override(
        mal_id,
        audio_lang=existing.get('audio_lang'),
        sub_lang=existing.get('sub_lang'),
        sub_mode=existing.get('sub_mode'),
        preferred_provider=existing.get('preferred_provider'),
        intro_offset_s=int(existing.get('intro_offset_s') or 0),
        outro_offset_s=int(existing.get('outro_offset_s') or 0),
        skip_filler_mode=existing.get('skip_filler_mode') or 'default',
        episode_offset=int(existing.get('episode_offset') or 0),
        sub_offset_ms=int(existing.get('sub_offset_ms') or 0),
        preferred_group='',
        excluded_groups=existing.get('excluded_groups') or '',
    )


def exclude_series_release_group(mal_id, group_name, remove=False):
    """Add (or remove) a release group in *mal_id*'s excluded_groups list, preserving other overrides."""
    if not mal_id or not str(mal_id).isdigit():
        return False
    clean_group = str(group_name or '').strip()
    if not clean_group:
        return False
    norm_target = source_utils.normalize_release_group(clean_group)
    existing = get_series_override(mal_id) or {}
    excl_raw = str(existing.get('excluded_groups') or '')
    groups = [g.strip() for g in excl_raw.replace(';', ',').split(',') if g.strip()]
    if remove:
        groups = [g for g in groups if source_utils.normalize_release_group(g) != norm_target]
        pref = str(existing.get('preferred_group') or '').strip()
    else:
        if not any(source_utils.normalize_release_group(g) == norm_target for g in groups):
            groups.append(clean_group)
        pref = str(existing.get('preferred_group') or '').strip()
        if pref and source_utils.normalize_release_group(pref) == norm_target:
            pref = ''
    return set_series_override(
        mal_id,
        audio_lang=existing.get('audio_lang'),
        sub_lang=existing.get('sub_lang'),
        sub_mode=existing.get('sub_mode'),
        preferred_provider=existing.get('preferred_provider'),
        intro_offset_s=int(existing.get('intro_offset_s') or 0),
        outro_offset_s=int(existing.get('outro_offset_s') or 0),
        skip_filler_mode=existing.get('skip_filler_mode') or 'default',
        episode_offset=int(existing.get('episode_offset') or 0),
        sub_offset_ms=int(existing.get('sub_offset_ms') or 0),
        preferred_group=pref,
        excluded_groups=', '.join(groups),
    )


def delete_series_override(mal_id):
    """Remove per-series override profile for a MAL ID."""
    if not mal_id or not str(mal_id).isdigit():
        return False
    _ensure_series_overrides_table()
    try:
        with SQL(control.malSyncDB) as cur:
            cur.execute('DELETE FROM series_overrides WHERE mal_id=?', (int(mal_id),))
            cur.connection.commit()
            return cur.rowcount > 0
    except Exception as e:
        control.log(f"delete_series_override error for {mal_id}: {e}", level='error')
        return False


def list_series_overrides():
    """Return all configured per-series override profiles ordered by updated_at DESC."""
    _ensure_series_overrides_table()
    try:
        with SQL(control.malSyncDB) as cur:
            cur.execute('SELECT * FROM series_overrides ORDER BY updated_at DESC')
            return cur.fetchall() or []
    except Exception as e:
        control.log(f"list_series_overrides error: {e}", level='warning')
        return []


# ═══════════════════════════════════════════════════════════════════════════
#  Persistent Watchlist Scrobble 429/5xx Retry Queue (NF-01)
# ═══════════════════════════════════════════════════════════════════════════

def _ensure_scrobble_retry_queue_table():
    cache_key = f"{control.malSyncDB}:scrobble_retry_queue"
    if cache_key in _tables_ready:
        return
    with SQL(control.malSyncDB) as cur:
        cur.execute(
            'CREATE TABLE IF NOT EXISTS scrobble_retry_queue ('
            'id INTEGER PRIMARY KEY AUTOINCREMENT, '
            'service TEXT NOT NULL, '
            'action TEXT NOT NULL, '
            'mal_id INTEGER NOT NULL, '
            'episode INTEGER DEFAULT 0, '
            'status TEXT DEFAULT "", '
            'score INTEGER DEFAULT 0, '
            'attempts INTEGER DEFAULT 0, '
            'next_retry_at INTEGER NOT NULL, '
            'last_error TEXT DEFAULT "", '
            'created_at INTEGER NOT NULL, '
            'UNIQUE(service, action, mal_id))'
        )
        cur.connection.commit()
    _tables_ready.add(cache_key)


def enqueue_scrobble_retry(service_name, action, mal_id, episode=0, status='', score=0, error='', delay_seconds=60, retry_after=None):
    """Insert or update a pending watchlist scrobble retry entry with Retry-After and exponential backoff."""
    if not service_name or not action or not mal_id or not str(mal_id).isdigit():
        return False
    _ensure_scrobble_retry_queue_table()
    now = int(time.time())
    base_delay = max(0, int(delay_seconds if delay_seconds is not None else 60))
    if retry_after is None and error:
        m = re.search(r'retry[-_ ]?after[:=\s]+(\d+(?:\.\d+)?)', str(error), re.IGNORECASE)
        if m:
            retry_after = float(m.group(1))
    retry_after_sec = None
    if retry_after is not None:
        try:
            retry_after_sec = min(3600, max(0, int(float(retry_after))))
        except (ValueError, TypeError):
            retry_after_sec = None
    try:
        with SQL(control.malSyncDB) as cur:
            cur.execute(
                'SELECT attempts FROM scrobble_retry_queue WHERE service=? AND action=? AND mal_id=?',
                (str(service_name), str(action), int(mal_id)),
            )
            existing = cur.fetchone()
            attempts = (int(existing.get('attempts') or 0) + 1) if existing else 1
            backoff = min(3600, base_delay * (2 ** max(0, attempts - 1)))
            if retry_after_sec is not None:
                backoff = max(backoff, retry_after_sec)
            next_retry = now + backoff
            execute_write_with_retry(
                cur,
                'INSERT OR REPLACE INTO scrobble_retry_queue '
                '(service, action, mal_id, episode, status, score, attempts, next_retry_at, last_error, created_at) '
                'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                (
                    str(service_name),
                    str(action),
                    int(mal_id),
                    int(episode or 0),
                    str(status or ''),
                    int(score or 0),
                    attempts,
                    next_retry,
                    str(error or '')[:256],
                    now,
                ),
            )
            cur.connection.commit()
            return True
    except Exception as e:
        control.log(f"enqueue_scrobble_retry error: {e}", level='error')
        return False


def get_due_scrobble_retries(now_ts=None, limit=25):
    """Fetch pending scrobble retry items due at or before now_ts."""
    _ensure_scrobble_retry_queue_table()
    now = int(now_ts if now_ts is not None else time.time())
    try:
        with SQL(control.malSyncDB) as cur:
            cur.execute(
                'SELECT * FROM scrobble_retry_queue WHERE next_retry_at <= ? ORDER BY next_retry_at ASC LIMIT ?',
                (now, int(limit or 25)),
            )
            return cur.fetchall() or []
    except Exception as e:
        control.log(f"get_due_scrobble_retries error: {e}", level='warning')
        return []


def list_scrobble_retry_queue():
    """Return all queued scrobble retry entries for telemetry inspection."""
    _ensure_scrobble_retry_queue_table()
    try:
        with SQL(control.malSyncDB) as cur:
            cur.execute('SELECT * FROM scrobble_retry_queue ORDER BY next_retry_at ASC')
            return cur.fetchall() or []
    except Exception as e:
        control.log(f"list_scrobble_retry_queue error: {e}", level='warning')
        return []


def remove_scrobble_retry(service_name, action, mal_id):
    """Remove a completed or expired scrobble retry entry."""
    _ensure_scrobble_retry_queue_table()
    try:
        with SQL(control.malSyncDB) as cur:
            cur.execute(
                'DELETE FROM scrobble_retry_queue WHERE service=? AND action=? AND mal_id=?',
                (str(service_name), str(action), int(mal_id)),
            )
            cur.connection.commit()
            return cur.rowcount > 0
    except Exception as e:
        control.log(f"remove_scrobble_retry error: {e}", level='warning')
        return False


# ═══════════════════════════════════════════════════════════════════════════
#  SQLite Quick-Check Verification Helper (NF-05)
# ═══════════════════════════════════════════════════════════════════════════

def verify_sqlite_integrity(db_path, required_tables=('anime',)):
    """Verify a candidate SQLite database file passes PRAGMA quick_check and contains required tables."""
    if not db_path or not os.path.isfile(db_path):
        return False, 'missing_file'
    try:
        with open(db_path, 'rb') as fp:
            header = fp.read(16)
        if not header.startswith(b'SQLite format 3\x00'):
            return False, 'invalid_sqlite_header'
        abs_path = os.path.abspath(db_path)
        conn = dbapi2.connect(f"file:{abs_path}?mode=ro", uri=True, timeout=10.0)
        try:
            cur = conn.cursor()
            cur.execute('PRAGMA quick_check(1)')
            row = cur.fetchone()
            if not row or str(row[0]).lower() != 'ok':
                return False, f"quick_check_failed:{row[0] if row else 'empty'}"
            if required_tables:
                cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
                found = {r[0] for r in cur.fetchall() if r and r[0]}
                for req in required_tables:
                    if req not in found:
                        return False, f"missing_table:{req}"
                for req in required_tables:
                    cur.execute(f"SELECT COUNT(*) FROM {req}")
                    cnt = cur.fetchone()[0]
                    if cnt <= 0:
                        return False, f"empty_table:{req}"
            return True, 'ok'
        finally:
            conn.close()
    except Exception as e:
        return False, f"sqlite_error:{e}"


# ═══════════════════════════════════════════════════════════════════════════
#  Playback Failover Context Storage (NF-11, offloads >64KB from Window props)
# ═══════════════════════════════════════════════════════════════════════════

def _pb_failover_key(mal_id, episode):
    return f"otaku_pb_failover_{mal_id}_{episode}"


def save_playback_failover_context(mal_id, episode, payload):
    """Store compact ordered source candidates and params in cache.db for mid-stream NF-11 failover."""
    if not mal_id or not isinstance(payload, dict):
        return False
    ep = str(episode if episode is not None else 1)
    try:
        slim_sources = []
        for s in (payload.get('sources') or [])[:30]:
            if not isinstance(s, dict):
                continue
            slim_sources.append({
                'provider': s.get('provider', ''),
                'type': s.get('type', ''),
                'debrid_provider': s.get('debrid_provider', ''),
                'hash': s.get('hash', ''),
                'magnet': s.get('magnet', ''),
                'release_title': s.get('release_title', ''),
                'name': s.get('name', ''),
                'quality': s.get('quality', 0),
                'info': list(s.get('info') or []),
                'size': s.get('size', ''),
                'filename': s.get('filename', ''),
                'episode_re': s.get('episode_re', ''),
                'subs': list(s.get('subs') or [])[:4] if s.get('subs') else [],
            })
        doc = {
            'mal_id': str(mal_id),
            'episode': ep,
            'candidate_index': int(payload.get('candidate_index') or 0),
            'active_url': str(payload.get('active_url') or ''),
            'active_host': str(payload.get('active_host') or ''),
            'debrid_provider': str(payload.get('debrid_provider') or ''),
            'media_type': str(payload.get('media_type') or 'episode'),
            'sources': slim_sources,
            'saved_at': int(time.time()),
        }
        cache_insert(_pb_failover_key(mal_id, ep), json.dumps(doc))
        return True
    except Exception as e:
        control.log(f"save_playback_failover_context error: {e}", level='debug')
        return False


def get_playback_failover_context(mal_id, episode, max_age_seconds=14400):
    """Retrieve stored mid-stream failover context from cache.db if fresh."""
    if not mal_id:
        return None
    ep = str(episode if episode is not None else 1)
    try:
        row = cache_get(_pb_failover_key(mal_id, ep))
        if not row or not row.get('value'):
            return None
        doc = control.loads_json(row['value'], default={})
        if not isinstance(doc, dict) or not doc.get('sources'):
            return None
        saved_at = int(doc.get('saved_at') or 0)
        if saved_at and (time.time() - saved_at) > max_age_seconds:
            return None
        return doc
    except Exception:
        return None



