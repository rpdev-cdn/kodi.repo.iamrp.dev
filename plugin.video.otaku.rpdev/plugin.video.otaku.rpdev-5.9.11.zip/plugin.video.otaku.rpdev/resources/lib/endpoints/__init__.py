import datetime

from resources.lib.ui import control


def _dub_is_upcoming(release_time):
    """True when the dub release time (local 'YYYY-MM-DD HH:MM') is still in the future.

    Unparseable values are treated as upcoming so third-party formats are not hidden.
    """
    try:
        released = datetime.datetime.strptime(str(release_time)[:16], '%Y-%m-%d %H:%M')
    except (ValueError, TypeError):
        return True
    return released > datetime.datetime.now()


def get_second_label(info, dub_data, filler=None):
    if control.getBool('jz.filler') and filler:
        return filler

    code_dub = code_sub = code = None

    # if ani_data:
    #     episode_schedule = ani_data['airingSchedule']['nodes']
    #     if len(episode_schedule) != 0:
    #         from datetime import datetime
    #         for ep_sched in episode_schedule:
    #             if ep_sched['episode'] == episode:
    #                 # info['title'] = control.colorString(info['title'], color="red")
    #                 code_sub = f'{datetime.fromtimestamp(ep_sched["airingAt"])}'[:-3]

    if dub_data:
        episode = info.get('episode')
        if not episode:
            return code
        for dub_dat in dub_data:
            season = int(info.get('season', 1))
            try:
                dub_ep = int(dub_dat['episode'])
                dub_season = int(dub_dat['season'])
            except (ValueError, TypeError, KeyError):
                continue
            if (dub_season == season or dub_dat['season'] == 0) and dub_ep == episode:
                if _dub_is_upcoming(dub_dat["release_time"]):
                    code_dub = dub_dat["release_time"]

    if code_dub and code_sub:
        code = f'Sub {code_sub} / Dub {code_dub}'
    elif code_dub:
        code = f'Dub {code_dub}'
    elif code_sub:
        code = code_sub
    return code
