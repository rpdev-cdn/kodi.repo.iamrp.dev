import random
import time
from resources.lib.ui import client, control, source_utils, database


class DebridLink:
    def __init__(self):
        api_info = database.get_info('Debrid-Link') or {}
        self.ClientID = api_info.get('client_id', '')
        self.USER_AGENT = 'Otaku'
        self.token = control.getSetting('debridlink.token')
        self.refresh = control.getSetting('debridlink.refresh')
        self.autodelete = control.getBool('debridlink.autodelete')
        self.api_url = "https://debrid-link.fr/api/v2"
        self.cache_check_results = {}
        self.DeviceCode = ''
        self.OauthTimeStep = 0
        self.OauthTimeout = 0
        self.OauthTotalTimeout = 0
        self.dialog = None

    def headers(self):
        if self.token and self.refresh:
            try:
                expiry = control.getInt('debridlink.expiry')
                if expiry > 0 and time.time() > (expiry - 300):
                    self.refreshToken()
            except Exception:
                pass
        return {'User-Agent': self.USER_AGENT, 'Authorization': f"Bearer {self.token}"}

    def _request_with_backoff(self, method, url, **kwargs):
        """Execute HTTP request with 1x exponential backoff if HTTP 429 is received."""
        r = getattr(client, method.lower())(url, **kwargs)
        if r and r.status_code == 429:
            try:
                wait_seconds = float(r.headers.get('Retry-After', 1))
            except (ValueError, TypeError):
                wait_seconds = 1.0
            wait_seconds = min(max(wait_seconds, 1.0), 3.0) + random.uniform(0.1, 0.4)
            control.log(f"Debrid-Link API rate limited (429) for {url}, backing off {wait_seconds:.2f}s", 'warning')
            if control.monitor.waitForAbort(wait_seconds):
                return None
            r = getattr(client, method.lower())(url, **kwargs)
        return r

    def auth_loop(self):
        if self.dialog and self.dialog.iscanceled():
            self.OauthTimeout = 0
            return False
        url = f"{self.api_url[:-3]}/oauth/token"
        data = {
            'client_id': self.ClientID,
            'code': self.DeviceCode,
            'grant_type': 'urn:ietf:params:oauth:grant-type:device_code'
        }
        r = client.post(url, data=data, headers={'User-Agent': self.USER_AGENT})
        if r and r.ok:
            try:
                response = r.json()
                if 'access_token' in response:
                    self.token = response.get('access_token')
                    self.refresh = response.get('refresh_token')
                    control.setSetting('debridlink.token', self.token)
                    control.setSetting('debridlink.refresh', self.refresh)
                    control.setInt('debridlink.expiry', int(time.time()) + int(response.get('expires_in', 2592000)))
                    return True
            except Exception as e:
                control.log(f"Debrid-Link auth_loop error: {e}", 'error')
        return False

    def auth(self):
        import os
        from resources.lib.windows.progress_dialog import Progress_dialog

        url = '{0}/oauth/device/code'.format(self.api_url[:-3])
        data = {'client_id': self.ClientID, 'scope': 'get.post.delete.seedbox get.account'}
        r = client.post(url, data=data, headers={'User-Agent': self.USER_AGENT})
        if not r or not r.ok:
            control.ok_dialog(control.ADDON_NAME, 'Failed to connect to Debrid-Link')
            return

        try:
            resp = r.json()
        except Exception:
            resp = {}

        if not resp or 'device_code' not in resp:
            control.ok_dialog(control.ADDON_NAME, 'Failed to get Debrid-Link device code')
            return

        self.OauthTotalTimeout = self.OauthTimeout = int(resp.get('expires_in', 600))
        self.OauthTimeStep = max(1, int(resp.get('interval', 5)))
        self.DeviceCode = resp.get('device_code')

        verification_url = resp.get('verification_url', 'https://debrid-link.com/device')
        user_code = resp.get('user_code', '')
        control.copy2clip(user_code)

        qr_path = os.path.join(control.dataPath, 'qr_code.png')
        try:
            import pyqrcode
            os.makedirs(control.dataPath, exist_ok=True)
            qr_target = f"{verification_url}/{user_code}" if user_code else verification_url
            qr_code = pyqrcode.create(qr_target)
            qr_code.png(qr_path, scale=20)
        except Exception as e:
            control.log(f"Debrid-Link QR generation error: {e}", 'warning')
            qr_path = ''

        config = {
            'heading': f'{control.ADDON_NAME}: Debrid-Link Auth',
            'text': f"{control.lang(30081).format(control.colorstr(verification_url))}[CR]{control.lang(30082).format(control.colorstr(user_code))}[CR]{control.lang(30083)}",
            'qr_code': qr_path,
            'percent': 100
        }

        self.dialog = Progress_dialog('progress_dialog.xml', control.ADDON_PATH, config=config)
        self.dialog.show()

        auth_done = False
        try:
            while not auth_done and self.OauthTimeout > 0:
                for _ in range(self.OauthTimeStep):
                    if control.abort_requested() or (self.dialog and self.dialog.iscanceled()):
                        break
                    control.sleep(1000)
                if control.abort_requested() or (self.dialog and self.dialog.iscanceled()):
                    break
                self.OauthTimeout -= self.OauthTimeStep
                auth_done = self.auth_loop()
                if self.dialog:
                    self.dialog.update(int(self.OauthTimeout / self.OauthTotalTimeout * 100))
        finally:
            if self.dialog:
                self.dialog.close()
                del self.dialog
                self.dialog = None

        if auth_done:
            self.status()
            control.setBool('debridlink.enabled', True)

    def status(self):
        url = f"{self.api_url[:-3]}/account/infos"
        response = client.get(url, headers=self.headers())
        if not response:
            control.ok_dialog(control.ADDON_NAME, 'Failed to get Debrid-Link user info')
            return
        response = response.json(default={})
        if 'value' not in response:
            control.ok_dialog(control.ADDON_NAME, 'Failed to get Debrid-Link user info')
            return
        username = response['value']['pseudo']
        premium = response['value']['premiumLeft'] > 0
        control.setSetting('debridlink.username', username)
        control.ok_dialog(control.ADDON_NAME, f'Debrid-Link {control.lang(30084)}')
        if not premium:
            control.setSetting('debridlink.auth.status', 'Expired')
            control.ok_dialog(f'{control.ADDON_NAME}: Debrid-Link', control.lang(30085))
        else:
            control.setSetting('debridlink.auth.status', 'Premium')

    def refreshToken(self):
        postData = {
            'grant_type': 'refresh_token',
            'refresh_token': self.refresh,
            'client_id': self.ClientID
        }
        url = f"{self.api_url[:-3]}/oauth/token"
        response = client.post(url, data=postData, headers={'User-Agent': self.USER_AGENT})
        if not response:
            return
        response = response.json()
        if response.get('access_token'):
            self.token = response['access_token']
            control.setSetting('debridlink.token', self.token)
            control.setInt('debridlink.expiry', int(time.time()) + response['expires_in'])

    def addMagnet(self, magnet):
        postData = {
            'url': magnet,
            'async': 'true'
        }
        url = f"{self.api_url}/seedbox/add"
        r = self._request_with_backoff('post', url, data=postData, headers=self.headers())
        return r.json().get('value') if r else None

    def delete_magnet(self, magnet_id):
        url = f'{self.api_url}/seedbox/{magnet_id}/remove'
        return self._request_with_backoff('delete', url, headers=self.headers())

    def resolve_single_magnet(self, hash_, magnet, episode, pack_select, filename=None):
        magnet_data = self.addMagnet(magnet)
        if not magnet_data or 'files' not in magnet_data:
            return None
        magnet_id = magnet_data.get('id')
        selected_link = None
        try:
            files = magnet_data.get('files', [])
            folder_details = [{'link': x.get('downloadUrl'), 'path': x.get('name')} for x in files if x.get('downloadUrl')]
            if episode and folder_details:
                selected_file = source_utils.get_best_match('path', folder_details, episode, pack_select, filename)
                if selected_file and selected_file.get('link'):
                    selected_link = selected_file['link']
                    return selected_link

            sources = [(item.get('size') or 0, item.get('downloadUrl')) for item in files if item.get('downloadUrl') and any(str(item.get('name', '')).lower().endswith(x) for x in ['avi', 'mp4', 'mkv'])]

            if sources:
                selected_link = max(sources)[1]
            elif folder_details:
                selected_link = folder_details[0].get('link')
            return selected_link
        finally:
            if magnet_id and (not selected_link or self.autodelete):
                self.delete_magnet(magnet_id)

    def get_torrent_status(self, magnet):
        """
        Given a magnet link, get torrent data needed for further resolution.
        Returns a tuple: (torrent_id, status, torrent_info)
        If the torrent cannot be selected, returns (None, None, None).
        """
        magnet_data = self.addMagnet(magnet)
        if not magnet_data or not magnet_data['id']:
            control.ok_dialog(control.ADDON_NAME, "BAD LINK")
            return None, None, None
        status = magnet_data.get('downloadPercent') == 100
        return magnet, status, magnet_data

    def magnet_status(self, magnet_id):
        url = f'{self.api_url}/seedbox/{magnet_id}/infos'
        r = client.get(url, headers=self.headers())
        return r.json()['value'] if r else None

    def resolve_uncached_source(self, source, runinbackground, runinforground, pack_select):
        heading = f'{control.ADDON_NAME}: Cache Resolver'
        if runinforground:
            control.progressDialog.create(heading, "Caching Progress")
        stream_link = None
        magnet = source['magnet']
        magnet_data = self.addMagnet(magnet)
        if not magnet_data or 'id' not in magnet_data:
            if runinforground:
                control.progressDialog.close()
            return None
        magnet_id = magnet_data['id']
        magnet_status = self.magnet_status(magnet_id)
        if not magnet_status:
            if runinforground:
                control.progressDialog.close()
            return None

        if runinbackground:
            control.notify(heading, "The source is downloading to your cloud")
            return None

        while magnet_status.get('downloadPercent') < 100.0:
            if runinforground and (control.progressDialog.iscanceled() or control.wait_for_abort(5)):
                break
            magnet_status = self.magnet_status(magnet_id)
            if not magnet_status:
                break
            status = magnet_status.get('name')
            progress = magnet_status.get('downloadPercent')
            speed = magnet_status.get('downloadSpeed')
            seeders = magnet_status.get('peersConnected')

            if runinforground:
                f_body = (f"Status: {status}[CR]"
                          f"Progress: {round(progress, 2)} %[CR]"
                          f"Seeders: {seeders}[CR]"
                          f"Speed: {source_utils.get_size(speed)}")
                control.progressDialog.update(int(progress), f_body)

        if magnet_status and magnet_status.get('downloadPercent') == 100.0:
            folder_details = [{'link': x.get('downloadUrl'), 'path': x.get('name').split('/')[-1]} for x in magnet_status.get('files')]
            if len(folder_details) == 1:
                stream_link = folder_details[0]['link']
            else:
                selected_file = source_utils.get_best_match('path', folder_details, source['episode_re'], pack_select)
                if not selected_file or not selected_file['path']:
                    self.delete_magnet(magnet_id)
                    if runinforground:
                        control.progressDialog.close()
                    return None
                stream_link = selected_file['link']
        else:
            self.delete_magnet(magnet_id)
        if runinforground:
            control.progressDialog.close()
        return stream_link

    @staticmethod
    def resolve_cloud(source, pack_select):
        pass
